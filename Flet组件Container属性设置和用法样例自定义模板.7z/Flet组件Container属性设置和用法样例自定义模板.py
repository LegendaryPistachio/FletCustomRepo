import flet as ft


def main(page: ft.Page):
    page.title = "Flet组件Container属性设置和用法样例自定义模板"
    # 设置页面背景颜色为浅灰色
    page.bgcolor = ft.Colors.GREY_300

    # 创建四个容器
    container_1 = ft.Container(
        content=ft.Text("Container 1"),
        padding=ft.padding.all(10),
        width=100,
        height=100,
        bgcolor=ft.Colors.AMBER_100,
        border=ft.border.all(2, ft.Colors.GREEN),
    )
    container_2 = ft.Container(
        content=ft.Text("Container 2"),
        padding=20,  # 等同于 ft.padding.all(20)
        width=100,
        height=100,
        bgcolor=ft.Colors.AMBER_100,
        border=ft.border.all(2, ft.Colors.GREEN),
    )
    container_3 = ft.Container(
        content=ft.Text("Container 3"),
        padding=ft.padding.symmetric(horizontal=10),
        width=100,
        height=100,
        bgcolor=ft.Colors.AMBER_100,
        border=ft.border.all(2, ft.Colors.GREEN),
    )
    container_4 = ft.Container(
        content=ft.Text("Container 4"),
        padding=ft.padding.only(left=10),
        width=100,
        height=100,
        bgcolor=ft.Colors.AMBER_100,
        border=ft.border.all(2, ft.Colors.GREEN),
    )

    # 将容器添加到页面
    page.add(
        ft.Row(
            [
                container_1,
                container_2,
                container_3,
                container_4,
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )


ft.app(target=main)
