import flet as ft

def main(page: ft.Page):
    page.title = "Flet动画切换过渡枚举值ROTATION旋转切换示例自定义模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # 使用普通布尔变量管理状态
    toggle_flag = False
    
    # 动态内容控件
    content = ft.AnimatedSwitcher(
        content=ft.Container(
            key="A",
            width=100,
            height=100,
            bgcolor=ft.Colors.BLUE,  # 使用 ft.Colors 替代 ft.colors
            alignment=ft.alignment.center,
            content=ft.Text("A", color=ft.Colors.WHITE)  # 使用 ft.Colors 替代 ft.colors
        ),
        transition=ft.AnimatedSwitcherTransition.ROTATION,
        duration=500
    )

    def toggle_content(e):
        nonlocal toggle_flag  # 声明为非局部变量
        # 切换内容
        if toggle_flag:
            new_content = ft.Container(
                key="A",
                width=100,
                height=100,
                bgcolor=ft.Colors.BLUE,  # 使用 ft.Colors 替代 ft.colors
                alignment=ft.alignment.center,
                content=ft.Text("A", color=ft.Colors.WHITE)  # 使用 ft.Colors 替代 ft.colors
            )
        else:
            new_content = ft.Container(
                key="B",
                width=100,
                height=100,
                bgcolor=ft.Colors.RED,  # 使用 ft.Colors 替代 ft.colors
                alignment=ft.alignment.center,
                content=ft.Text("B", color=ft.Colors.WHITE)  # 使用 ft.Colors 替代 ft.colors
            )
        
        # 更新状态和内容
        toggle_flag = not toggle_flag
        content.content = new_content
        page.update()

    page.add(
        ft.Column(
            [
                content,
                ft.ElevatedButton("切换", on_click=toggle_content)
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

ft.app(target=main)