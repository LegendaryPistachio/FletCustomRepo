# main.py
import subprocess
import flet as ft


def start_child1_win(event):
    # Pass -Xfrozen_modules=off parameter to disable frozen modules
    subprocess.Popen(["python", "-Xfrozen_modules=off", "child1.py"])


def start_child2_win(event):
    # Pass -Xfrozen_modules=off parameter to disable frozen modules
    subprocess.Popen(["python", "-Xfrozen_modules=off", "child2.py"])


def main(page: ft.Page):
    page.title = "Main Interface - Flet Multi-Process Management Independent Multiple Windows Desktop Application Framework Custom Component Template"
    page.add(
        ft.TextButton(text="Start Sub-Interface 1", on_click=start_child1_win),
        ft.TextButton(text="Start Sub-Interface 2", on_click=start_child2_win),
    )


ft.app(target=main)
