# child2.py
import flet as ft


def main(page: ft.Page):
    page.title = "Sub-Interface 2"
    page.window.always_on_top = True
    text_control = ft.Text("This is Sub-Interface 2")
    page.add(text_control)


ft.app(target=main)
