import flet as ft


def main(page: ft.Page):
    page.title = "Flet时间选择器TimePicker中文环境配置自定义模板"
    page.locale_configuration = ft.LocaleConfiguration(
        supported_locales=[
            ft.Locale("en", "English"),
            ft.Locale("zh", "Chinese"),
        ],
        current_locale=ft.Locale("zh", "Chinese"),
    )

    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def handle_change(e):
        page.add(ft.Text(f"时间变更为: {time_picker.value}"))

    def handle_dismissal(e):
        page.add(ft.Text(f"时间选择器已关闭: {time_picker.value}"))

    def handle_entry_mode_change(e):
        entry_mode_text = {
            ft.TimePickerEntryMode.INPUT: "文本输入模式",
            ft.TimePickerEntryMode.DIAL: "表盘选择器模式",
        }.get(e.entry_mode, "未知模式")
        page.add(ft.Text(f"时间选择器输入模式已更改为: {entry_mode_text}"))

    time_picker = ft.TimePicker(
        confirm_text="确认",
        error_invalid_text="时间超出范围",
        help_text="选择你的时间段",
        on_change=handle_change,
        on_dismiss=handle_dismissal,
        on_entry_mode_change=handle_entry_mode_change,
    )

    page.add(
        ft.ElevatedButton(
            "选择时间",
            icon=ft.Icons.TIME_TO_LEAVE,
            on_click=lambda _: page.open(time_picker),
        )
    )


ft.app(main)
