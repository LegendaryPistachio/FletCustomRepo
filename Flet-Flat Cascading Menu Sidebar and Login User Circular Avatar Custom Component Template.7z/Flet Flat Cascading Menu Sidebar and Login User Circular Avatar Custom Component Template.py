import flet as ft


def example():
    return ft.Container(
        content=ft.Column(
            controls=[
                ft.Container(
                    content=ft.Stack(
                        [
                            ft.CircleAvatar(
                                foreground_image_src="https://avatars.githubusercontent.com/u/5041459?s=88&v=4",
                                radius=30,  # Set avatar radius to 30 to fit a 60x60 container
                                tooltip="User Avatar",  # Optional: Add tooltip
                            ),
                            ft.Container(
                                content=ft.CircleAvatar(
                                    bgcolor=ft.Colors.GREEN,
                                    radius=10,
                                    content=ft.Text(
                                        "Online",
                                        size=5,
                                        color=ft.Colors.WHITE,
                                    ),
                                ),
                                alignment=ft.alignment.bottom_right,
                            ),
                        ],
                        width=60,
                        height=60,
                    ),
                    margin=ft.margin.only(left=70),  # Move left by 70 pixels
                    alignment=ft.alignment.center_left,  # Left alignment
                ),
                ft.Container(
                    width=220,
                    content=ft.ExpansionTile(
                        title=ft.Row(
                            controls=[
                                ft.Icon(
                                    ft.Icons.STAR, color=ft.Colors.BLUE
                                ),  # Star icon
                                ft.Text("ExpansionTile 1"),
                            ]
                        ),
                        affinity=ft.TileAffinity.PLATFORM,  # Expansion arrow on the right
                        maintain_state=True,
                        initially_expanded=False,  # Default collapsed
                        collapsed_text_color=ft.Colors.BLUE,
                        text_color=ft.Colors.AMBER,
                        controls=[
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.STAR, color=ft.Colors.BLUE
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 1"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.SEARCH, color=ft.Colors.BLUE
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 2"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.BOOKMARK, color=ft.Colors.BLUE
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 3"),
                                    ]
                                )
                            ),
                        ],
                    ),
                ),
                ft.Container(
                    width=220,
                    content=ft.ExpansionTile(
                        title=ft.Row(
                            controls=[
                                ft.Icon(
                                    ft.Icons.NOTIFICATIONS, color=ft.Colors.GREEN
                                ),  # Fixed icon
                                ft.Text("ExpansionTile 2"),
                            ]
                        ),
                        affinity=ft.TileAffinity.PLATFORM,  # Expansion arrow on the right
                        maintain_state=True,
                        initially_expanded=False,  # Default collapsed
                        collapsed_text_color=ft.Colors.BLUE,
                        text_color=ft.Colors.AMBER,
                        controls=[
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.FAVORITE, color=ft.Colors.BLUE
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 1"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.EMAIL, color=ft.Colors.BLUE
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 2"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.CLOSE_FULLSCREEN,
                                            color=ft.Colors.BLUE,
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 3"),
                                    ]
                                )
                            ),
                        ],
                    ),
                ),
                ft.Container(
                    width=220,
                    content=ft.ExpansionTile(
                        title=ft.Row(
                            controls=[
                                ft.Icon(
                                    ft.Icons.SETTINGS, color=ft.Colors.RED
                                ),  # Fixed icon
                                ft.Text("ExpansionTile 3"),
                            ]
                        ),
                        affinity=ft.TileAffinity.PLATFORM,  # Expansion arrow on the right
                        maintain_state=True,
                        initially_expanded=False,  # Default collapsed
                        collapsed_text_color=ft.Colors.BLUE,
                        text_color=ft.Colors.AMBER,
                        controls=[
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.HOME, color=ft.Colors.BLUE
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 1"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.SETTINGS, color=ft.Colors.BLUE
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 2"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.PERM_DEVICE_INFORMATION,
                                            color=ft.Colors.BLUE,
                                        ),  # Fixed icon
                                        ft.Text("Subtitle 3"),
                                    ]
                                )
                            ),
                        ],
                    ),
                ),
            ],
            alignment=ft.MainAxisAlignment.START,  # Alignment
        ),
        alignment=ft.alignment.center,  # Center alignment
    )


def main(page: ft.Page):
    page.title = "Flet Flat Cascading Menu Sidebar and Login User Circular Avatar Custom Component Template"
    page.window.center()
    page.add(example())


ft.app(target=main)
