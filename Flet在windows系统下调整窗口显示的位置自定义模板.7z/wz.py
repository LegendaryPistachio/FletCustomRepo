import flet as ft


def main(page):
    # 设置窗口标题
    page.title = "Flet在windows系统下调整窗口显示的位置自定义模板"

    # 设定窗口大小
    page.window.width = 800
    page.window.height = 600

    # 调整窗口位置
    page.window.left = 500  # 左边距离
    page.window.top = 400  # 上边距离

    # 添加组件
    page.add(ft.Text("欢迎使用 Flet 框架！"))


# 运行应用
ft.app(target=main)
