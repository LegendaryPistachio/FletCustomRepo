import flet as ft


def main(page: ft.Page):
    page.title = (
        "Flet Container Text Ten Alignment Ways Alignment Class Custom Template"
    )
    page.scroll = "adaptive"

    # Create three Row containers to arrange sub-containers
    row1 = ft.Row(
        [
            ft.Container(
                content=ft.Text(
                    "Top Left Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.top_left,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
            ft.Container(
                content=ft.Text(
                    "Top Center Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.top_center,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
            ft.Container(
                content=ft.Text(
                    "Top Right Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.top_right,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
        ],
        alignment=ft.MainAxisAlignment.START,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    row2 = ft.Row(
        [
            ft.Container(
                content=ft.Text(
                    "Center Left Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.center_left,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
            ft.Container(
                content=ft.Text(
                    "Center Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.center,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
            ft.Container(
                content=ft.Text(
                    "Center Right Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.center_right,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
        ],
        alignment=ft.MainAxisAlignment.START,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    row3 = ft.Row(
        [
            ft.Container(
                content=ft.Text(
                    "Bottom Left Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.bottom_left,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
            ft.Container(
                content=ft.Text(
                    "Bottom Center Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.bottom_center,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
            ft.Container(
                content=ft.Text(
                    "Bottom Right Alignment",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.bottom_right,
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
            ft.Container(
                content=ft.Text(
                    "Custom Alignment (-0.5, -0.5)",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.Alignment(-0.5, -0.5),
                width=200,
                height=200,  # Change to square
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # Add blue border
            ),
        ],
        alignment=ft.MainAxisAlignment.START,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    # Create a Column container to arrange three Row containers
    column = ft.Column(
        [row1, row2, row3],
        alignment=ft.MainAxisAlignment.START,
        horizontal_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    # Add Column container to the page
    page.add(column)


ft.app(target=main)
