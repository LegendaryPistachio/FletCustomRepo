import flet as ft
import json

# 修改 header_list，去掉多余的一列
header_list = ["序号", "产品名称", "SN号", "规格型号", "数量", "操作"]

data_table_style = {
    "expand": True,
    "border_radius": 8,
    "border": ft.border.all(2, "#ebebeb"),
    "horizontal_lines": ft.border.BorderSide(1, "#ebebeb"),
    "columns": [
        ft.DataColumn(
            label=ft.Text(
                index, color="black", weight="bold", text_align=ft.TextAlign.CENTER
            ),
            heading_row_alignment=ft.MainAxisAlignment.CENTER,
        )
        for index in header_list
    ],
    "show_bottom_border": True,
}


class CustomDataTable(ft.DataTable):
    def __init__(self):
        super().__init__(**data_table_style)
        self.width = 1240
        self.height = 300
        self.vertical_lines = ft.border.BorderSide(1, "#ebebeb")
        self.column_spacing = 5
        self.data_row_max_height = 50
        self.heading_row_color = ft.Colors.BLUE_50
        self.rows = []
        self.editing_rows = set()  # 用于跟踪正在编辑的行
        self.load_data()  # 加载数据

    def textField(self, keyboard_type, width, value="", on_change=None):
        return ft.Container(
            content=ft.TextField(
                keyboard_type=keyboard_type,
                color="black",
                bgcolor=ft.Colors.GREY_50,
                height=42,
                border_width=0,
                cursor_height=20,
                adaptive=True,
                value=value,
                on_change=on_change,
            ),
            width=width,
        )

    def fill_data_table(self, filtered_data=None):
        self.rows = []
        data = filtered_data if filtered_data is not None else self.data
        for index, values in enumerate(data):
            is_editing = index in self.editing_rows
            cells = [
                ft.DataCell(
                    ft.Text(
                        str(index + 1),
                        color="black",
                        weight="bold",
                        text_align=ft.TextAlign.CENTER,
                        width=30,
                    )
                ),
                ft.DataCell(
                    self.textField(
                        keyboard_type=ft.KeyboardType.TEXT,
                        width=200,
                        value=values[1],
                        on_change=lambda e, i=index: self.update_cell(e, i, 1),
                    )
                    if is_editing
                    else ft.Text(values[1], color="black", text_align=ft.TextAlign.LEFT)
                ),
                ft.DataCell(
                    self.textField(
                        keyboard_type=ft.KeyboardType.TEXT,
                        width=180,
                        value=values[2],
                        on_change=lambda e, i=index: self.update_cell(e, i, 2),
                    )
                    if is_editing
                    else ft.Text(values[2], color="black", text_align=ft.TextAlign.LEFT)
                ),
                ft.DataCell(
                    self.textField(
                        keyboard_type=ft.KeyboardType.TEXT,
                        width=200,
                        value=values[3],
                        on_change=lambda e, i=index: self.update_cell(e, i, 3),
                    )
                    if is_editing
                    else ft.Text(values[3], color="black", text_align=ft.TextAlign.LEFT)
                ),
                ft.DataCell(
                    self.textField(
                        keyboard_type=ft.KeyboardType.NUMBER,
                        width=70,
                        value=str(values[4]),
                        on_change=lambda e, i=index: self.update_cell(e, i, 4),
                    )
                    if is_editing
                    else ft.Text(
                        str(values[4]), color="black", text_align=ft.TextAlign.RIGHT
                    )
                ),
                ft.DataCell(  # 修改操作列的宽度和布局
                    ft.Container(
                        content=ft.Row(
                            controls=[
                                ft.ElevatedButton(
                                    text="编辑" if not is_editing else "取消",
                                    icon=(
                                        ft.Icons.EDIT
                                        if not is_editing
                                        else ft.Icons.CANCEL
                                    ),
                                    icon_color=ft.Colors.WHITE,
                                    color=ft.Colors.WHITE,
                                    tooltip=ft.Tooltip(
                                        message=(
                                            "编辑当前行"
                                            if not is_editing
                                            else "取消编辑"
                                        )
                                    ),
                                    bgcolor=(
                                        ft.Colors.GREEN_200
                                        if not is_editing
                                        else ft.Colors.RED_200
                                    ),
                                    style=ft.ButtonStyle(
                                        shape={"": ft.RoundedRectangleBorder(radius=8)},
                                        padding=ft.padding.all(8),
                                    ),
                                    on_click=lambda e, row_index=index: self.toggle_edit_mode(
                                        e, row_index
                                    ),
                                ),
                                ft.ElevatedButton(
                                    text="保存",
                                    icon=ft.Icons.SAVE,
                                    icon_color=ft.Colors.WHITE,
                                    color=ft.Colors.WHITE,
                                    tooltip=ft.Tooltip(message="保存当前行"),
                                    bgcolor=ft.Colors.BLUE_200,
                                    style=ft.ButtonStyle(
                                        shape={"": ft.RoundedRectangleBorder(radius=8)},
                                        padding=ft.padding.all(8),
                                    ),
                                    on_click=lambda e, row_index=index: self.save_row(
                                        e, row_index
                                    ),
                                    visible=is_editing,
                                ),
                                ft.ElevatedButton(
                                    text="删除",
                                    icon=ft.Icons.DELETE,
                                    icon_color=ft.Colors.WHITE,
                                    color=ft.Colors.WHITE,
                                    tooltip=ft.Tooltip(message="删除当前行"),
                                    bgcolor=ft.Colors.RED_200,
                                    style=ft.ButtonStyle(
                                        shape={"": ft.RoundedRectangleBorder(radius=8)},
                                        padding=ft.padding.all(8),
                                    ),
                                    on_click=lambda e, row_index=index: self.delete_row(
                                        e, row_index
                                    ),
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.START,  # 修改此处为左对齐
                            spacing=5,
                        ),
                        width=300,  # 修改此处宽度，以适应所有操作按钮
                        alignment=ft.alignment.top_left,  # 使用 top_left 而不是 start
                    )
                ),
            ]
            data_row = ft.DataRow(cells=cells)
            self.rows.append(data_row)
        self.update()

    def toggle_edit_mode(self, e, row_index):
        if row_index in self.editing_rows:
            self.editing_rows.remove(row_index)
        else:
            self.editing_rows.add(row_index)
        self.fill_data_table()

    def save_row(self, e, row_index):
        self.editing_rows.discard(row_index)
        self.fill_data_table()
        self.save_data(e)

    def add_row(self, e):
        new_row = ["", "", "", "", ""]
        self.data.append(new_row)
        self.fill_data_table()

    def delete_row(self, e, row_index):
        del self.data[row_index]
        self.fill_data_table()

    def update_cell(self, e, row_index, col_index):
        self.data[row_index][col_index] = e.control.value

    def load_data(self):
        try:
            with open("data.json", "r") as file:
                self.data = json.load(file)
        except FileNotFoundError:
            self.data = []

    def save_data(self, e):
        with open("data.json", "w") as file:
            json.dump(self.data, file, ensure_ascii=False, indent=4)

    def query_data(self, e):
        query_text = self.query_input.value.lower()
        filtered_data = [
            row
            for row in self.data
            if any(query_text in str(cell).lower() for cell in row)
        ]
        self.fill_data_table(filtered_data)


def main(page: ft.Page):
    page.title = "Flet增删改查表格数据管理数据的框架自定义组件模板"
    page.adaptive = True
    data_table = CustomDataTable()
    add_button = ft.ElevatedButton(
        text="添加行",
        icon=ft.Icons.ADD,
        on_click=data_table.add_row,
    )
    save_all_button = ft.ElevatedButton(
        text="全部保存",
        icon=ft.Icons.SAVE,
        on_click=data_table.save_data,
    )
    query_button = ft.ElevatedButton(
        text="查询",
        icon=ft.Icons.SEARCH,
        on_click=data_table.query_data,
    )
    data_table.query_input = ft.TextField(
        hint_text="输入查询条件",
        width=300,
        on_submit=data_table.query_data,
    )
    page.add(
        ft.Column(
            scroll=ft.ScrollMode.ALWAYS,
            expand=True,
            controls=[
                ft.Container(
                    content=ft.Row(
                        controls=[
                            data_table.query_input,
                            query_button,
                            add_button,
                            save_all_button,
                        ],
                        alignment=ft.MainAxisAlignment.END,
                    ),
                    padding=ft.padding.only(top=10, bottom=10),
                ),
                ft.Container(
                    content=ft.Row(
                        controls=[data_table],
                        scroll=ft.ScrollMode.ALWAYS,
                    ),
                    padding=ft.padding.only(bottom=20),
                ),
            ],
        ),
    )
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    data_table.fill_data_table()  # 在这里调用 fill_data_table 方法


if __name__ == "__main__":
    ft.app(target=main)
