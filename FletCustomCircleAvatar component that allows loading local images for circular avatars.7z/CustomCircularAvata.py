import flet as ft

def main(page: ft.Page):
    def create_circle_avatar(src: str, size: int = 200) -> ft.Container:
        return ft.Container(
            content=ft.Image(src=src, width=size, height=size, fit=ft.ImageFit.COVER),
            width=size,
            height=size,
            border_radius=size/2,
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        )

    contact_us_content = ft.Container(
        content=ft.Column([
            create_circle_avatar("logo.jpg"),
            ft.Text("Shopping List Assistant Desktop Program 1.0", size=20, weight=ft.FontWeight.BOLD),
            ft.Text("Created by Legendary Pistachio using FLet", size=16),
            ft.Text("Completed on October 14, 2024, at home in Guazhou", size=16),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20),
        alignment=ft.alignment.center,
        width=1200,
        height=522,
        bgcolor=ft.colors.WHITE,
        padding=20,
    )

    page.add(contact_us_content)

ft.app(target=main)