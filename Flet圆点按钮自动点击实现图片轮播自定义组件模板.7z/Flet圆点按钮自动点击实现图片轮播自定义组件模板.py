import flet as ft
from flet import Icons  # 导入 Icons 模块
import threading
import time

# 图片列表
images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg",
    "image6.jpg",
    "image7.jpg",
]


def change_image(index, image_container, buttons, page):
    image_container.content.src = images[index]
    page.update()
    # 更新按钮的选中状态
    for i, button in enumerate(buttons):
        button.selected = i == index
    page.update()


def auto_change_image(image_container, buttons, page):
    current_index = 0

    def change():
        nonlocal current_index
        while True:
            current_index = (current_index + 1) % len(images)
            change_image(current_index, image_container, buttons, page)
            buttons[current_index].on_click(None)  # 模拟按钮点击事件
            time.sleep(3)  # 3 秒

    # 创建并启动线程
    thread = threading.Thread(target=change, daemon=True)
    thread.start()


def main(page: ft.Page):
    page.title = "Flet圆点按钮自动点击实现图片轮播自定义组件模板"

    # 初始化当前图片索引
    current_index = 0

    # 图片容器
    image_container = ft.Container(
        content=ft.Image(
            src=images[current_index], width=1000, height=500, fit=ft.ImageFit.COVER
        ),
        alignment=ft.alignment.center,
    )

    # 按钮行
    buttons = [
        ft.IconButton(
            icon=Icons.CIRCLE_SHARP,  # 使用 CIRCLE_SHARP 图标
            selected_icon=Icons.CIRCLE_SHARP,  # 可选：设置选中时的图标
            icon_color="blue",  # 可选：设置图标的颜色
            selected_icon_color="red",  # 可选：设置选中时图标的颜色
            tooltip=f"Image {i+1}",  # 可选：设置工具提示
            selected=i == current_index,  # 初始化选中状态
            on_click=lambda e, i=i: change_image(i, image_container, buttons, page),
        )
        for i in range(len(images))
    ]
    buttons_row = ft.Row(
        buttons,
        alignment=ft.MainAxisAlignment.CENTER,
        width=500,  # 调整 Row 的宽度以适应所有按钮
    )

    # 使用 Stack 将 image_container 和 buttons_row 堆叠在一起
    stack = ft.Stack(
        [
            image_container,
            ft.Container(
                content=buttons_row,
                alignment=ft.alignment.bottom_center,  # 将按钮行放置在底部中心
                margin=ft.margin.only(bottom=20),  # 调整按钮行的底部边距
            ),
        ],
        width=1000,  # 设置 Stack 的宽度
        height=500,  # 设置 Stack 的高度
    )

    # 将 Stack 添加到页面中
    page.add(
        ft.Column(
            [
                ft.Row(
                    [stack],
                    alignment=ft.MainAxisAlignment.CENTER,  # 水平居中
                    expand=True,  # 使 Row 占据整个页面宽度
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,  # 垂直居中
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # 水平居中
            expand=True,  # 使 Column 占据整个页面高度
        )
    )

    # 启动定时器
    auto_change_image(image_container, buttons, page)


ft.app(target=main)
