import flet as ft
from PIL import Image, ImageOps
import os

def main(page: ft.Page):
    def create_reflection():
        # Open the image and resize it
        image = Image.open("logo.jpg").resize((200, 200))
        # Flip the image vertically to create the reflection
        reflection = ImageOps.flip(image)
        # Adjust the transparency of the reflection
        reflection = reflection.convert("RGBA")
        data = reflection.getdata()
        new_data = [(item[0], item[1], item[2], 128) for item in data]
        reflection.putdata(new_data)
        
        # Save the reflection image to a temporary file
        temp_file = "reflection.png"
        reflection.save(temp_file, format="PNG")
        return temp_file

    # Create the original image and the reflection image
    original_image = ft.Image(src="logo.jpg", width=200, height=200, left=0, top=0)
    reflection_image = ft.Image(src=create_reflection(), width=200, height=200, left=0, top=200)

    # Use the Stack control to place the images
    stack = ft.Stack([
        original_image,
        reflection_image
    ], expand=True)

    page.add(stack)

ft.app(target=main)