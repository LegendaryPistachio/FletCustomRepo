import flet as ft
import asyncio

def main(page: ft.Page):
    # 初始购物车图标（彩色）
    cart_icon_colored = ft.Icon(name=ft.icons.SHOPPING_CART, size=40, color=ft.colors.AMBER)
    # 商品图标（彩色）
    product_icon_colored = ft.Icon(name=ft.icons.SHOPPING_BAG, size=40, color=ft.colors.PINK)

    # 创建购物车容器
    cart_container = ft.Container(
        content=cart_icon_colored,
        width=50,
        height=50,
        alignment=ft.alignment.center,
        left=20,
        top=300,  # 购物车位置不变
    )

    # 创建商品容器
    product_container = ft.Container(
        content=product_icon_colored,
        width=50,
        height=50,
        alignment=ft.alignment.center,
        left=150,
        top=50,
    )

    # 贝塞尔曲线函数
    def bezier_curve(t, p0, p1, p2):
        return (1 - t)**2 * p0 + 2 * (1 - t) * t * p1 + t**2 * p2

    # 动画函数
    async def animate_product(e):
        duration = 3  # 动画持续时间（秒）
        steps = 100  # 动画步数
        trail_points = []
        for i in range(steps + 1):
            t = i / steps
            x = bezier_curve(t, 150, 200, 20)
            y = bezier_curve(t, 50, 200, 300)
            trail_points.append((x, y))
        for i in range(steps +1):
            t = i / steps
            x = trail_points[i][0]
            y = trail_points[i][1]
            product_container.left = x
            product_container.top = y
            if i == steps:  # 当商品到达购物车时
                product_container.content.size = 25  # 变小到25像素
                product_container.top = cart_container.top - 10 # 向上移动3像素
            page.update()
            await asyncio.sleep(duration / steps)
        # 更改购物车图标为彩色图标
        cart_container.content = ft.Icon(name=ft.icons.SHOPPING_CART_OUTLINED, size=40, color=ft.colors.GREEN)
        cart_container.update()

    # 添加到页面
    page.add(
        ft.Stack(
            [product_container, cart_container],
            width=400,
            height=400,
        ),
        ft.ElevatedButton("添加商品到购物车", on_click=animate_product),  # 按钮文本为中文
    )

ft.app(target=main)