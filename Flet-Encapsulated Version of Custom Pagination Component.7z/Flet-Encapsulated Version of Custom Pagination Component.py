import flet as ft

class CustomPaginationComponent(ft.Row):
    def __init__(self, total_pages, current_page, page_change_callback):
        super().__init__()
        self.total_pages = total_pages
        self.current_page = current_page
        self.page_change_callback = page_change_callback

        self.previous_button = ft.ElevatedButton("<", on_click=self.previous_page)
        self.page_label = ft.Text(f"Page {self.current_page} / {self.total_pages}")
        self.next_button = ft.ElevatedButton(">", on_click=self.next_page)

        self.controls = [self.previous_button, self.page_label, self.next_button]

    def previous_page(self, e):
        if self.current_page > 1:
            self.current_page -= 1
            self.update_page_label()
            self.page_change_callback(self.current_page)

    def next_page(self, e):
        if self.current_page < self.total_pages:
            self.current_page += 1
            self.update_page_label()
            self.page_change_callback(self.current_page)

    def update_page_label(self):
        self.page_label.value = f"Page {self.current_page} / {self.total_pages}"
        self.update()

def main_function(page: ft.Page):
    def page_change_callback(page_number):
        # Handle the logic when the page changes, for example, fetch data for the corresponding page and update the page content
        print(f"Switched to page {page_number}")
        image_path = f"{page_number}.jpg"
        page.controls = [
            ft.Container(
                content=CustomPaginationComponent(3, page_number, page_change_callback),
                padding=ft.padding.only(left=100)  # Move 100 pixels to the right
            ),
            ft.Container(
                content=ft.Image(src=image_path, width=500, height=700),  # Set the width and height of the image
                alignment=ft.alignment.top_left  # Align from the top-left corner
            )
        ]
        page.update()

    # Display the image of the first page by default
    page.controls = [
        ft.Container(
            content=CustomPaginationComponent(3, 1, page_change_callback),
            padding=ft.padding.only(left=100)  # Move 100 pixels to the right
        ),
        ft.Container(
            content=ft.Image(src="1.jpg", width=500, height=700),  # Set the width and height of the image
            alignment=ft.alignment.top_left  # Align from the top-left corner
        )
    ]
    
    page.update()

ft.app(target=main_function)