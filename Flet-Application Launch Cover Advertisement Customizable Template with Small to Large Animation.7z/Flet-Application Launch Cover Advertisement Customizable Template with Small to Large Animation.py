import flet as ft
import asyncio


async def increase_size(page: ft.Page):
    # Initialize window size
    initial_width = 320  # Initial width
    initial_height = 159  # Initial height
    target_width = 640  # Target width
    target_height = 319  # Target height
    total_duration = 5  # Animation duration (seconds)
    frames_per_second = 30  # Frames per second
    total_frames = total_duration * frames_per_second  # Total frames
    width_increment = (
        target_width - initial_width
    ) / total_frames  # Width increment per frame
    height_increment = (
        target_height - initial_height
    ) / total_frames  # Height increment per frame

    # Set borderless window
    page.window.resizable = False
    page.window.width = initial_width
    page.window.height = initial_height
    page.window.frameless = True  # Set borderless window
    page.padding = 0  # Remove default padding
    page.window.left = 400
    page.window.top = 300  # Modify to 300

    # Load and fill image
    img = ft.Image(
        src="cangku.png",
        width=initial_width,
        height=initial_height,
        fit=ft.ImageFit.CONTAIN,  # Use CONTAIN to make the image fit the window
    )
    page.add(img)

    # Stay for 2 seconds
    await asyncio.sleep(2)

    # Animation process
    for _ in range(total_frames):
        # Increase window size and update
        page.window.width += width_increment
        page.window.height += height_increment
        img.width = page.window.width
        img.height = page.window.height
        img.fit = ft.ImageFit.CONTAIN  # Ensure the image fits the new window size
        page.update()  # Update the page

        await asyncio.sleep(1 / frames_per_second)  # Control frame rate


# Start app
ft.app(target=increase_size)
