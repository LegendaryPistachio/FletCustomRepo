import flet as ft


def main(page: ft.Page):
    page.title = "Flet Personal Center Entry and 3D Cascading Menu Combined Sidebar Custom Component Template"

    def handle_change(e: ft.ControlEvent):
        print(f"change on panel with index {e.data}")

    def handle_delete(e: ft.ControlEvent):
        panel.controls.remove(e.control.data)
        page.update()

    panel = ft.ExpansionPanelList(
        expand_icon_color=ft.Colors.AMBER,  # Keep the expand icon color amber
        elevation=8,
        divider_color=ft.Colors.GREY_300,  # Change the divider color to grey
        on_change=handle_change,
        controls=[],
    )

    icons = [
        ft.Icons.FOLDER,
        ft.Icons.FILE_PRESENT,
        ft.Icons.INSERT_DRIVE_FILE,
    ]

    icon_colors = [
        ft.Colors.BLUE,  # Folder icon color
        ft.Colors.GREEN,  # File icon color
        ft.Colors.RED,  # File insert icon color
    ]

    for i in range(3):
        exp = ft.ExpansionPanel(
            bgcolor=ft.Colors.WHITE,  # Set background color to white
            header=ft.ListTile(
                leading=ft.Icon(
                    icons[i % len(icons)], color=icon_colors[i % len(icon_colors)]
                ),  # Set icon color
                title=ft.Text(f"Panel {i}"),
            ),
        )

        exp.content = ft.ListTile(
            title=ft.Text(f"This is in Panel {i}"),
            subtitle=ft.Text(f"Press the icon to delete panel {i}"),
            trailing=ft.IconButton(ft.Icons.DELETE, on_click=handle_delete, data=exp),
        )

        panel.controls.append(exp)

    fixed_width = 200  # Set fixed width

    # Create circular avatar component
    avatar = ft.CircleAvatar(
        foreground_image_url="https://avatars.githubusercontent.com/u/5041459?s=88&v=4",
        radius=30,
    )

    # Create badge component
    badge = ft.Container(
        content=ft.Text(
            "", color=ft.Colors.WHITE, size=12, weight=ft.FontWeight.BOLD
        ),  # Remove exclamation mark
        bgcolor=ft.Colors.GREEN,  # Change badge color to green
        width=16,
        height=16,
        border_radius=8,
        alignment=ft.alignment.center,
    )

    # Use Container to overlay badge on avatar
    avatar_with_badge = ft.Container(
        content=ft.Stack(
            controls=[
                avatar,
                ft.Container(
                    content=badge,
                    alignment=ft.alignment.top_right,
                ),
            ],
            width=60,  # Ensure Stack width is sufficient to accommodate avatar and badge
            height=60,  # Ensure Stack height is sufficient to accommodate avatar and badge
        ),
        alignment=ft.alignment.center_left,
    )

    # Create card component and add avatar with badge and text inside
    card = ft.Card(
        width=fixed_width,
        content=ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            avatar_with_badge,
                            ft.Text(
                                "Personal Center", size=12, weight=ft.FontWeight.BOLD
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.START,
                        spacing=10,  # Add spacing
                    ),
                ],
                alignment=ft.MainAxisAlignment.START,
                tight=True,
            ),
            padding=10,
        ),
    )

    # Use Container to wrap ExpansionPanelList and set fixed width
    page.add(
        ft.Container(
            width=fixed_width,
            content=ft.Column(
                controls=[
                    card,
                    panel,
                ],
            ),
        )
    )


ft.app(main)
