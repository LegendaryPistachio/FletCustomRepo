import flet as ft

class CustomTab:
    def __init__(self, text, icon_path, on_click=None):
        self.text = text
        self.icon_path = icon_path
        self.on_click = on_click
        self.container = None

    def build(self):
        self.container = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[ft.Image(src=self.icon_path, width=64, height=64)],
                        alignment=ft.MainAxisAlignment.CENTER
                    ),
                    ft.Row(
                        controls=[ft.Text(self.text, color=ft.colors.WHITE, size=16)],
                        alignment=ft.MainAxisAlignment.CENTER
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=5
            ),
            bgcolor=ft.colors.GREEN_500,
            height=200,
            width=200,
            on_click=self.on_click,
            ink=True  # Ensure it has an ink effect
        )
        return self.container

def create_tab(text, icon_path, on_click):
    return CustomTab(text=text, icon_path=icon_path, on_click=on_click).build()

def main(page: ft.Page):
    # Set the initial size and style of the window
    page.window.width = 1220
    page.window.height = 800
    page.window.frameless = True
    page.window.resizable = False

    current_tab = None
    content_container = ft.Column()

    tab_contents = {
        "My Selections": ft.Text("This is the My Selections page", bgcolor=ft.colors.RED),
        "List Details": ft.Text("This is the List Details page", bgcolor=ft.colors.ORANGE),
        "Add Item": ft.Text("This is the Add Item page", bgcolor=ft.colors.GREEN),
        "Save Item": ft.Text("This is the Save Item page", bgcolor=ft.colors.BLUE),
        "Delete Item": ft.Text("This is the Delete Item page", bgcolor=ft.colors.PURPLE),
        "Contact Us": ft.Text("This is the Contact Us page", bgcolor=ft.colors.YELLOW),
    }

    def tab_clicked(e):
        nonlocal current_tab
        tab_text = e.control.content.controls[1].controls[0].value
        print(f"{tab_text} tab clicked")

        if current_tab:
            current_tab.bgcolor = ft.colors.GREEN_500
        
        current_tab = e.control
        current_tab.bgcolor = ft.colors.GREEN_400
        page.update()

        content_container.clean()
        content_container.controls.append(tab_contents[tab_text])
        page.update()

    # Create the top title bar
    def create_app_title():
        app_title_row = ft.Row(
            controls=[
                ft.IconButton(ft.icons.SHOPPING_CART, tooltip="Shopping Cart", icon_color=ft.colors.WHITE),
                ft.Text("Shopping List Assistant Desktop Program 1.0", color=ft.colors.WHITE, size=16)
            ],
            alignment=ft.MainAxisAlignment.START
        )
        close_button = ft.IconButton(
            ft.icons.CLOSE,
            tooltip="Close",
            icon_color=ft.colors.RED,
            on_click=lambda e: page.window.close()
        )
        icons_row = ft.Row(
            controls=[
                ft.IconButton(ft.icons.HOME, tooltip="Home", icon_color=ft.colors.WHITE),
                ft.IconButton(ft.icons.SEARCH, tooltip="Search", icon_color=ft.colors.WHITE),
                ft.IconButton(ft.icons.SETTINGS, tooltip="Settings", icon_color=ft.colors.WHITE),
                close_button
            ],
            alignment=ft.MainAxisAlignment.END
        )
        top_row_container = ft.Container(
            content=ft.Row(
                controls=[app_title_row, icons_row],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                height=50,
                width=1220
            ),
            bgcolor=ft.colors.GREEN_500,
            padding=10,
        )
        return top_row_container

    # Create the tab bar
    def create_tabs():
        tabs = ft.Row(
            [
                create_tab(text="My Selections", icon_path="gg.png", on_click=tab_clicked),
                create_tab(text="List Details", icon_path="hh.png", on_click=tab_clicked),
                create_tab(text="Add Item", icon_path="ii.png", on_click=tab_clicked),
                create_tab(text="Save Item", icon_path="jj.png", on_click=tab_clicked),
                create_tab(text="Delete Item", icon_path="kk.png", on_click=tab_clicked),
                create_tab(text="Contact Us", icon_path="ll.png", on_click=tab_clicked),
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=0,
            width=1200
        )
        return tabs

    # Create the layout
    layout_column = ft.Column(
        controls=[create_app_title(), create_tabs()],
        spacing=0
    )

    page.add(layout_column, content_container)

ft.app(target=main)