import flet as ft

def main(page: ft.Page):
    page.title = "圆形波浪进度条"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    wave_color = ft.colors.LIGHT_BLUE

    large_wave = ft.Container(
        width=200,  # 调整为与容器相同的宽度
        height=200,  # 调整为与容器相同的高度
        bgcolor=wave_color,
        border_radius=100,  # 调整为与容器相同的半径
        offset=ft.Offset(-0.20, 0.95),  # 初始位置
        animate_offset=ft.Animation(500, "easeInOut"),
    )

    small_wave = ft.Container(
        width=3040,  # 保持增大的宽度
        height=3040,  # 保持增大的高度
        bgcolor=wave_color,
        border_radius=1520,  # 保持增大的半径
        offset=ft.Offset(0.30, 1.05),  # 初始位置
        animate_offset=ft.Animation(500, "easeInOut"),
    )

    text = ft.Text(
        "0%",
        size=30,
        weight=ft.FontWeight.BOLD,
        color=ft.colors.WHITE,
    )

    container = ft.Container(
        width=200,  # 保持不变
        height=200,  # 保持不变
        border_radius=100,  # 保持不变
        bgcolor=ft.colors.GREY_200,
        border=ft.Border(
            left=ft.BorderSide(5, wave_color),
            top=ft.BorderSide(5, wave_color),
            right=ft.BorderSide(5, wave_color),
            bottom=ft.BorderSide(5, wave_color),
        ),
        alignment=ft.alignment.center,
        clip_behavior=ft.ClipBehavior.HARD_EDGE,  # 限制波浪在圆圈内
        content=ft.Stack(
            [
                large_wave,
                small_wave,
                ft.Container(
                    content=text,
                    alignment=ft.alignment.center
                ),
            ]
        ),
    )

    def update_wave(value):
        # 更新波浪位置
        x_offset_adjustment = 0.2 * (value / 100)  # 100%时右移200个单位
        y_offset_adjustment = 0.050 * (value / 100)  # 100%时下移5.0个单位
        large_wave.offset = ft.Offset(-0.20 + x_offset_adjustment, 0.95 - value / 100 + y_offset_adjustment)
        small_wave.offset = ft.Offset(0.30 + x_offset_adjustment, 1.05 - value / 100 * 1.2 + y_offset_adjustment)
        text.value = f"{int(value)}%"
        page.update()

    slider = ft.Slider(
        min=0,
        max=100,
        value=0,
        on_change=lambda e: update_wave(e.control.value),
    )

    page.add(container, slider)

ft.app(target=main)