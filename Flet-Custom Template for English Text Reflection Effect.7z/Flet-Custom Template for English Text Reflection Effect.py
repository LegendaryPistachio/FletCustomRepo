import flet as ft
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import base64

# Function to create reflection effect
def create_reflected_text(text: str, font_family: str, font_size: int, text_color: tuple, background_color: tuple, gap: int):
    # Use the MISTRAL.TTF font path in the root directory
    font_path = "MISTRAL.TTF"
    
    # Print the font file path for debugging
    print(f"Font path: {font_path}")
    
    # Load the font
    try:
        font = ImageFont.truetype(font_path, font_size)
    except OSError as e:
        print(f"Error loading font: {e}")
        return None
    
    # Get the text dimensions
    text_bbox = font.getbbox(text)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    
    # Create the original text image
    original_image = Image.new('RGBA', (text_width, text_height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(original_image)
    draw.text((0, 0), text, fill=text_color, font=font)
    
    # Create the reflection image
    reflected_image = original_image.transpose(Image.FLIP_TOP_BOTTOM)
    
    # Create the final image
    total_height = text_height * 2 + gap
    final_image = Image.new('RGBA', (text_width, total_height), background_color)
    
    # Paste the original text
    final_image.paste(original_image, (0, 0), original_image)
    
    # Paste the reflection text
    final_image.paste(reflected_image, (0, text_height + gap), reflected_image)
    
    # Create the mask
    mask = Image.new('L', (text_width, total_height), 255)
    mask_draw = ImageDraw.Draw(mask)
    for i in range(text_height):
        alpha = int(255 * (1 - i / text_height))
        mask_draw.line([(0, text_height + gap + i), (text_width, text_height + gap + i)], fill=alpha)
    
    # Apply the mask
    final_image.putalpha(mask)
    
    return final_image

# Main function
def main(page: ft.Page):
    # Set the page title
    page.title = "Text Reflection Example"
    
    # Create the reflected text image
    text = "Hello, Flet"
    font_family = "MISTRAL.TTF"  # Use MISTRAL.TTF font
    font_size = 150
    text_color = (0, 102, 204)  # blue-500
    background_color = (255, 255, 255)  # white
    gap = 10  # Gap between text and reflection
    
    image = create_reflected_text(text, font_family, font_size, text_color, background_color, gap)
    
    if image is None:
        print("Failed to create reflected text image")
        return
    
    # Convert the image to a byte stream
    byte_arr = BytesIO()
    image.save(byte_arr, format='PNG')
    byte_arr.seek(0)
    
    # Convert the byte stream to a base64 encoded string
    img_base64 = base64.b64encode(byte_arr.read()).decode('utf-8')
    
    # Create the Flet image component
    img = ft.Image(src_base64=img_base64, width=image.width, height=image.height)
    
    # Add the image to the page
    page.add(img)

# Run the application
if __name__ == "__main__":
    ft.app(target=main)