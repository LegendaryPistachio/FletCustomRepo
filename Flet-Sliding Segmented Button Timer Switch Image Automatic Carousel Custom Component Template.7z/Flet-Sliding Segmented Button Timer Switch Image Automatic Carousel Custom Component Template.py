import flet as ft
import asyncio
import os

# Image resource list
image_paths = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg",
    "image6.jpg",
    "image7.jpg",
]

# Check if image files exist
for path in image_paths:
    if not os.path.exists(path):
        print(f"Image file {path} does not exist.")


# Main function, marked as asynchronous
async def main(page: ft.Page):
    page.title = "Image Carousel"
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"

    # Current image index
    current_image_index = 0

    # Image display area, set width and height
    image = ft.Image(
        src=image_paths[current_image_index],
        width=1200,
        height=600,
        fit=ft.ImageFit.CONTAIN,
    )
    print(f"Initial image source: {image.src}")  # Debug information

    # Custom button list
    def change_image_callback(index):
        nonlocal current_image_index
        current_image_index = index
        change_image(page, image, segmented_control, current_image_index)

    # Create CupertinoSlidingSegmentedButton
    segmented_control = ft.CupertinoSlidingSegmentedButton(
        selected_index=current_image_index,
        thumb_color=ft.colors.BLUE_400,
        on_change=lambda e: change_image_callback(int(e.data)),
        padding=ft.padding.symmetric(0, 10),
        controls=[
            ft.Container(
                content=ft.Text(f"{i+1}"),
                width=100,  # Set the width of each button
                alignment=ft.alignment.center,
            )
            for i in range(len(image_paths))
        ],
    )

    # Use Stack to overlay image and button group
    stack = ft.Stack(
        [
            image,
            ft.Container(
                content=segmented_control,
                alignment=ft.alignment.bottom_center,
                margin=ft.Margin(
                    0, 0, 0, 50
                ),  # Adjust the bottom margin of the button group
            ),
        ],
        alignment=ft.alignment.center,
    )  # Ensure Stack content is centered

    # Use Container to set Stack alignment
    container = ft.Container(content=stack, alignment=ft.alignment.center, expand=True)

    # Page layout
    page.add(container)

    # Timer for automatic carousel
    async def auto_rotate():
        nonlocal current_image_index
        while True:
            if current_image_index < len(image_paths) - 1:
                current_image_index += 1
            else:
                current_image_index = 0
            change_image(page, image, segmented_control, current_image_index)
            await asyncio.sleep(3)  # Switch images every 3 seconds

    # Start automatic carousel
    page.run_task(auto_rotate)  # Pass the function itself, not call it


def change_image(page, image, segmented_control, index):
    image.src = image_paths[index]
    print(f"Changing image source to: {image.src}")  # Debug information

    # Update button color
    segmented_control.selected_index = index
    page.update()


ft.app(main)
