import flet as ft

def main(page: ft.Page):
    page.title = "Flet缓出缩小动画示例自定义模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.spacing = 20

    # 定义缓出动画
    scale_out_animation = ft.Animation(duration=1000, curve=ft.AnimationCurve.EASE_OUT)

    # 创建一个容器，用于显示动画效果
    container = ft.Container(
        width=100,
        height=100,
        bgcolor=ft.Colors.BLUE,
        animate_scale=scale_out_animation,
        scale=1,  # 初始缩放为1
    )

    # 创建一个图片控件
    image = ft.Image(
        src="logo.png",
        width=100,
        height=100,
        fit=ft.ImageFit.CONTAIN,
    )

    # 创建一个列容器来包含图片
    content_column = ft.Column(
        controls=[image],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=5,
    )

    # 将列容器添加到主容器中
    container.content = content_column

    # 创建一个按钮，用于启动缓出动画
    scale_out_button = ft.ElevatedButton(
        text="启动缓出动画",
        on_click=lambda e: start_scale_out_animation(container)
    )

    # 创建一个列容器来包含容器和按钮
    column = ft.Column(
        controls=[container, scale_out_button],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
    )

    # 将列容器添加到页面中
    page.add(column)


def start_scale_out_animation(container: ft.Container):
    # 设置动画为缓出动画
    container.animate_scale = ft.Animation(duration=1000, curve=ft.AnimationCurve.EASE_OUT)
    # 由大变小的缓出缩放动画
    container.scale = 0
    container.update()

ft.app(target=main)