import flet as ft


def main(page: ft.Page):
    page.title = "Flet缓入放大动画示例自定义模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.spacing = 20

    # 定义缓入动画
    animation = ft.Animation(duration=1000, curve=ft.AnimationCurve.EASE_IN)

    # 创建一个容器，用于显示动画效果
    container = ft.Container(
        width=100,
        height=100,
        bgcolor=ft.Colors.BLUE,
        animate_scale=animation,
        scale=0,  # 初始缩放为0
    )

    # 创建一个图片控件
    image = ft.Image(
        src="logo.png",
        width=100,
        height=100,
        fit=ft.ImageFit.CONTAIN,
    )

    # 创建一个列容器来包含图片
    content_column = ft.Column(
        controls=[image],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=5,
    )

    # 将列容器添加到主容器中
    container.content = content_column

    # 创建一个按钮，用于启动动画
    button = ft.ElevatedButton(
        text="启动缓入动画", on_click=lambda e: start_animation(container)
    )

    # 创建一个列容器来包含容器和按钮
    column = ft.Column(
        controls=[container, button],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
    )

    # 将列容器添加到页面中
    page.add(column)


def start_animation(container: ft.Container):
    # 由小变大的缓入缩放动画
    container.scale = 1
    container.update()


ft.app(target=main)
