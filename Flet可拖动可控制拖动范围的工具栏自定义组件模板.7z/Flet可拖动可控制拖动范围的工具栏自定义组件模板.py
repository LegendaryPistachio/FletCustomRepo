import flet as ft


def main(page: ft.Page):
    page.title = "Flet可拖动可控制拖动范围的工具栏自定义组件模板"

    def on_pan_update1(e: ft.DragUpdateEvent):
        new_top = c.top + e.delta_y
        new_left = c.left + e.delta_x
        c.top = max(0, min(new_top, 200))  # 200 是顶部的最大值，确保容器不超出底部
        c.left = max(0, min(new_left, 900))  # 900 是左侧的最大值，确保容器不超出右侧
        c.update()

    def on_pan_update2(e: ft.DragUpdateEvent):
        new_top = e.control.top + e.delta_y
        new_left = e.control.left + e.delta_x
        e.control.top = max(
            0, min(new_top, 200)
        )  # 200 是顶部的最大值，确保容器不超出底部
        e.control.left = max(
            0, min(new_left, 900)
        )  # 900 是左侧的最大值，确保容器不超出右侧
        e.control.update()

    # 创建一个水平排列的图标按钮行
    icon_buttons = ft.Row(
        [
            ft.IconButton(icon=ft.Icons.DRAG_INDICATOR, tooltip="Favorite"),
            ft.IconButton(icon=ft.Icons.SEARCH, tooltip="Search"),
            ft.IconButton(icon=ft.Icons.SETTINGS, tooltip="Settings"),
            ft.IconButton(icon=ft.Icons.INFO, tooltip="Info"),
            ft.IconButton(icon=ft.Icons.HOME, tooltip="Home"),
        ],
        alignment=ft.MainAxisAlignment.START,  # 水平左对齐
        spacing=0,
    )

    gd = ft.GestureDetector(
        mouse_cursor=ft.MouseCursor.MOVE,
        drag_interval=50,
        on_pan_update=on_pan_update1,
        content=ft.Container(
            icon_buttons,
            bgcolor=ft.Colors.AMBER,
            width=300,
            height=50,
            padding=0,
            alignment=ft.alignment.center,  # 垂直居中对齐
        ),
    )

    c = ft.Container(gd, left=0, top=0)

    # 创建另一个水平排列的图标按钮行
    icon_buttons_blue = ft.Row(
        [
            ft.IconButton(icon=ft.Icons.DRAG_INDICATOR, tooltip="Favorite"),
            ft.IconButton(icon=ft.Icons.SEARCH, tooltip="Search"),
            ft.IconButton(icon=ft.Icons.SETTINGS, tooltip="Settings"),
            ft.IconButton(icon=ft.Icons.INFO, tooltip="Info"),
            ft.IconButton(icon=ft.Icons.HOME, tooltip="Home"),
        ],
        alignment=ft.MainAxisAlignment.START,  # 水平左对齐
        spacing=0,
    )

    gd1 = ft.GestureDetector(
        mouse_cursor=ft.MouseCursor.MOVE,
        drag_interval=10,
        on_vertical_drag_update=on_pan_update2,
        left=100,
        top=100,
        content=ft.Container(
            icon_buttons_blue,
            bgcolor=ft.Colors.BLUE,
            width=300,
            height=50,
            padding=0,
            alignment=ft.alignment.center,  # 垂直居中对齐
        ),
    )

    page.add(ft.Stack([c, gd1], width=1200, height=500))


ft.app(target=main)
