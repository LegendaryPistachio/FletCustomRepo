# main.py
import subprocess
import flet as ft


def start_child1_win(event):
    # 传递 -Xfrozen_modules=off 参数以禁用冻结模块
    subprocess.Popen(["python", "-Xfrozen_modules=off", "child1.py"])


def start_child2_win(event):
    # 传递 -Xfrozen_modules=off 参数以禁用冻结模块
    subprocess.Popen(["python", "-Xfrozen_modules=off", "child2.py"])


def main(page: ft.Page):
    page.title = "主界面-flet多进程管理独立多窗口的桌面程序框架自定义组件模板"
    page.add(
        ft.TextButton(text="启动子界面1", on_click=start_child1_win),
        ft.TextButton(text="启动子界面2", on_click=start_child2_win),
    )


ft.app(target=main)
