# child1.py
import flet as ft


def main(page: ft.Page):
    page.title = "子界面1"
    page.window.always_on_top = True  # 确保子窗口始终在最上层

    # 添加文本控件
    text_control = ft.Text("这是子界面1")
    page.add(text_control)


ft.app(target=main)
