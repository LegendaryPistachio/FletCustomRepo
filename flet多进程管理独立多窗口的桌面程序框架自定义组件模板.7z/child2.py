# child2.py
import flet as ft


def main(page: ft.Page):
    page.title = "子界面2"
    page.window.always_on_top = True
    text_control = ft.Text("这是子界面2")
    page.add(text_control)


ft.app(target=main)
