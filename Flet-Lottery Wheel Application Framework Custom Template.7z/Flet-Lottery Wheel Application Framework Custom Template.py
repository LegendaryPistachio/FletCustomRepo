import os
import flet as ft
import random
import time
from threading import Thread
import json

def main(page: ft.Page):
    page.title = "Lottery Wheel"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 50
    page.update()

    # List of image filenames
    image_paths = [
        'desktop computer.jpg',
        'smartphone2.jpg',
        'smartearbuds2.jpg',
        'laptop.jpg',
        'start.jpg',
        'smartband1.jpg',
        'smartband2.jpg',  
        'smartphone1.jpg',
        'smartphone3.jpg'
    ]

    # List of participants
    participants = [
        "Zhang San", "Li Si", "Wang Wu", "Zhao Liu", "Sun Qi", "Zhou Ba",
        "Wu Jiu", "Zheng Shi", "Qian Shiyi", "Chen Shier", "Yang Shisan", "Huang Shisi"
    ]

    # Get the current working directory
    current_dir = os.getcwd()

    # Define uniform button width and height
    button_width = 150
    button_height = 150

    # Reduce image width and height by 40 pixels (reduce 20 pixels based on the original 20 pixels reduction)
    image_width = button_width - 40
    image_height = button_height - 40

    # Load local images
    image_buttons = []
    for idx, image_name in enumerate(image_paths):
        image_path = os.path.join(current_dir, image_name)  # Concatenate to full path

        image_button = ft.ElevatedButton(
            content=ft.Image(
                src=image_path,  # Use full path
                fit=ft.ImageFit.COVER,  # Use COVER to fill the entire button
                repeat=ft.ImageRepeat.NO_REPEAT,
                border_radius=ft.border_radius.all(10),
                width=image_width,  # Set image width
                height=image_height  # Set image height
            ),
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10),
                padding=0,  # Ensure no padding
                overlay_color={
                    ft.ControlState.PRESSED: ft.Colors.BLUE,  # Color when pressed
                    ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE,  # Color when hovered
                    ft.ControlState.DEFAULT: ft.Colors.TRANSPARENT  # Default state color
                }
            ),
            width=button_width,  # Set button width
            height=button_height,  # Set button height
            on_click=lambda e, name=image_name, idx=idx: start_lottery(e, name, idx),  # Add click event
            data=idx  # Set button ID
        )
        image_buttons.append(image_button)

    # Manually layout image buttons using Column and Row components
    rows = []
    for i in range(0, len(image_buttons), 3):
        row = ft.Row(
            controls=image_buttons[i:i+3],
            spacing=5,
            alignment=ft.MainAxisAlignment.CENTER
        )
        rows.append(row)

    column = ft.Column(
        controls=rows,
        spacing=5,
        alignment=ft.MainAxisAlignment.CENTER
    )

    # Wrap the Column in a Container and set the border
    grid_container = ft.Container(
        content=column,
        border=ft.border.all(2, ft.Colors.BLUE),  # Add blue border
        padding=10,  # Optional: add padding
        border_radius=ft.border_radius.all(10),  # Optional: add rounded corners
        width=485,  # Increase width by 5
        height=500  # Manually set height, adjust as needed
    )

    # Create a new ListView component
    list_view = ft.ListView(
        expand=1,
        spacing=10,
        padding=10
    )

    # Initial display message
    initial_message = ft.Text("Display lottery results here", size=18, color=ft.Colors.BLACK, weight=ft.FontWeight.BOLD)
    list_view.controls.append(initial_message)

    # Wrap the ListView in a Container and set the border
    list_container = ft.Container(
        content=list_view,
        border=ft.border.all(1, ft.Colors.BLUE),  # Change to blue border
        padding=10,  # Optional: add padding
        border_radius=ft.border_radius.all(10),  # Optional: add rounded corners
        height=500,  # Set the same height as grid_container
        expand=True  # Let the container expand to maximum width
    )

    # Use a Row component to horizontally arrange two containers
    row_container = ft.Row(
        controls=[
            grid_container,
            list_container
        ],
        alignment=ft.MainAxisAlignment.START,  # Left align
        vertical_alignment=ft.CrossAxisAlignment.START  # Top align
    )

    # Wrap the Row in a Container and set the background color
    container_with_row = ft.Container(
        content=row_container,
        bgcolor=ft.Colors.YELLOW  # Add yellow background color for debugging
    )

    page.add(container_with_row)
    page.update()

    last_winner_button = None  # To record the last winning button

    # Initialize lottery data
    data = load_data()
    current_round = len(data["rounds"]) + 1
    current_round_data = {
        "round": current_round,
        "draw_count": 0,
        "results": []
    }
    data["rounds"].append(current_round_data)
    save_data(data)

    def simulate_hover(buttons):
        nonlocal last_winner_button  # Use external variable

        # Calculate additional wait time to make the total time between 30 and 40 seconds
        extra_wait_time = random.uniform(20, 30)  # Randomly generate an additional wait time between 20 and 30 seconds

        for _ in range(10):  # Simulate 10 hovers
            button = random.choice(buttons)
            # Simulate mouse hover
            button.style.bgcolor = ft.Colors.LIGHT_BLUE
            page.update()
            time.sleep(0.5)  # Pause for 0.5 seconds

            # Simulate mouse leave
            button.style.bgcolor = ft.Colors.TRANSPARENT
            page.update()
            time.sleep(0.5)  # Pause for 0.5 seconds

        # Randomly select a button as the winning button
        winner_button = random.choice(buttons)
        winner_button.style.bgcolor = ft.Colors.LIGHT_BLUE
        page.update()

        # Randomly select a winning participant
        winner_name = random.choice(participants)

        # Display winning information
        winner_image = os.path.basename(winner_button.content.src)  # Extract image name
        result_text = f"{winner_name} wins {os.path.splitext(winner_image)[0]}"  # Modify to display only the image name
        list_view.controls.append(ft.Text(result_text, size=18, color=ft.Colors.RED))
        list_view.update()

        # Update lottery data
        current_round_data["draw_count"] += 1
        current_round_data["results"].append(result_text)
        save_data(data)

        # Record the winning button
        last_winner_button = winner_button

        # Add additional wait time
        time.sleep(extra_wait_time)

    def start_lottery(e, image_name, idx):
        if idx == 4:  # Ensure it is the fifth button
            # Cancel the last winning hover
            if last_winner_button:
                last_winner_button.style.bgcolor = ft.Colors.TRANSPARENT
                page.update()

            # Check the number of draws in the current round
            if current_round_data["draw_count"] < 5:
                # Create a thread to simulate mouse hover and leave
                thread = Thread(target=simulate_hover, args=(image_buttons,))
                thread.start()
            else:
                # The number of draws has reached the limit, display a prompt message
                list_view.controls.append(ft.Text("This round of the lottery has ended", size=18, color=ft.Colors.RED))
                list_view.update()

    def reset_lottery(e):
        nonlocal current_round_data
        nonlocal current_round  # Declare current_round as a variable in the outer scope
        # Reset lottery status
        if last_winner_button:
            last_winner_button.style.bgcolor = ft.Colors.TRANSPARENT
            page.update()

        # Start a new round
        current_round += 1
        current_round_data = {
            "round": current_round,
            "draw_count": 0,
            "results": []
        }
        data["rounds"].append(current_round_data)
        save_data(data)

        # Clear the result list
        list_view.controls.clear()
        list_view.controls.append(initial_message)
        list_view.update()

    # Add a reset button
    reset_button = ft.ElevatedButton(
        text="Reset Lottery",
        on_click=reset_lottery
    )

    # Add the reset button to the page
    page.add(reset_button)
    page.update()

def load_data():
    try:
        with open('data.json', 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        return {"rounds": []}

def save_data(data):
    with open('data.json', 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)

ft.app(main)