import flet as ft


def main(page: ft.Page):
    page.title = "AnimatedSwitcher SCALE Demo"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    toggle = False  # Directly use Python variable

    # Define two containers
    container1 = ft.Container(
        key="1",
        width=200,
        height=200,
        bgcolor=ft.Colors.BLUE,
        alignment=ft.alignment.center,
        content=ft.Text("Page 1", color=ft.Colors.WHITE, size=24),
    )

    container2 = ft.Container(
        key="2",
        width=200,
        height=200,
        bgcolor=ft.Colors.RED,
        alignment=ft.alignment.center,
        content=ft.Text("Page 2", color=ft.Colors.WHITE, size=24),
    )

    def animate(e):
        nonlocal toggle  # Declare to use the external variable
        toggle = not toggle
        animated_content.content = container1 if toggle else container2
        page.update()

    # Define animated switching content
    animated_content = ft.AnimatedSwitcher(
        content=container1,  # Initial content
        transition=ft.AnimatedSwitcherTransition.SCALE,  # Use scale transition
        duration=500,  # Animation duration (milliseconds)
        switch_in_curve=ft.AnimationCurve.EASE_IN_OUT,  # Entrance animation curve
        switch_out_curve=ft.AnimationCurve.EASE_IN_OUT,  # Exit animation curve
    )

    # Force an update once to ensure the initial state is correct
    page.update()

    # Add column to the page
    page.add(
        ft.Column(
            [animated_content, ft.ElevatedButton("Switch Page", on_click=animate)],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )
    )

    # Force an update once to ensure the initial state is correct
    page.update()

    # Manually trigger the animation once to ensure the animation starts on the first click
    animate(None)


ft.app(target=main)
