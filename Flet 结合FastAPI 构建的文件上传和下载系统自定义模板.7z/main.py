import flet as ft
import os
import asyncio
from fastapi import FastAPI, File, UploadFile, Request
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from threading import Thread
import aiohttp

# 确保目录存在
os.makedirs("./assets/dl", exist_ok=True)
os.makedirs("./assets/uploads", exist_ok=True)

# 直接在代码中设置环境变量 PORT
os.environ["PORT"] = "8080"

# 增加文件大小限制
app = FastAPI(limits={"max_content_length": 100 * 1024 * 1024})  # 100 MB

# 允许跨域请求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/dl/{filename}")
async def dl_file(filename: str):
    res = "./assets/dl/" + filename
    if not os.path.exists(res):
        return {"error": "File not found"}, 404
    return FileResponse(res)


@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    with open(os.path.join("./assets/uploads", file.filename), "wb") as buffer:
        buffer.write(await file.read())
    return {"filename": file.filename}


def main(page: ft.Page):

    ############################################### 文件上传模块 ################################################################
    prog_bars: dict[str, ft.ProgressRing] = {}
    files = ft.Ref[ft.Column]()
    upload_button = ft.Ref[ft.ElevatedButton]()

    def file_picker_result(e: ft.FilePickerResultEvent):
        upload_button.current.disabled = True if e.files is None else False
        prog_bars.clear()
        files.current.controls.clear()
        if e.files is not None:
            for f in e.files:
                prog = ft.ProgressRing(value=0, bgcolor="#eeeeee", width=20, height=20)
                prog_bars[f.name] = prog
                files.current.controls.append(ft.Row([prog, ft.Text(f.name)]))
        page.update()

    def on_upload_progress(e: ft.FilePickerUploadEvent):
        prog_bars[e.file_name].value = e.progress
        prog_bars[e.file_name].update()

    file_picker = ft.FilePicker(
        on_result=file_picker_result, on_upload=on_upload_progress
    )

    async def upload_files(e):
        uf = []
        if file_picker.result is not None and file_picker.result.files is not None:
            for f in file_picker.result.files:
                uf.append(
                    ft.FilePickerUploadFile(
                        f.name,
                        upload_url="http://127.0.0.1:8080/upload/",
                        method="POST",  # 设置上传方法为 POST
                    )
                )
            file_picker.upload(uf)
            files.current.controls.clear()
            await asyncio.sleep(2)  # 使用异步等待
            page.update()

    async def custom_upload_files(e):
        if file_picker.result is not None and file_picker.result.files is not None:
            for f in file_picker.result.files:
                prog = prog_bars[f.name]
                async with aiohttp.ClientSession() as session:
                    form_data = aiohttp.FormData()
                    with open(f.path, "rb") as file:
                        form_data.add_field("file", file, filename=f.name)
                        async with session.post(
                            "http://127.0.0.1:8080/upload/", data=form_data
                        ) as response:
                            if response.status == 200:
                                prog.value = 100
                                prog.update()
                                page.update()
                            else:
                                prog.value = 0
                                prog.update()
                                page.update()

    # hide dialog in a overlay
    page.overlay.append(file_picker)

    #########################################################################################################################################
    def clear(e):  # 添加参数 e
        path = "./assets/uploads"
        for i in os.listdir(path):
            file_path = os.path.join(path, i)
            os.unlink(file_path)

    def down(e):
        # 假设你要下载的文件名为 "1.xlsx"
        filename = "1.xlsx"
        page.launch_url(f"http://127.0.0.1:8080/dl/{filename}")

    btn = ft.ElevatedButton(text="clear", on_click=clear)  # 传递函数引用
    d_b = ft.ElevatedButton(text="Download", on_click=down)  # 传递函数引用

    ######################################### page组件添加 ########################################################################################
    page.add(
        ft.ElevatedButton(
            "Select files...",
            icon=ft.Icons.FOLDER_OPEN,  # 修改这里
            on_click=lambda _: file_picker.pick_files(allow_multiple=True),
        ),
        ft.Column(ref=files),
        ft.ElevatedButton(
            "Upload",
            ref=upload_button,
            icon=ft.Icons.UPLOAD,  # 修改这里
            on_click=custom_upload_files,
            disabled=True,
        ),
        btn,
        d_b,
    )


def check_globals():
    for key, value in globals().items():
        if key == "port":
            print(
                f"Global variable 'port' found with value: {value}, type: {type(value)}"
            )


def run_fastapi():
    fastapi_port_value = int(os.getenv("PORT", 8000))  # 使用环境变量 PORT，默认 8000
    print(f"Environment variable 'PORT': {os.getenv('PORT')}")
    print(
        f"Type of fastapi_port_value: {type(fastapi_port_value)}, Value of fastapi_port_value: {fastapi_port_value}"
    )
    print(globals())  # 打印全局命名空间
    assert isinstance(
        fastapi_port_value, int
    ), f"fastapi_port_value must be an integer, got {type(fastapi_port_value)}"
    print(f"Running FastAPI on port: {fastapi_port_value}")  # 打印 port 值
    uvicorn.run(app, host="127.0.0.1", port=fastapi_port_value)


if __name__ == "__main__":
    check_globals()

    fastapi_thread = Thread(target=run_fastapi)
    fastapi_thread.start()

    # 在主线程中启动 Flet 应用
    ft.app(target=main, assets_dir="assets", upload_dir="assets/uploads", port=8550)

    fastapi_thread.join()
