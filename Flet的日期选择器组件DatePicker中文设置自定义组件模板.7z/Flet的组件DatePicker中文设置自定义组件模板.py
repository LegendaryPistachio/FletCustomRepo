import datetime
import flet as ft


def main(page: ft.Page):
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def handle_change(e):
        # 将日期格式化为中文格式
        formatted_date = e.control.value.strftime("%Y年%m月%d日")
        page.add(ft.Text(f"日期变更：{formatted_date}"))

    def handle_dismissal(e):
        page.add(ft.Text("日期选择器已关闭"))

    page.add(
        ft.ElevatedButton(
            "选择日期",
            icon=ft.Icons.CALENDAR_MONTH,
            on_click=lambda e: page.open(
                ft.DatePicker(
                    first_date=datetime.datetime(year=2023, month=10, day=1),
                    last_date=datetime.datetime(year=2024, month=10, day=1),
                    on_change=handle_change,
                    on_dismiss=handle_dismissal,
                    cancel_text="取消",  # 将取消按钮文本设置为中文
                    confirm_text="确定",  # 将确认按钮文本设置为中文
                    help_text="请选择日期",  # 帮助文本设置为中文
                    field_label_text="输入日期",  # TextField标签设置为中文
                    field_hint_text="请输入日期",  # TextField提示设置为中文
                    # 以下两行代码用于设置错误信息为中文
                    error_format_text="格式不正确",
                    error_invalid_text="超出范围",
                )
            ),
        )
    )


ft.app(main)
