import flet as ft


def create_table(
    headers,
    rows_data,
    col_widths=None,
    row_height=None,
    bgcolor=ft.Colors.TRANSPARENT,
    border_color=ft.Colors.GREY,
):
    if not col_widths:
        col_widths = [None] * len(headers)

    if not row_height:
        row_height = 30

    def create_row(cells, is_header=False):
        return ft.Row(
            controls=[
                ft.Container(
                    content=(
                        cell if isinstance(cell, ft.Control) else ft.Text(str(cell))
                    ),
                    width=col_width if col_width else None,
                    height=row_height,
                    alignment=ft.alignment.center,
                    bgcolor=ft.Colors.TRANSPARENT if is_header else bgcolor,
                    border=ft.border.all(1, border_color),
                    padding=5,
                )
                for cell, col_width in zip(cells, col_widths)
            ],
            spacing=0,
            vertical_alignment=ft.MainAxisAlignment.CENTER,
        )

    header_row = create_row(headers, is_header=True)
    data_rows = [create_row(row) for row in rows_data]

    return ft.Column(
        [header_row, *data_rows],
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        spacing=0,
    )


def main(page: ft.Page):
    page.title = "Flet Table Example"

    headers = ["ID", "Name", "Age"]
    rows_data = [[1, "Alice", 30], [2, "Bob", 25], [3, "Charlie", 35]]

    # Set the specific width for each column
    col_widths = [50, 150, 100]  # Adjust these values as needed

    table = create_table(headers, rows_data, col_widths=col_widths)

    page.add(table)


if __name__ == "__main__":
    ft.app(target=main)
