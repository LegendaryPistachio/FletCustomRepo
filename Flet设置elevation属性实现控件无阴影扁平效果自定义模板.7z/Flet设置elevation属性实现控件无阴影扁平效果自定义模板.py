import flet as ft


def main(page: ft.Page):
    page.title = "Flet设置elevation属性实现控件无阴影扁平效果自定义模板"
    # 创建一个没有阴影的 ElevatedButton
    no_shadow_button = ft.ElevatedButton(text="无阴影ElevatedButton按钮", elevation=0)

    # 创建一个没有阴影的 OutlinedButton
    no_shadow_outlined_button = ft.OutlinedButton(text="无阴影轮廓按钮")

    # 创建一个没有阴影的 FilledButton
    no_shadow_filled_button = ft.FilledButton(text="无阴影填充按钮")

    # 创建一个没有阴影的 Card
    card = ft.Card(
        content=ft.Container(
            content=ft.Text("无阴影卡片"), padding=10, alignment=ft.alignment.center
        ),
        elevation=0,
    )

    # 创建一个没有阴影的 FloatingActionButton
    fab = ft.FloatingActionButton(icon=ft.Icons.ADD, elevation=0)

    # 创建一个没有阴影的 AppBar
    app_bar = ft.AppBar(title=ft.Text("无阴影应用栏"), center_title=True, elevation=0)
    page.appbar = app_bar

    # 添加所有控件到页面
    page.add(
        no_shadow_button, no_shadow_outlined_button, no_shadow_filled_button, card, fab
    )


ft.app(target=main)
