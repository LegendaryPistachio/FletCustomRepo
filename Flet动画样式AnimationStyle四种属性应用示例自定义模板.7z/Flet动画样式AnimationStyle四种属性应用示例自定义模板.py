import flet as ft


def main(page: ft.Page):
    page.title = "Flet动画样式AnimationStyle四种属性应用示例自定义模板"
    # 创建一个动画对象，设置正向的曲线及持续时间
    animation = ft.Animation(
        duration=2000,  # 正向动画持续时间
        curve=ft.AnimationCurve.EASE_IN_OUT,  # 正向动画曲线
    )

    reverse_animation = ft.Animation(
        duration=1000,  # 反向动画持续时间
        curve=ft.AnimationCurve.BOUNCE_OUT,  # 反向动画曲线
    )

    container = ft.Container(
        width=200,
        height=200,
        bgcolor=ft.Colors.BLUE,
        animate=animation,  # 使用定义的动画对象
        on_click=lambda e: toggle_animation(e),
    )
    page.add(container)

    def toggle_animation(e):
        if e.control.width == 200:
            e.control.width = 300
            e.control.bgcolor = ft.Colors.GREEN
            e.control.animate = animation
        else:
            e.control.width = 200
            e.control.bgcolor = ft.Colors.BLUE
            e.control.animate = reverse_animation
        e.control.update()

    page.update()


ft.app(target=main)
