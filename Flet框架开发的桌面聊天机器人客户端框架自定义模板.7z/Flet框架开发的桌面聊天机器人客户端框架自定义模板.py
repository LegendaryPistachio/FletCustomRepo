import flet as ft
import time
import os
import dashscope


class Layout_Alert(ft.AlertDialog):
    def __init__(
        self,
        page,
        mtitle=ft.Text("请先设置API-KEY"),
        mactions_alignment=ft.MainAxisAlignment.CENTER,
        modal=True,
    ):
        super().__init__()
        self.page = page
        self.content_padding = 15
        self.mtitle = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            controls=[
                ft.Row([mtitle]),
            ],
        )
        self.actions = [
            ft.TextButton("保存", on_click=self.save_keys),
            ft.TextButton("取消", on_click=self.handle_close),
        ]
        self.actions_alignment = ft.MainAxisAlignment.END
        old_api_key = self.page.client_storage.get("api_key")
        self.mcontent = ft.TextField(
            value=old_api_key if old_api_key else "",
            label="api_key",
            password=True,
            can_reveal_password=True,
        )
        self.mactions_alignment = mactions_alignment
        self.modal = modal
        self.title = self.mtitle
        self.content = self.mcontent

    def handle_close(self, e):
        self.page.close(self)

    def save_keys(self, e):
        api_key = self.mcontent.value
        self.page.client_storage.set("api_key", api_key)
        self.page.close(self)


class Right_Box(ft.Container):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.expand = 1
        self.border_radius = ft.border_radius.all(15)
        self.padding = 10
        self.foucs = None
        self.bgcolor = "#f8f7fe"
        # 初始化AI
        self.messages = [
            {"role": "system", "content": "you are a helpful assistant"},
        ]
        # 取得api_key
        # self.api_key = self.page.client_storage.get("api_key")
        self.question = ft.TextField(
            expand=1,
            multiline=True,  # 启用多行输入
            min_lines=1,  # 最小行数
            max_lines=2,  # 最大行数
            text_style=ft.TextStyle(size=14),  # 设置字体大小
            on_change=self.set_btn,
            border=ft.InputBorder.NONE,
            on_focus=self.get_focus,
            on_blur=self.get_focus,
        )
        self.main_list_view = ft.ListView(expand=True, auto_scroll=True, controls=[])
        self.send_btn = ft.IconButton(
            icon=ft.Icons.SEND_SHARP,
            icon_color="#efeff2",
            icon_size=25,
            disabled=True,
            on_click=self.send_message,
        )
        self.btn_box = ft.Container(
            border_radius=50,
            bgcolor="#d6d5de",
            content=self.send_btn,
        )
        # 提问容器
        self.input_box = ft.Container(
            padding=5,
            alignment=ft.alignment.center,
            border=ft.border.all(1, "#e8eaf2"),
            border_radius=10,
            content=ft.Row(
                [
                    self.question,
                    self.btn_box,
                ]
            ),
        )
        new_button = ft.Container(
            width=35,
            height=35,
            bgcolor="#615ced",
            border_radius=50,
            content=ft.IconButton(
                icon=ft.Icons.ADD,
                icon_color="white",
                icon_size=20,
                on_click=self.new_conversation,
                tooltip="新建对话",
            ),
        )
        self.content = ft.Column(
            controls=[
                # 头部
                ft.Row(
                    [
                        new_button,
                        ft.TextButton("通义千问 2.5"),
                    ]
                ),
                # 中部
                ft.Container(
                    expand=1,
                    alignment=ft.alignment.top_left,
                    content=ft.Column(
                        controls=[
                            self.main_list_view,
                        ]
                    ),
                ),
                # 底部
                self.input_box,
            ]
        )

    def new_conversation(self, e):
        self.main_list_view.controls.clear()
        self.page.update()
        self.messages = [
            {"role": "system", "content": "you are a helpful assistant"},
        ]

    def get_focus(self, e):
        self.foucs = e.name
        if self.foucs == "focus":
            self.input_box.border = ft.border.all(1, "#615ced")
            self.page.update()
            return
        if self.foucs == "blur" and len(self.question.value) <= 0:
            self.input_box.border = ft.border.all(1, "#e8eaf2")
            self.page.update()
            return

    def set_btn(self, e):
        q_value = self.question.value
        if len(q_value) >= 1:
            self.btn_box.bgcolor = "#615ced"
            self.send_btn.icon_color = "white"
            self.send_btn.disabled = False
        elif len(q_value) <= 0:
            self.btn_box.bgcolor = "#d6d5de"
            self.send_btn.icon_color = "#efeff2"
            self.send_btn.disabled = True
        self.page.update()

    def send_message(self, e):
        q = self.question.value
        if len(q) <= 2:
            return False
        ret = self.as_user_create_icon_markdown(q, "us", self.page)
        for item in ret:
            self.main_list_view.controls.append(item)
        self.question.value = ""
        self.public_display_info(q)

    def public_display_info(self, msg):
        # 新增一个空的控件，显示效果
        self.message = ft.Text(
            style=ft.TextThemeStyle.BODY_MEDIUM,  # 设置文本样式
        )
        public_content = ft.Container(
            padding=15,
            content=ft.Row(
                wrap=True,
                alignment=ft.MainAxisAlignment.START,
                controls=[
                    ft.Container(
                        border_radius=5,
                        content=ft.Column(
                            controls=[
                                self.message,
                            ],
                            spacing=10,
                        ),
                    )
                ],
            ),
        )
        public_content = ft.Card(content=public_content)
        self.main_list_view.controls.append(public_content)
        self.page.update()
        try:
            temp_msg = ""
            us_arr = {"role": "user", "content": msg}
            self.messages.append(us_arr)
            responses = dashscope.Generation.call(
                # 若没有配置环境变量，请用百炼API Key将下行替换为：api_key="sk-xxx",
                api_key=self.page.client_storage.get("api_key"),
                model="qwen-plus",
                messages=self.messages,
                result_format="message",
                stream=True,
                incremental_output=True,
            )
            for response in responses:
                is_stop = response["output"]["choices"][0]["finish_reason"]
                content = response["output"]["choices"][0]["message"]["content"]
                if is_stop == "null":
                    temp_msg = f"{temp_msg}{content}"
                    self.message.value = temp_msg
                    self.page.update()
            as_arr = {"role": "system", "content": temp_msg}
            self.messages.append(as_arr)

            if self.main_list_view.controls:
                # 删除最后一项
                del self.main_list_view.controls[-1]
                self.main_list_view.update()
            ret = self.as_user_create_icon_markdown(temp_msg, "as", self.page)
            for item in ret:
                self.main_list_view.controls.append(item)
            self.main_list_view.update()
            print(temp_msg)
        except Exception as e:
            dlg = ft.AlertDialog(
                title=ft.Text("请检API-KEY设置"),
                content=ft.Text(str(e)),
            )
            self.page.open(dlg)
            self.main_list_view.controls.clear()
            self.page.update()

    def handle_expansion_tile_change(self, e):
        if e.control.trailing:
            e.control.trailing.name = (
                ft.Icons.ARROW_DROP_DOWN
                if e.control.trailing.name == ft.Icons.ARROW_DROP_DOWN_CIRCLE
                else ft.Icons.ARROW_DROP_DOWN_CIRCLE
            )
            self.page.update()

    def as_user_create_icon_markdown(self, contents, moudles, page):
        if moudles == "as":
            as_icon_row = ft.Row(
                controls=[ft.Icon(name=ft.Icons.COMPUTER_SHARP, color=ft.Colors.BLUE)],
                alignment=ft.MainAxisAlignment.START,
            )
            as_mk = ft.Markdown(
                contents,
                selectable=True,
                extension_set="gitHubWeb",
                code_theme="atom-one-dark",
                code_style=ft.TextStyle(font_family="Roboto Mono"),
                on_tap_link=lambda e: page.launch_url(e.data),
            )
            card = ft.Card(margin=5, content=as_mk)
            pull_down = ft.ExpansionTile(
                title=ft.Text("assistant"),
                # subtitle=ft.Text("Leading expansion arrow icon"),
                affinity=ft.TileAffinity.LEADING,
                initially_expanded=True,
                collapsed_text_color=ft.Colors.BLUE,
                text_color=ft.Colors.BLUE,
                controls=[
                    ft.ListTile(title=ft.ListTile(title=card)),
                ],
            )
            return [as_icon_row, pull_down]
        if moudles == "us":
            us_icon_row = ft.Row(
                controls=[
                    ft.Icon(name=ft.Icons.PEOPLE_ALT_SHARP, color=ft.Colors.BLACK)
                ],
                alignment=ft.MainAxisAlignment.END,
            )
            right_content = ft.Container(
                padding=15,
                content=ft.Row(
                    wrap=True,
                    alignment=ft.MainAxisAlignment.END,
                    controls=[
                        ft.Container(
                            border_radius=5,
                            content=ft.Column(
                                controls=[
                                    # 设置Text控件以适应容器
                                    ft.Text(
                                        value=contents,
                                        style=ft.TextThemeStyle.BODY_MEDIUM,  # 设置文本样式
                                    ),
                                ],
                                spacing=10,
                            ),
                        )
                    ],
                ),
            )
            right_content = ft.Card(
                content=right_content,
            )

            return [us_icon_row, right_content]


class Left_Nav(ft.Container):
    def __init__(self, page):
        super().__init__()
        self.page = page
        # self.expand=1
        self.alignment = ft.alignment.top_center
        self.width = 70
        self.bgcolor = "#8f74f3"
        self.alert = Layout_Alert(self.page)
        self.content = ft.Column(
            expand=1,
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                ft.Column(
                    spacing=1,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.IconButton(
                            icon=ft.Icons.AC_UNIT_SHARP,
                            icon_color="#e6e0fc",
                            icon_size=35,
                        ),
                        ft.Text(
                            "通义",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color="#e6e0fc",
                        ),
                    ],
                ),
                ft.Container(
                    alignment=ft.alignment.bottom_center,
                    # bgcolor="red",
                    expand=1,
                    content=ft.IconButton(
                        icon=ft.Icons.SETTINGS_OUTLINED,
                        icon_color="#e6e0fc",
                        icon_size=25,
                        on_click=self.open_layout,
                    ),
                ),
            ],
        )

    def open_layout(self, e):
        self.page.open(self.alert)


class Page_View(ft.Container):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.padding = 10
        self.expand = 1
        self.bgcolor = "#8f74f3"
        # self.bgcolor="#feeeee"
        self.left_view = Left_Nav(self.page)
        self.main_view = Right_Box(self.page)
        self.content = ft.Row(
            vertical_alignment=ft.CrossAxisAlignment.START,
            controls=[
                # 左侧列
                self.left_view,
                self.main_view,
            ],
        )


def main(page: ft.Page):
    page.fonts = {
        "Roboto Mono": "RobotoMono-VariableFont_wght.ttf",
    }
    # 创建主页面布局
    page.window.height = 800
    page.window.width = 650
    page.padding = 1
    page.title = "通义千问(flet==0.25.1) by--吖嗪"
    pv = Page_View(page)
    page.add(pv)


ft.app(target=main)
