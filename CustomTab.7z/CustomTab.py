import flet as ft

class CustomTab:
    def __init__(self, text, icon_path, on_click=None):
        self.text = text
        self.icon_path = icon_path
        self.on_click = on_click

    def build(self):
        # Create a row to display the icon
        image_row = ft.Row(
            [ft.Image(src=self.icon_path, width=64, height=64)],
            alignment=ft.MainAxisAlignment.CENTER
        )
        # Create a row to display the text
        text_row = ft.Row(
            [ft.Text(self.text, color=ft.colors.WHITE, size=16)],
            alignment=ft.MainAxisAlignment.CENTER
        )
        # Create a column containing the icon and text
        container = ft.Column(
            [image_row, text_row],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=5
        )
        return ft.Container(
            content=container,
            bgcolor=ft.colors.GREEN_500,
            height=128,
            width=128,
            border_radius=8,
            on_click=self.on_click
        )

def main(page: ft.Page):
    current_tab = None
    content_container = ft.Column()  # Container for displaying page content

    # Define the content for each tab
    tab_contents = {
        "My Contacts": ft.Text("This is the My Contacts page", bgcolor=ft.colors.RED),
        "Web Favorites": ft.Text("This is the Web Favorites page", bgcolor=ft.colors.ORANGE),
        "PC Cleanup": ft.Text("This is the PC Cleanup page", bgcolor=ft.colors.GREEN),
        "System Repair": ft.Text("This is the System Repair page", bgcolor=ft.colors.BLUE),
        "My Notes": ft.Text("This is the My Notes page", bgcolor=ft.colors.PURPLE),
        "All Features": ft.Text("This is the All Features page", bgcolor=ft.colors.YELLOW),
    }

    def tab_clicked(e):
        nonlocal current_tab
        tab_text = e.control.content.controls[1].controls[0].value  # Get the text of the clicked tab
        print(f"{tab_text} tab clicked")

        # Update the background color of the current tab
        if current_tab:
            current_tab.bgcolor = ft.colors.GREEN_500
        current_tab = e.control
        current_tab.bgcolor = ft.colors.GREEN_700
        page.update()

        # Update the content in the content container
        content_container.clean()  # Clear old content
        content_container.controls.append(tab_contents.get(tab_text, ft.Text("Unknown page")))
        page.update()

    # Create and add all tabs
    tabs = ft.Row(
        [
            CustomTab(text="My Contacts", icon_path="aa.png", on_click=tab_clicked).build(),
            CustomTab(text="Web Favorites", icon_path="bb.png", on_click=tab_clicked).build(),
            CustomTab(text="PC Cleanup", icon_path="cc.png", on_click=tab_clicked).build(),
            CustomTab(text="System Repair", icon_path="dd.png", on_click=tab_clicked).build(),
            CustomTab(text="My Notes", icon_path="ee.png", on_click=tab_clicked).build(),
            CustomTab(text="All Features", icon_path="ff.png", on_click=tab_clicked).build(),
        ],
        alignment=ft.MainAxisAlignment.START
    )

    page.add(tabs, content_container)  # Add tabs and content container to the page

ft.app(target=main)