import flet as ft

def main(page: ft.Page):
    page.title = "Flet圆形头像带自适应徽章示例自定义模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # 创建一个圆形头像
    avatar = ft.Container(
        width=100,
        height=100,
        border_radius=50,  # 圆形
        bgcolor=ft.Colors.BLUE,  # 头像背景色
        content=ft.Image(
            src="https://avatars.githubusercontent.com/u/5041459?s=88&v=4",
            width=100,
            height=100,
            fit=ft.ImageFit.COVER,  # 确保图像覆盖整个容器
            border_radius=50,  # 圆形
        ),
    )

    # 创建一个自适应文字的徽章
    badge = ft.Container(
        width=60,  # 设置徽章宽度
        height=20,  # 设置徽章高度
        padding=ft.padding.symmetric(horizontal=0, vertical=0),  # 徽章内边距
        border_radius=10,  # 圆角矩形
        bgcolor=ft.Colors.GREEN,  # 徽章背景色
        alignment=ft.alignment.top_center,  # 徽章对齐方式
        offset=ft.Offset(1.3, 0.5),  # 徽章偏移量
        content=ft.Text("用户在线", color=ft.Colors.WHITE, size=12),  # 徽章内容
    )

    # 将头像和徽章组合在一起
    avatar_with_badge = ft.Stack(
        [
            avatar,
            badge,
        ],
        width=100,
        height=100,
    )

    # 将组合后的控件添加到页面
    page.add(avatar_with_badge)

ft.app(target=main)