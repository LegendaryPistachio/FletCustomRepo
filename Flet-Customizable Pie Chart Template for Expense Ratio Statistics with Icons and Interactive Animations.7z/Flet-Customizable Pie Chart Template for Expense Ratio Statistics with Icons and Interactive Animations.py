import flet as ft

def main(page: ft.Page):
    page.title = "Flet Interactive Animated Pie Chart Template for Office Equipment Cost Distribution"
    normal_radius = 100
    hover_radius = 110
    normal_title_style = ft.TextStyle(
        size=12, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD
    )
    hover_title_style = ft.TextStyle(
        size=16,
        color=ft.Colors.WHITE,
        weight=ft.FontWeight.BOLD,
        shadow=ft.BoxShadow(blur_radius=2, color=ft.Colors.BLACK54),
    )
    normal_badge_size = 40
    hover_badge_size = 50

    def badge(icon, size):
        return ft.Container(
            ft.Icon(icon),
            width=size,
            height=size,
            border=ft.border.all(1, ft.Colors.BROWN),
            border_radius=size / 2,
            bgcolor=ft.Colors.WHITE,
        )

    def on_chart_event(e: ft.PieChartEvent):
        for idx, section in enumerate(chart.sections):
            if idx == e.section_index:
                section.radius = hover_radius
                section.title_style = hover_title_style
            else:
                section.radius = normal_radius
                section.title_style = normal_title_style
        chart.update()

    chart = ft.PieChart(
        sections=[
            ft.PieChartSection(
                20,
                title="20%",
                title_style=normal_title_style,
                color=ft.Colors.BLUE,
                radius=normal_radius,
                badge=badge(ft.Icons.DESKTOP_WINDOWS, normal_badge_size),  # Desktop
                badge_position=0.98,
            ),
            ft.PieChartSection(
                25,
                title="25%",
                title_style=normal_title_style,
                color=ft.Colors.YELLOW,
                radius=normal_radius,
                badge=badge(ft.Icons.LAPTOP, normal_badge_size),  # Laptop
                badge_position=0.98,
            ),
            ft.PieChartSection(
                15,
                title="15%",
                title_style=normal_title_style,
                color=ft.Colors.GREEN,
                radius=normal_radius,
                badge=badge(ft.Icons.PRINT, normal_badge_size),  # Printer
                badge_position=0.98,
            ),
            ft.PieChartSection(
                20,
                title="20%",
                title_style=normal_title_style,
                color=ft.Colors.PURPLE,
                radius=normal_radius,
                badge=badge(ft.Icons.SCANNER, normal_badge_size),  # Scanner
                badge_position=0.98,
            ),
            ft.PieChartSection(
                20,
                title="20%",
                title_style=normal_title_style,
                color=ft.Colors.ORANGE,
                radius=normal_radius,
                badge=badge(ft.Icons.TABLET_ANDROID, normal_badge_size),  # Tablet
                badge_position=0.98,
            ),
        ],
        sections_space=0,
        center_space_radius=0,
        on_chart_event=on_chart_event,
        expand=True,
    )

    # Chart Title
    chart_title = ft.Text(
        value="Office Equipment Cost Distribution",
        size=24,
        weight=ft.FontWeight.BOLD,
        color=ft.Colors.BLACK,
        text_align=ft.TextAlign.CENTER
    )

    # Legend
    legend_items = [
        ft.Row([
            ft.Container(
                width=20,
                height=20,
                bgcolor=color,
                border_radius=5
            ),
            ft.Text(label, size=14, color=ft.Colors.BLACK)
        ])
        for color, label in [
            (ft.Colors.BLUE, "Desktop"),
            (ft.Colors.YELLOW, "Laptop"),
            (ft.Colors.GREEN, "Printer"),
            (ft.Colors.PURPLE, "Scanner"),
            (ft.Colors.ORANGE, "Tablet")
        ]
    ]

    legend = ft.Column(
        controls=legend_items,
        alignment=ft.MainAxisAlignment.START,
        spacing=10
    )

    # Integrate Chart, Title, and Legend
    page.add(
        ft.Column(
            [
                chart_title,
                chart,
                legend
            ],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20
        )
    )

ft.app(target=main)