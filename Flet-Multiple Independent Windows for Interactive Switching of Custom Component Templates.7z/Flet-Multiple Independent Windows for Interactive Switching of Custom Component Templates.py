import flet as ft


def main(page: ft.Page):
    page.padding = 0
    page.window.width = 700
    page.window.height = 450

    def route_change(e):
        page.views.clear()
        routes = {
            "/": show_login,
            "/subwindow1": show_subwindow1,
            "/subwindow2": show_subwindow2,
            "/subwindow3": show_subwindow3,  # Add new window route
        }
        routes.get(page.route, show_login)()

    def show_page(title, content, buttons, width, height):
        page.title = title
        page.window.width = width
        page.window.height = height
        page.views.append(
            ft.View(
                page.route,
                [
                    ft.Column(
                        [
                            ft.Column(
                                content,
                                alignment=ft.MainAxisAlignment.CENTER,
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                spacing=10,
                            ),
                            ft.Row(
                                buttons,
                                alignment=ft.MainAxisAlignment.START,
                                spacing=10,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=12,
                    )
                ],
                padding=20,
            )
        )
        page.update()

    def create_button(text, route):
        return ft.ElevatedButton(text, on_click=lambda _: page.go(route))

    def show_subwindow1():
        buttons = [create_button("Return to Main Window", "/")]
        show_page("Sub-Window 1", [], buttons, 500, 300)

    def show_subwindow2():
        buttons = [create_button("Return to Main Window", "/")]
        show_page("Sub-Window 2", [], buttons, 500, 300)

    def show_subwindow3():  # New Sub-Window 3
        buttons = [create_button("Return to Main Window", "/")]
        show_page("Sub-Window 3", [], buttons, 500, 300)

    def show_login():
        buttons = [
            create_button("Sub-Window 1", "/subwindow1"),
            create_button("Sub-Window 2", "/subwindow2"),
            create_button("Sub-Window 3", "/subwindow3"),  # Add new window button
        ]
        show_page("Main Window", [], buttons, 700, 450)

    page.on_route_change = route_change
    page.go("/")


ft.app(target=main)
