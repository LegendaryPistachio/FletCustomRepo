import flet as ft


def main(page: ft.Page):
    page.padding = 0
    page.window.width = 700
    page.window.height = 450

    def route_change(e):
        page.views.clear()
        routes = {
            "/": show_login,
            "/subwindow1": show_subwindow1,
            "/subwindow2": show_subwindow2,
            "/subwindow3": show_subwindow3,  # 添加新窗口的路由
        }
        routes.get(page.route, show_login)()

    def show_page(title, content, buttons, width, height):
        page.title = title
        page.window.width = width
        page.window.height = height
        page.views.append(
            ft.View(
                page.route,
                [
                    ft.Column(
                        [
                            ft.Column(
                                content,
                                alignment=ft.MainAxisAlignment.CENTER,
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                spacing=10,
                            ),
                            ft.Row(
                                buttons,
                                alignment=ft.MainAxisAlignment.START,
                                spacing=10,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=12,
                    )
                ],
                padding=20,
            )
        )
        page.update()

    def create_button(text, route):
        return ft.ElevatedButton(text, on_click=lambda _: page.go(route))

    def show_subwindow1():
        buttons = [create_button("返回主窗口", "/")]
        show_page("子窗口1", [], buttons, 500, 300)

    def show_subwindow2():
        buttons = [create_button("返回主窗口", "/")]
        show_page("子窗口2", [], buttons, 500, 300)

    def show_subwindow3():  # 新增的子窗口3
        buttons = [create_button("返回主窗口", "/")]
        show_page("子窗口3", [], buttons, 500, 300)

    def show_login():
        buttons = [
            create_button("子窗口1", "/subwindow1"),
            create_button("子窗口2", "/subwindow2"),
            create_button("子窗口3", "/subwindow3"),  # 添加新窗口的按钮
        ]
        show_page("主窗口", [], buttons, 700, 450)

    page.on_route_change = route_change
    page.go("/")


ft.app(target=main)
