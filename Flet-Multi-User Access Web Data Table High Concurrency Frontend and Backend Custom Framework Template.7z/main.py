# main.py
import asyncio
from typing import AsyncGenerator, List
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, String, select
from contextlib import asynccontextmanager
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    logger.info("Database initialized and application is starting...")
    yield
    logger.info("Application is shutting down...")


app = FastAPI(lifespan=lifespan)

DATABASE_URL = "postgresql+asyncpg://postgres:lxm1234@localhost:5432/mydatabase"
engine = create_async_engine(DATABASE_URL, echo=True)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)
Base = declarative_base()


class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String, index=True)
    sn_number = Column(String, index=True)
    model = Column(String, index=True)
    quantity = Column(Integer, index=True)
    description = Column(String, index=True)


class ProductCreate(BaseModel):
    product_name: str
    sn_number: str
    model: str
    quantity: int
    description: str


class ProductRead(ProductCreate):
    id: int


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as db:
        yield db


connected_clients = set()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connected_clients.add(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Process received data (if needed)
    except WebSocketDisconnect:
        connected_clients.remove(websocket)
    finally:
        await websocket.close()


async def notify_clients(action: str, data: ProductRead):
    message = {"action": action, "data": data}
    for client in connected_clients:
        await client.send_json(message)


@app.post("/add_product/", response_model=ProductRead)
async def add_product(product: ProductCreate, db: AsyncSession = Depends(get_db)):
    db_product = Product(
        product_name=product.product_name,
        sn_number=product.sn_number,
        model=product.model,
        quantity=product.quantity,
        description=product.description,
    )
    db.add(db_product)
    await db.commit()
    await db.refresh(db_product)
    asyncio.create_task(notify_clients("add", db_product))
    return db_product


@app.get("/get_products/", response_model=List[ProductRead])
async def get_products(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Product))
    products = result.scalars().all()
    return products


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        logger.info("Database initialized successfully")


if __name__ == "__main__":
    import uvicorn

    logger.info("Starting FastAPI application...")
    uvicorn.run(app, host="127.0.0.1", port=8000)
