import flet as ft
import requests as re
import json

# 定义 VE 变量
VE = "1.0.0"  # 根据实际情况设置版本号


# 定义 LINK_URL 常量
class LINK_URL:
    About_Url = "https://example.com/api/about"  # 替换为实际的URL


class MyApp(ft.Container):  # 继承 ft.Container
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.msg = ft.Text(value="", color="green")
        self.button = ft.ElevatedButton(
            text="About",
            on_click=self.pro_about,
            data={"url": LINK_URL.About_Url, "pwd": "your_password_here"},
        )
        self.download_button = ft.ElevatedButton(
            text="Download",
            on_click=self.download_pro,
            data={"download_url": "https://example.com/file.zip"},
        )
        self.content = ft.Column([self.button, self.download_button, self.msg])

    def pro_about(self, e):
        url = e.control.data["url"]
        pwd = e.control.data["pwd"]
        self.page.launch_url(url)
        self.page.set_clipboard(pwd)
        self.msg.value = "密码已复制"
        self.msg.update()

        try:
            response = re.get(LINK_URL.About_Url)
            if 200 <= response.status_code < 300:
                ret = response.text
                info_list = json.loads(ret.replace("'", '"'))
            else:
                # 如果服务器响应不在200-300之间，使用默认信息
                info_list = {
                    "code": 0,
                    "msg": "success!",
                    "newversion": 0,
                    "latest": VE,
                }
        except Exception as e:
            print("main.py-error", e)
            # 如果出错，图片地址设为本地
            info_list = {
                "code": -1,
                "msg": "服务器错误",
                "newversion": 0,
                "latest": "local",
            }

        # 处理info_list，这里假设你需要在界面上显示一些信息
        self.msg.value = f"状态码: {info_list['code']}, 消息: {info_list['msg']}"
        self.msg.update()

    def download_pro(self, e):
        download_url = e.control.data["download_url"]  # 假设事件对象中有下载URL
        save_path = "downloaded_file.ext"  # 设置保存路径和文件名

        try:
            response = re.get(download_url, stream=True)
            if response.status_code == 200:
                with open(save_path, "wb") as file:
                    for chunk in response.iter_content(chunk_size=8192):
                        file.write(chunk)
                self.msg.value = f"文件已成功下载并保存到 {save_path}"
            else:
                self.msg.value = f"下载失败，状态码: {response.status_code}"
        except Exception as e:
            print("download_pro-error", e)
            self.msg.value = f"下载过程中发生错误: {str(e)}"

        self.msg.update()


def main(page: ft.Page):
    page.title = "MyApp"
    app = MyApp(page)
    page.add(app)


ft.app(target=main)
