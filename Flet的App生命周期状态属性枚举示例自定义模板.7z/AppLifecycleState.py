import flet as ft


def main(page: ft.Page):
    page.title = "Flet的App生命周期状态AppLifecycleState属性枚举示例自定义模板"
    # 定义一个用于显示当前生命周期状态的文本控件
    status_text = ft.Text("App is shown")

    # 定义生命周期状态变化的回调函数
    def app_lifecycle_change(e: ft.AppLifecycleStateChangeEvent):
        status_text.value = f"App state changed to: {e.state}"
        page.update()
        if e.state == ft.AppLifecycleState.DETACH:
            print("App is detached from the engine.")
        elif e.state == ft.AppLifecycleState.HIDE:
            print("App is hidden.")
        elif e.state == ft.AppLifecycleState.INACTIVE:
            print("App is inactive.")
        elif e.state == ft.AppLifecycleState.PAUSE:
            print("App is paused.")
        elif e.state == ft.AppLifecycleState.RESUME:
            print("App is resumed.")
        elif e.state == ft.AppLifecycleState.RESTART:
            print("App is restarted.")
        elif e.state == ft.AppLifecycleState.SHOW:
            print("App is shown.")

    # 设置生命周期状态变化的回调函数
    page.on_app_lifecycle_state_change = app_lifecycle_change

    # 将状态文本控件添加到页面
    page.add(status_text)

    # 在应用启动时打印 "App is shown."
    print("App is shown.")


# 启动 Flet 应用
ft.app(target=main)
