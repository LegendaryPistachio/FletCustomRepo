import flet as ft

def main(page: ft.Page):
    class TreeNode(ft.UserControl):
        def __init__(self, label, children=None, indent_level=0):
            super().__init__()
            self.label = label
            self.children = children or []
            self.expanded = False
            self.indent_level = indent_level

        def build(self):
            self.icon = ft.Icon(name=ft.icons.ADD, size=18)  # Default is plus sign
            self.text = ft.Text(value=self.label)
            self.row = ft.GestureDetector(
                on_tap=self.toggle_expansion,
                content=ft.Row(
                    controls=[
                        ft.Container(width=20 * self.indent_level),  # Indentation
                        self.icon,
                        self.text
                    ]
                )
            )
            self.column = ft.Column(controls=[self.row])
            for child in self.children:
                child.visible = self.expanded  # Default is collapsed
                self.column.controls.append(child)
            return self.column

        def toggle_expansion(self, e):
            if self.children:
                self.expanded = not self.expanded
                self.icon.name = ft.icons.REMOVE if self.expanded else ft.icons.ADD
                for child in self.children:
                    child.visible = self.expanded
                self.update()

    # Create some nodes
    level_3_child1 = TreeNode("Level 3 Child 1", indent_level=3)
    level_3_child2 = TreeNode("Level 3 Child 2", indent_level=3)
    level_2_child1 = TreeNode("Level 2 Child 1", [level_3_child1, level_3_child2], indent_level=2)
    level_2_child2 = TreeNode("Level 2 Child 2", indent_level=2)
    level_1_child1 = TreeNode("Level 1 Child 1", [level_2_child1, level_2_child2], indent_level=1)
    level_1_child2 = TreeNode("Level 1 Child 2", indent_level=1)
    root = TreeNode("Root", [level_1_child1, level_1_child2], indent_level=0)

    # Copy the existing root and its child nodes
    level_3_child1_copy = TreeNode("Level 3 Child 1", indent_level=3)
    level_3_child2_copy = TreeNode("Level 3 Child 2", indent_level=3)
    level_2_child1_copy = TreeNode("Level 2 Child 1", [level_3_child1_copy, level_3_child2_copy], indent_level=2)
    level_2_child2_copy = TreeNode("Level 2 Child 2", indent_level=2)
    level_1_child1_copy = TreeNode("Level 1 Child 1", [level_2_child1_copy, level_2_child2_copy], indent_level=1)
    level_1_child2_copy = TreeNode("Level 1 Child 2", indent_level=1)
    root_copy = TreeNode("Root Copy", [level_1_child1_copy, level_1_child2_copy], indent_level=0)

    # Add to page
    page.add(root, root_copy)

ft.app(target=main)