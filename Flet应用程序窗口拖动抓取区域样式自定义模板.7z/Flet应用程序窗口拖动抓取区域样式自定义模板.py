import flet as ft


def main(page: ft.Page):
    page.window.title_bar_hidden = True
    page.window.title_bar_buttons_hidden = True

    def close_window(e):
        page.window.close()

    close_button = ft.Container(
        content=ft.IconButton(
            icon=ft.Icons.CLOSE,  # 使用 ft.Icons 替代 ft.icons
            on_click=close_window,
        ),
        bgcolor=ft.Colors.RED,  # 使用 ft.Colors 替代 ft.colors
        border_radius=25,  # 可选：设置圆角
        padding=0,  # 可选：设置内边距
    )

    drag_area = ft.WindowDragArea(
        ft.Container(
            ft.Text(
                "Flet应用程序窗口拖动抓取区域样式自定义模板",
            ),
            bgcolor=ft.Colors.GREY_300,
            border_radius=15,
            padding=10,
        ),
        expand=True,
    )

    page.add(ft.Row([drag_area, close_button]))


ft.app(target=main)  # 使用 target 参数传递主函数
