import flet as ft
from flet import Icons  # 导入 Icons 枚举

def main(page: ft.Page):
    # 设置窗口标题
    page.title = "Flet传统桌面程序主窗口包含菜单栏工具栏的单页面自定义模板"

    def handle_menu_item_click(e):
        print(f"{e.control.content.value}.on_click")
        page.open(ft.SnackBar(content=ft.Text(f"{e.control.content.value} was clicked!")))
        page.update()

    def handle_submenu_open(e):
        print(f"{e.control.content.value}.on_open")

    def handle_submenu_close(e):
        print(f"{e.control.content.value}.on_close")

    def handle_submenu_hover(e):
        print(f"{e.control.content.value}.on_hover")

    menubar = ft.MenuBar(
        expand=True,
        style=ft.MenuStyle(
            alignment=ft.alignment.top_left,
            bgcolor=ft.Colors.BLUE_GREY_300,  # 更改背景色
            mouse_cursor={
                ft.ControlState.HOVERED: ft.MouseCursor.WAIT,
                ft.ControlState.DEFAULT: ft.MouseCursor.ZOOM_OUT,
            },
        ),
        controls=[
            ft.SubmenuButton(
                content=ft.Text("文件"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("新建"),
                        leading=ft.Icon(Icons.NEW_LABEL),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("打开"),
                        leading=ft.Icon(Icons.FOLDER_OPEN),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("保存"),
                        leading=ft.Icon(Icons.SAVE),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("另存为"),
                        leading=ft.Icon(Icons.SAVE_AS),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("退出"),
                        leading=ft.Icon(Icons.EXIT_TO_APP),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("编辑"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("撤销"),
                        leading=ft.Icon(Icons.UNDO),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("重做"),
                        leading=ft.Icon(Icons.REDO),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("剪切"),
                        leading=ft.Icon(Icons.CONTENT_CUT),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("复制"),
                        leading=ft.Icon(Icons.CONTENT_COPY),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("粘贴"),
                        leading=ft.Icon(Icons.CONTENT_PASTE),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("删除"),
                        leading=ft.Icon(Icons.DELETE),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("查找"),
                        leading=ft.Icon(Icons.SEARCH),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("替换"),
                        leading=ft.Icon(Icons.SWAP_HORIZ),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("全选"),
                        leading=ft.Icon(Icons.SELECT_ALL),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("格式"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("自动换行"),
                        leading=ft.Icon(Icons.WRAP_TEXT),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.PINK_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("字体..."),
                        leading=ft.Icon(Icons.FONT_DOWNLOAD),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.PINK_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("查看"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("状态栏"),
                        leading=ft.Icon(Icons.STAR),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.ORANGE_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("帮助"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("查看帮助"),
                        leading=ft.Icon(Icons.HELP),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.YELLOW_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("关于记事本"),
                        leading=ft.Icon(Icons.INFO),  # 使用 Icon 控件
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.YELLOW_100}  # 使用新的 Colors 枚举
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
        ],
    )

    # 创建工具栏
    toolbar = ft.Row(
        [
            ft.IconButton(Icons.NEW_LABEL, tooltip="新建", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.FOLDER_OPEN, tooltip="打开", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SAVE, tooltip="保存", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SAVE_AS, tooltip="另存为", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.UNDO, tooltip="撤销", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.REDO, tooltip="重做", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.CONTENT_CUT, tooltip="剪切", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.CONTENT_COPY, tooltip="复制", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.CONTENT_PASTE, tooltip="粘贴", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.DELETE, tooltip="删除", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SEARCH, tooltip="查找", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SWAP_HORIZ, tooltip="替换", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SELECT_ALL, tooltip="全选", on_click=lambda e: handle_menu_item_click(e)),
        ],
        spacing=10,
    )

    # 将菜单栏和工具栏添加到页面中
    page.add(
        ft.Column([
            ft.Row([menubar]),
            toolbar,
        ])
    )

ft.app(main)