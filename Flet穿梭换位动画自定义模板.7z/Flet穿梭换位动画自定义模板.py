import flet as ft
import asyncio

async def main(page: ft.Page):
    # 图片宽度和间隔间距
    image_width = 100
    spacing = 20

    # 计算总的占用宽度
    total_width = 3 * image_width + 2 * spacing

    # 计算每个图片容器的初始位置
    left1 = page.window.width - total_width
    left2 = left1 + image_width + spacing
    left3 = left2 + image_width + spacing

    # 创建图片容器
    c1 = ft.Container(
        content=ft.Image(src="logo.jpg", width=image_width, height=image_width),  # 替换为你的图片路径
        top=60,  # 距离顶部60像素
        left=left1,  # 初始位置在右侧
        animate_position=1000
    )

    c2 = ft.Container(
        content=ft.Image(src="logo.jpg", width=image_width, height=image_width),  # 替换为你的图片路径
        top=60,  # 距离顶部60像素
        left=left2,  # 初始位置在右侧
        animate_position=500
    )

    c3 = ft.Container(
        content=ft.Image(src="logo.jpg", width=image_width, height=image_width),  # 替换为你的图片路径
        top=60,  # 距离顶部60像素
        left=left3,  # 初始位置在右侧
        animate_position=1000
    )

    def animate_container():
        # 将图片容器移动到左侧
        c1.left -= 100
        c2.left -= 100
        c3.left -= 100

        # 检查是否需要重置位置
        if c1.left <= -image_width:
            c1.left = page.window.width
        if c2.left <= -image_width:
            c2.left = page.window.width - image_width - spacing
        if c3.left <= -image_width:
            c3.left = page.window.width - 2 * image_width - 2 * spacing

        page.update()

    async def timer_tick():
        while True:
            animate_container()
            await asyncio.sleep(0.1)  # 每0.1秒更新一次位置

    page.add(
        ft.Stack([c1, c2, c3], height=250),
    )

    # 启动定时任务
    asyncio.create_task(timer_tick())

def start_app():
    ft.app(target=main)

if __name__ == "__main__":
    start_app()