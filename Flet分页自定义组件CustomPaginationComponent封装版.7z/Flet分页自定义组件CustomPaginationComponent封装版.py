import flet as ft

class 分页组件(ft.Row):
    def __init__(self, 总页数, 当前页, 页面变化回调):
        super().__init__()
        self.总页数 = 总页数
        self.当前页 = 当前页
        self.页面变化回调 = 页面变化回调

        self.上一页按钮 = ft.ElevatedButton("<", on_click=self.上一页)
        self.页码标签 = ft.Text(f"第 {self.当前页} 页 / 共 {self.总页数} 页")
        self.下一页按钮 = ft.ElevatedButton(">", on_click=self.下一页)

        self.controls = [self.上一页按钮, self.页码标签, self.下一页按钮]

    def 上一页(self, e):
        if self.当前页 > 1:
            self.当前页 -= 1
            self.更新页码标签()
            self.页面变化回调(self.当前页)

    def 下一页(self, e):
        if self.当前页 < self.总页数:
            self.当前页 += 1
            self.更新页码标签()
            self.页面变化回调(self.当前页)

    def 更新页码标签(self):
        self.页码标签.value = f"第 {self.当前页} 页 / 共 {self.总页数} 页"
        self.update()

def 主函数(页面: ft.Page):
    def 页面变化回调(页码):
        # 在此处处理页面切换时的逻辑，例如获取对应页码的数据并更新页面内容
        print(f"切换到了第 {页码} 页")
        图片路径 = f"{页码}.jpg"
        页面.controls = [
            ft.Container(
                content=分页组件(3, 页码, 页面变化回调),
                padding=ft.padding.only(left=100)  # 向右移动300像素
            ),
            ft.Container(
                content=ft.Image(src=图片路径, width=500, height=700),  # 设置图片的宽度和高度
                alignment=ft.alignment.top_left  # 从左上角对齐
            )
        ]
        页面.update()

    # 默认显示第一页的图片
    页面.controls = [
        ft.Container(
            content=分页组件(3, 1, 页面变化回调),
            padding=ft.padding.only(left=100)  # 向右移动300像素
        ),
        ft.Container(
            content=ft.Image(src="1.jpg", width=500, height=700),  # 设置图片的宽度和高度
            alignment=ft.alignment.top_left  # 从左上角对齐
        )
    ]
    
    页面.update()

ft.app(target=主函数)