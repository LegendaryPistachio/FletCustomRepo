import flet as ft

def open_main(page):
    page.clean()
    page.add(
        ft.Text("Main Window"),
        ft.ElevatedButton(text="Open Window 1", on_click=lambda e: open_window1(page)),
        ft.ElevatedButton(text="Open Window 2", on_click=lambda e: open_window2(page)),
        ft.ElevatedButton(text="Open Window 3", on_click=lambda e: open_window3(page))
    )

def open_window1(page):
    page.clean()
    page.add(
        ft.Text("Window 1"),
        ft.ElevatedButton(text="Back to Main", on_click=lambda e: open_main(page))
    )

def open_window2(page):
    page.clean()
    page.add(
        ft.Text("Window 2"),
        ft.ElevatedButton(text="Back to Main", on_click=lambda e: open_main(page))
    )

def open_window3(page):
    page.clean()
    page.add(
        ft.Text("Window 3"),
        ft.ElevatedButton(text="Back to Main", on_click=lambda e: open_main(page))
    )

def main(page: ft.Page):
    page.title = "Flet Event-Driven Model for Managing Multiple Windows and Custom Components Template"
    
    # Initialize the page
    open_main(page)

# Run the application
ft.app(target=main)