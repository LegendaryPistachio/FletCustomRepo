# 操作系统任务栏设置为自动隐藏，然后再启动程序，窗口会自动居中。
import flet as ft


def main(page: ft.Page):
    # 设置窗口标题
    page.title = "Flet窗口居中示例自定义模板"

    # 设置窗口大小
    page.window.width = 800
    page.window.height = 600

    # 使窗口居中
    page.window.center()

    # 添加一个简单的文本控件
    page.add(ft.Text("窗口已居中！"))


# 启动 Flet 应用
ft.app(target=main)
