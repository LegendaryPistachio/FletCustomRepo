import flet as ft
import time


def main(page: ft.Page):
    page.title = "Flet Animation Transition Enum Value Fade Example Custom Template"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Create a text control, set background color to yellow, and text color to white
    text = ft.Text(
        "Fade In and Out",
        size=30,
        opacity=0,
        bgcolor=ft.Colors.YELLOW_500,
        color=ft.Colors.WHITE,
    )

    # Add text control to the page
    page.add(text)

    # Fade in animation
    def fade_in():
        for i in range(0, 101, 5):
            text.opacity = i / 100
            page.update()
            time.sleep(0.3)  # Add time interval

    # Fade out animation
    def fade_out():
        for i in range(100, -1, -5):
            text.opacity = i / 100
            page.update()
            time.sleep(0.3)  # Add time interval

    # Loop fade in and fade out
    while True:
        fade_in()
        fade_out()


ft.app(target=main)
