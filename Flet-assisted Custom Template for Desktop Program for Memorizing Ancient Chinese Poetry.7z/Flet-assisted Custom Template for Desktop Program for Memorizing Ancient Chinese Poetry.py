import flet as ft
import json
import random
from threading import Timer

# Embed poem.json content
poem_json_content = """
{
    "Flowers": [
        "Two flowers bloom, each on its own branch.",
        "A lone person stands amidst falling petals, while swallows fly in the light rain.",
        "A human face like peach blossoms, a utopia beyond the peach garden."
    ],
    "Mountains and Water": [
        "Mountains and rivers seem to have no way out, but willows and flowers appear in the dark.",
        "The sun sets behind the mountains, the Yellow River flows into the sea.",
        "A waterfall plunges straight down for three thousand feet, as if the Milky Way has fallen from the ninth heaven."
    ]
}
"""

# Parse JSON content
poem_data = json.loads(poem_json_content)


class PoemApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.page.title = "Flet Ancient Poetry Memorization Assistant Custom Template"
        self.page.window.width = 450
        self.page.window.height = 600
        self.page.theme_mode = ft.ThemeMode.LIGHT

        # Initialize state
        self.category = "Flowers"
        self.poems = poem_data[self.category]
        self.index = 0
        self.show_top = True
        self.backs_count = 0
        self.timer = None
        self.random_prompt = False
        self.random_order = False
        self.order = list(range(len(self.poems)))

        # Create UI
        self.create_widgets()

    def create_widgets(self):
        # Category selection
        self.category_var = ft.Dropdown(
            label="Select Category:",
            options=[ft.dropdown.Option(k) for k in poem_data.keys()],
            value=self.category,
            on_change=self.change_category,
        )

        # Prompt method selection
        self.prompt_var = ft.RadioGroup(
            content=ft.Column(
                [
                    ft.Radio(value="Top Half", label="Prompt Top Half"),
                    ft.Radio(value="Bottom Half", label="Prompt Bottom Half"),
                    ft.Radio(value="Random", label="Random"),
                ]
            ),
            value="Top Half",
        )

        # Question order selection
        self.order_var = ft.RadioGroup(
            content=ft.Column(
                [
                    ft.Radio(value="Sequential", label="Sequential"),
                    ft.Radio(value="Random", label="Random"),
                ]
            ),
            value="Sequential",
        )

        # Display poem
        self.poem_label = ft.Text(
            value="",
            size=20,
            text_align=ft.TextAlign.CENTER,
        )

        # Buttons
        self.prev_button = ft.ElevatedButton(
            text="Previous Sentence",
            on_click=self.show_prev_poem,
        )
        self.next_button = ft.ElevatedButton(
            text="Next Sentence",
            on_click=self.show_next_poem,
        )
        self.answer_button = ft.ElevatedButton(
            text="Show Answer",
            on_click=self.show_answer,
            disabled=True,
        )

        # Memorization count
        self.counter_label = ft.Text(
            value=f"Sentences Memorized: {self.backs_count}",
            size=16,
        )

        # Layout
        self.page.add(
            ft.Column(
                [
                    ft.Row([self.category_var]),
                    ft.Row([self.prompt_var]),
                    ft.Row([self.order_var]),
                    ft.Row([self.poem_label], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Row(
                        [self.prev_button, self.answer_button, self.next_button],
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    ft.Row([self.counter_label], alignment=ft.MainAxisAlignment.CENTER),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            )
        )

        # Display the first sentence
        self.show_poem()

    def change_category(self, e: ft.ControlEvent):
        self.category = e.control.value
        self.poems = poem_data[self.category]
        self.index = 0
        self.order = list(range(len(self.poems)))
        if self.order_var.value == "Random":
            random.shuffle(self.order)
        self.show_poem()

    def show_poem(self):
        if self.timer:
            self.timer.cancel()
        poem = self.poems[self.order[self.index]]
        half = len(poem) // 2

        # Random or fixed prompt selection
        if self.prompt_var.value == "Random":
            self.show_top = random.choice([True, False])
        else:
            self.show_top = self.prompt_var.value == "Top Half"

        if self.show_top:
            prompt = poem[:half] + " " + "_" * (len(poem) - half)
        else:
            prompt = "_" * half + " " + poem[half:]

        self.poem_label.value = prompt
        self.answer_button.disabled = True
        self.timer = Timer(10, self.enable_answer_button)
        self.timer.start()
        self.page.update()

    def enable_answer_button(self):
        self.answer_button.disabled = False
        self.page.update()

    def show_prev_poem(self, e: ft.ControlEvent):
        self.index = (self.index - 1) % len(self.poems)
        self.show_poem()

    def show_next_poem(self, e: ft.ControlEvent):
        self.index = (self.index + 1) % len(self.poems)
        self.backs_count += 1
        self.counter_label.value = f"Sentences Memorized: {self.backs_count}"
        self.show_poem()

    def show_answer(self, e: ft.ControlEvent):
        if self.timer:
            self.timer.cancel()
        self.poem_label.value = self.poems[self.order[self.index]]
        self.answer_button.disabled = True
        self.page.update()


def main(page: ft.Page):
    app = PoemApp(page)


ft.app(target=main)
