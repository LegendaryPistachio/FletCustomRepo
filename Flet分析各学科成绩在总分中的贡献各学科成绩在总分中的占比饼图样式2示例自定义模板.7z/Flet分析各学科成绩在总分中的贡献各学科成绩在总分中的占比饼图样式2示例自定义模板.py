import flet as ft

def main(page: ft.Page):
    # 将 normal_radius 和 hover_radius 缩小到原来的 2/3
    normal_radius = 134
    hover_radius = 160
    normal_title_style = ft.TextStyle(
        size=16, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD
    )
    hover_title_style = ft.TextStyle(
        size=22,
        color=ft.Colors.WHITE,
        weight=ft.FontWeight.BOLD,
        shadow=ft.BoxShadow(blur_radius=2, color=ft.Colors.BLACK54),
    )

    # 定义各科成绩和总分
    scores = {
        "Math": 85,
        "Science": 90,
        "English": 78,
        "History": 88
    }
    total_score = sum(scores.values())

    def on_chart_event(e: ft.PieChartEvent):
        for idx, section in enumerate(chart.sections):
            if idx == e.section_index:
                section.radius = hover_radius
                section.title_style = hover_title_style
            else:
                section.radius = normal_radius
                section.title_style = normal_title_style
        chart.update()

    # 计算每科成绩在总分中的占比，并创建 PieChartSection
    sections = [
        ft.PieChartSection(
            (score / total_score) * 100,
            title=f"{subject}: {score} ({(score / total_score) * 100:.2f}%)",
            title_style=normal_title_style,
            color=ft.Colors.with_opacity(0.6, color),
            radius=normal_radius,
        )
        for subject, score, color in zip(scores.keys(), scores.values(), [ft.Colors.BLUE, ft.Colors.YELLOW, ft.Colors.PURPLE, ft.Colors.GREEN])
    ]

    chart = ft.PieChart(
        sections=sections,
        sections_space=0,
        center_space_radius=106.67,  # 将中心空心半径缩小到原来的 2/3
        on_chart_event=on_chart_event,
        expand=True,
    )

    # 创建标题
    title = ft.Text(
        value="各科成绩在总分中的占比",
        size=24,
        weight=ft.FontWeight.BOLD,
        color=ft.Colors.BLACK,
        text_align=ft.TextAlign.CENTER
    )

    # 创建图例
    legend_items = [
        ft.Row(
            [
                ft.Container(
                    width=20,
                    height=20,
                    bgcolor=ft.Colors.with_opacity(0.6, color),
                    border_radius=5
                ),
                ft.Text(subject, size=16, color=ft.Colors.BLACK)
            ],
            alignment=ft.MainAxisAlignment.START
        )
        for subject, color in zip(scores.keys(), [ft.Colors.BLUE, ft.Colors.YELLOW, ft.Colors.PURPLE, ft.Colors.GREEN])
    ]

    legend = ft.Column(
        controls=legend_items,
        alignment=ft.MainAxisAlignment.START,
        spacing=10
    )

    # 创建一个 Column 包含标题
    title_column = ft.Column(
        controls=[
            title
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20
    )

    # 创建一个 Column 包含饼图和图例，并在上方添加一个 Container 来下移饼图
    chart_column = ft.Column(
        controls=[
            ft.Container(height=100),  # 添加一个 Container 来下移饼图
            chart,
            legend
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20
    )

    # 将标题和饼图及图例添加到页面
    page.add(
        ft.Column(
            controls=[
                title_column,
                chart_column
            ],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20
        )
    )

ft.app(target=main)