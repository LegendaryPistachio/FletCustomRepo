import flet as ft


def main(page: ft.Page):
    # 导航按钮
    buttons = [
        ft.Text("Main", size=18),
        ft.FilledTonalButton(
            "Home",
            icon=ft.Icons.HOME,
            width=180,
            style=ft.ButtonStyle(alignment=ft.alignment.center_left),
        ),
        ft.FilledTonalButton(
            "Team",
            icon=ft.Icons.GROUP_SHARP,
            width=180,
            style=ft.ButtonStyle(alignment=ft.alignment.center_left),
        ),
        ft.FilledTonalButton(
            "Goals",
            icon=ft.Icons.STARS_SHARP,
            width=180,
            style=ft.ButtonStyle(alignment=ft.alignment.center_left),
        ),
        ft.FilledTonalButton(
            "Private tasks",
            icon=ft.Icons.STAR_OUTLINED,
            width=180,
            style=ft.ButtonStyle(alignment=ft.alignment.center_left),
        ),
        ft.FilledTonalButton(
            "Analytics",
            icon=ft.Icons.ANALYTICS_SHARP,
            width=180,
            style=ft.ButtonStyle(alignment=ft.alignment.center_left),
        ),
        ft.Text("Other", size=18),
        ft.FilledTonalButton(
            "Documents",
            icon=ft.Icons.FOLDER,
            width=180,
            style=ft.ButtonStyle(alignment=ft.alignment.center_left),
        ),
        ft.FilledTonalButton(
            "Settings",
            icon=ft.Icons.SETTINGS,
            width=180,
            style=ft.ButtonStyle(alignment=ft.alignment.center_left),
        ),
    ]
    # 圆形头像
    img = ft.Image(
        src="https://picsum.photos/200/200?0",
        width=50,
        height=50,
        fit=ft.ImageFit.NONE,
        repeat=ft.ImageRepeat.NO_REPEAT,
        border_radius=ft.border_radius.all(50),
    )

    # 使用 Stack 实现 Badge 效果
    badge_stack = ft.Stack(
        [
            img,
            ft.Container(
                content=ft.Text("10", size=12, color="white"),
                width=20,
                height=20,
                alignment=ft.alignment.top_right,
                bgcolor=ft.Colors.RED,
                border_radius=ft.border_radius.all(10),
                margin=ft.margin.only(left=35, top=5),  # 调整位置
            ),
        ],
        width=50,
        height=50,
    )

    # 左侧栏
    left_bottom_user = ft.Container(
        alignment=ft.alignment.bottom_center,  # 将内容对齐到底部
        width=200,
        expand=True,  # 扩展以填满可用空间
        content=ft.Column(
            alignment=ft.MainAxisAlignment.END,  # 将内容对齐到底部
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # 水平居中
            controls=[
                badge_stack,
                ft.Text("Michael Jones"),
                ft.Text("michael@workmail.com"),
            ],
            spacing=2,  # 控制子控件之间的间距
        ),
    )

    # 左侧容器布局
    container = ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    alignment=ft.MainAxisAlignment.START,
                    controls=[img, ft.Text("Bonita", size=20)],
                ),
                ft.Container(height=10),
                *buttons,
                ft.Column(
                    expand=1,
                    alignment=ft.MainAxisAlignment.END,
                    controls=[
                        left_bottom_user,
                    ],
                ),
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=10,
        ),
        width=200,
        padding=10,
    )
    avatars = ["https://picsum.photos/200/200?0", "https://picsum.photos/200/200?1"]

    # 使用 Row 控件水平排列头像，实现堆叠效果
    avatars_row = ft.Row(
        controls=[
            ft.Container(
                width=50,
                height=50,
                border_radius=ft.border_radius.all(25),
                border=ft.border.all(2, "#cabaeb"),
                content=ft.Image(
                    src=avatar,
                    width=50,
                    height=50,
                    fit=ft.ImageFit.COVER,
                    border_radius=ft.border_radius.all(25),
                ),
                margin=ft.margin.only(right=-20),  # 负右间距使得头像重叠
            )
            for avatar in avatars
        ]
        + [
            ft.Container(
                width=50,
                height=50,
                border_radius=ft.border_radius.all(25),
                border=ft.border.all(2, "#cabaeb"),
                content=ft.Icon(ft.Icons.ADD_CIRCLE_SHARP, size=50, color="black"),
                margin=ft.margin.only(right=-20),  # 负右间距使得头像重叠
            )
        ],
        alignment=ft.MainAxisAlignment.START,  # 头像从左开始排列
    )
    # 主体卡片
    cards_box = ft.ResponsiveRow(
        [
            ft.Container(
                padding=10,
                border_radius=ft.border_radius.all(10),
                bgcolor="#C8BAEB",
                height=150,
                col={"sm": 4},
                content=ft.Column(
                    alignment=ft.MainAxisAlignment.END,
                    spacing=0,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Text("Efficiency"),
                                ft.Row(
                                    [
                                        ft.Text("Dev team "),
                                        ft.IconButton(
                                            icon=ft.Icons.KEYBOARD_ARROW_DOWN_SHARP
                                        ),
                                    ],
                                    spacing=0,
                                ),
                            ],
                        ),
                        ft.Row(
                            [
                                ft.Text(
                                    "87%",
                                    size=25,
                                    weight=ft.FontWeight.BOLD,
                                )
                            ]
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                avatars_row,
                                ft.Row(
                                    vertical_alignment=ft.CrossAxisAlignment.END,
                                    controls=[
                                        ft.Container(
                                            padding=5,
                                            border_radius=ft.border_radius.all(20),
                                            bgcolor=ft.Colors.WHITE,
                                            height=30,
                                            width=70,
                                            content=ft.Row(
                                                [
                                                    ft.Text(
                                                        "4", weight=ft.FontWeight.BOLD
                                                    ),
                                                    ft.IconButton(
                                                        icon=ft.Icons.SUPPORT_AGENT_SHARP,
                                                        icon_size=14,
                                                    ),
                                                ]
                                            ),
                                        )
                                    ],
                                ),
                            ],
                        ),
                    ],
                ),
            ),
            ft.Container(
                padding=10,
                border_radius=ft.border_radius.all(10),
                bgcolor="FEFFFF",
                height=150,
                col={"sm": 4},
                content=ft.Column(
                    # alignment=ft.MainAxisAlignment.END,
                    spacing=0,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Text("Tasks this week"),
                                ft.Row([ft.IconButton(icon=ft.Icons.MORE_HORIZ_SHARP)]),
                            ],
                        ),
                        ft.Row(
                            [
                                ft.Text(
                                    "15",
                                    size=25,
                                    weight=ft.FontWeight.BOLD,
                                )
                            ]
                        ),
                        ft.Column(
                            alignment=ft.MainAxisAlignment.END,
                            controls=[
                                ft.Row(
                                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                                    controls=[
                                        ft.Text(
                                            "Performance review",
                                            size=15,
                                            weight=ft.FontWeight.BOLD,
                                        ),
                                        ft.Text(f"35% left", color="#c5c5c5"),
                                    ],
                                ),
                                ft.ProgressBar(expand=1),
                            ],
                        ),
                    ],
                ),
            ),
            ft.Container(
                padding=10,
                border=ft.border.all(1, "#e6e7e9"),
                border_radius=ft.border_radius.all(10),
                bgcolor="F5F6F8",  # 背景色
                height=150,
                col={"sm": 4},
                content=ft.Column(
                    spacing=0,
                    controls=[
                        ft.Row(
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls=[
                                ft.Text("Online time per day"),
                                ft.Container(
                                    padding=2,
                                    bgcolor="F1E5A8",
                                    height=30,
                                    width=80,
                                    border_radius=ft.border_radius.all(5),
                                    content=ft.Row(
                                        [
                                            ft.IconButton(
                                                icon=ft.Icons.ARROW_UPWARD_SHARP,
                                                icon_color="black",
                                                icon_size=14,
                                            ),
                                            ft.Text(
                                                "3%",
                                                weight=ft.FontWeight.BOLD,
                                            ),
                                        ]
                                    ),
                                ),
                            ],
                        ),
                        ft.Row(
                            [
                                ft.Text(
                                    "9.2",
                                    size=25,
                                    weight=ft.FontWeight.BOLD,
                                ),
                                ft.Text("h", weight=ft.FontWeight.BOLD),
                            ]
                        ),
                        ft.Column(
                            alignment=ft.MainAxisAlignment.END,
                            controls=[
                                ft.Row(
                                    spacing=5,
                                    controls=[
                                        ft.Text(
                                            "\nIncreased\ncompared to last week.",
                                            size=15,
                                            weight=ft.FontWeight.BOLD,
                                        )
                                    ],
                                ),
                            ],
                        ),
                    ],
                ),
            ),
        ]
    )
    # 图表
    chart = ft.LineChart(
        data_series=[
            ft.LineChartData(
                data_points=[
                    ft.LineChartDataPoint(0, 3),
                    ft.LineChartDataPoint(2.6, 2),
                    ft.LineChartDataPoint(4.9, 5),
                    ft.LineChartDataPoint(6.8, 3.1),
                    ft.LineChartDataPoint(8, 4),
                    ft.LineChartDataPoint(9.5, 3),
                    ft.LineChartDataPoint(11, 4),
                ],
                stroke_width=5,
                color=ft.Colors.CYAN,
                curved=True,
                stroke_cap_round=True,
            )
        ],
        border=ft.border.all(3, ft.Colors.with_opacity(0.2, ft.Colors.ON_SURFACE)),
        horizontal_grid_lines=ft.ChartGridLines(
            interval=1, color=ft.Colors.with_opacity(0.2, ft.Colors.ON_SURFACE), width=1
        ),
        vertical_grid_lines=ft.ChartGridLines(
            interval=1, color=ft.Colors.with_opacity(0.2, ft.Colors.ON_SURFACE), width=1
        ),
        left_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(
                    value=1,
                    label=ft.Text("10K", size=14, weight=ft.FontWeight.BOLD),
                ),
                ft.ChartAxisLabel(
                    value=3,
                    label=ft.Text("30K", size=14, weight=ft.FontWeight.BOLD),
                ),
                ft.ChartAxisLabel(
                    value=5,
                    label=ft.Text("50K", size=14, weight=ft.FontWeight.BOLD),
                ),
            ],
            labels_size=40,
        ),
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(
                    value=2,
                    label=ft.Container(
                        ft.Text(
                            "MAR",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
                ft.ChartAxisLabel(
                    value=5,
                    label=ft.Container(
                        ft.Text(
                            "JUN",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
                ft.ChartAxisLabel(
                    value=8,
                    label=ft.Container(
                        ft.Text(
                            "SEP",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
            ],
            labels_size=32,
        ),
        tooltip_bgcolor=ft.Colors.with_opacity(0.8, ft.Colors.BLUE_GREY),
        min_y=0,
        max_y=6,
        min_x=0,
        max_x=11,
        col={"sm": 8},
        height=300,
    )
    # 图表容器
    chart_box = ft.ResponsiveRow(
        [
            chart,
            ft.Container(
                height=300,
                padding=15,
                col={"sm": 4},
                bgcolor="F7F3F3",
                expand=True,
                content=ft.Column(
                    spacing=15,
                    controls=[
                        ft.Row(
                            controls=[
                                ft.Container(
                                    expand=True,
                                    content=ft.Row(
                                        [
                                            ft.CircleAvatar(
                                                foreground_image_src="https://picsum.photos/200/200?3",
                                                content=ft.Text("USER"),
                                            ),
                                            ft.Column(
                                                [
                                                    ft.Text("Wade Warren"),
                                                    ft.Text("Marketing coordinator"),
                                                ],
                                                spacing=5,
                                            ),
                                        ]
                                    ),
                                )
                            ]
                        ),
                        ft.Row(
                            controls=[
                                ft.Container(
                                    border_radius=ft.border_radius.all(10),
                                    expand=True,
                                    bgcolor="DFE5F0",
                                    content=ft.Row(
                                        controls=[
                                            ft.CircleAvatar(
                                                foreground_image_src="https://picsum.photos/200/200?4",
                                                content=ft.Text("USER"),
                                            ),
                                            ft.Column(
                                                [
                                                    ft.Text("Jakob Jones"),
                                                    ft.Text("Web designer"),
                                                ],
                                                spacing=5,
                                            ),
                                            ft.IconButton(
                                                icon=ft.Icons.MODE_EDIT_OUTLINE_OUTLINED
                                            ),
                                        ]
                                    ),
                                )
                            ]
                        ),
                        ft.Row(
                            controls=[
                                ft.Container(
                                    expand=True,
                                    content=ft.Row(
                                        controls=[
                                            ft.CircleAvatar(
                                                foreground_image_src="https://picsum.photos/200/200?5",
                                                content=ft.Text("USER"),
                                            ),
                                            ft.Column(
                                                [
                                                    ft.Text("Leslie Wonderwid"),
                                                    ft.Text("PM manager"),
                                                ],
                                                spacing=5,
                                            ),
                                        ]
                                    ),
                                )
                            ]
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[ft.OutlinedButton(text="Manage personal")],
                        ),
                    ],
                ),
            ),
        ]
    )
    # 整个右侧容器
    right_box = ft.Container(
        padding=20,
        bgcolor="F5F6F8",
        expand=1,
        content=ft.Column(
            controls=[
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Row(
                            [
                                ft.Text(
                                    "Al team management",
                                    size=25,
                                    weight=ft.FontWeight.BOLD,
                                ),
                            ]
                        ),
                        ft.Row(
                            controls=[
                                ft.IconButton(
                                    icon=ft.Icons.ACCOUNT_CIRCLE_SHARP,
                                    icon_color="black",
                                    icon_size=35,
                                ),
                                ft.IconButton(
                                    icon=ft.Icons.MESSAGE_SHARP,
                                    icon_color="black",
                                    icon_size=35,
                                ),
                                ft.FilledButton(
                                    "Upgrade plan",
                                    style=ft.ButtonStyle(bgcolor="#4550de"),
                                ),
                            ]
                        ),
                    ],
                ),
                cards_box,
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Text("Team performance", weight=ft.FontWeight.BOLD, size=22),
                        ft.Row(
                            controls=[
                                ft.Container(
                                    bgcolor="#262729",
                                    width=10,
                                    height=10,
                                    border_radius=ft.border_radius.all(10),
                                ),
                                ft.Text(
                                    "Dev team",
                                    color="#99999a",
                                    size=20,
                                ),
                                ft.Container(
                                    bgcolor="#c7bfee",
                                    width=10,
                                    height=10,
                                    border_radius=ft.border_radius.all(10),
                                ),
                                ft.Text(
                                    "Design team",
                                    color="#99999a",
                                    size=20,
                                ),
                            ]
                        ),
                        ft.Text(
                            "See all",
                            size=18,
                            color="#8080f3",
                            weight=ft.FontWeight.BOLD,
                        ),
                    ],
                ),
                chart_box,
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Row(
                            [
                                ft.Text(
                                    "Departments", size=25, weight=ft.FontWeight.BOLD
                                ),
                            ]
                        ),
                        ft.Row(
                            controls=[
                                ft.Row(
                                    [
                                        ft.IconButton(
                                            icon=ft.Icons.SETTINGS_OUTLINED,
                                            icon_color="#707173",
                                        ),
                                        ft.Text(
                                            "Customize",
                                            size=18,
                                            color="#707173",
                                            weight=ft.FontWeight.BOLD,
                                        ),
                                        ft.IconButton(
                                            icon=ft.Icons.ADD, icon_color="#8080f3"
                                        ),
                                        ft.Text(
                                            "Add team",
                                            size=18,
                                            color="#8080f3",
                                            weight=ft.FontWeight.BOLD,
                                        ),
                                    ]
                                )
                            ]
                        ),
                    ],
                ),
                ft.ResponsiveRow(
                    alignment=ft.MainAxisAlignment.END,
                    columns=15,
                    controls=[
                        ft.Container(
                            padding=10,
                            col={"sm": 5},
                            bgcolor="F4F1F1",
                            content=ft.Row(
                                [
                                    ft.Container(
                                        border_radius=ft.border_radius.all(10),
                                        bgcolor="CCE7F0",
                                        width=60,
                                        height=60,
                                        content=ft.Icon(
                                            name=ft.Icons.REMOVE_RED_EYE_SHARP
                                        ),
                                    ),
                                    ft.Column(
                                        spacing=3,
                                        controls=[
                                            ft.Text("Visual", color="#797979", size=16),
                                            ft.Text(
                                                "ui designers", color="#232323", size=16
                                            ),
                                        ],
                                    ),
                                    ft.Row(
                                        controls=[
                                            ft.Container(
                                                width=40,
                                                height=40,
                                                border_radius=ft.border_radius.all(25),
                                                border=ft.border.all(2, "#eaebed"),
                                                content=ft.Image(
                                                    src="https://picsum.photos/200/200?6",
                                                    width=40,
                                                    height=25,
                                                    fit=ft.ImageFit.COVER,
                                                    border_radius=ft.border_radius.all(
                                                        25
                                                    ),
                                                ),
                                                margin=ft.margin.only(
                                                    right=-20
                                                ),  # 负右间距使得头像重叠
                                            )
                                        ]
                                        + [
                                            ft.Container(
                                                bgcolor="#f6f6f8",
                                                width=40,
                                                height=40,
                                                alignment=ft.alignment.center,
                                                border_radius=ft.border_radius.all(40),
                                                border=ft.border.all(2, "#eaebed"),
                                                content=ft.Text(
                                                    "+23",
                                                    size=10,
                                                    color="#909092",
                                                    weight=ft.FontWeight.BOLD,
                                                ),
                                                margin=ft.margin.only(
                                                    right=-20
                                                ),  # 负右间距使得头像重叠
                                            )
                                        ],
                                        alignment=ft.MainAxisAlignment.START,  # 头像从左开始排列
                                    ),
                                ]
                            ),
                        ),
                        ft.Container(
                            padding=10,
                            col={"sm": 5},
                            bgcolor="F4F1F1",
                            content=ft.Row(
                                [
                                    ft.Container(
                                        border_radius=ft.border_radius.all(10),
                                        bgcolor="F2E8AB",
                                        width=60,
                                        height=60,
                                        content=ft.Icon(
                                            name=ft.Icons.ACCOUNT_CIRCLE_SHARP
                                        ),
                                    ),
                                    ft.Column(
                                        spacing=3,
                                        controls=[
                                            ft.Text(
                                                "Accounting", color="#797979", size=16
                                            ),
                                            ft.Text("Sales", color="#232323", size=16),
                                        ],
                                    ),
                                    ft.Row(
                                        controls=[
                                            ft.Container(
                                                width=40,
                                                height=40,
                                                border_radius=ft.border_radius.all(25),
                                                border=ft.border.all(2, "#eaebed"),
                                                content=ft.Image(
                                                    src="https://picsum.photos/200/200?7",
                                                    width=40,
                                                    height=25,
                                                    fit=ft.ImageFit.COVER,
                                                    border_radius=ft.border_radius.all(
                                                        25
                                                    ),
                                                ),
                                                margin=ft.margin.only(
                                                    right=-20
                                                ),  # 负右间距使得头像重叠
                                            )
                                        ]
                                        + [
                                            ft.Container(
                                                bgcolor="#f6f6f8",
                                                width=40,
                                                height=40,
                                                alignment=ft.alignment.center,
                                                border_radius=ft.border_radius.all(40),
                                                border=ft.border.all(2, "#eaebed"),
                                                content=ft.Text(
                                                    "+12",
                                                    size=10,
                                                    color="#909092",
                                                    weight=ft.FontWeight.BOLD,
                                                ),
                                                margin=ft.margin.only(
                                                    right=-20
                                                ),  # 负右间距使得头像重叠
                                            )
                                        ],
                                        alignment=ft.MainAxisAlignment.START,  # 头像从左开始排列
                                    ),
                                ]
                            ),
                        ),
                        ft.Container(
                            padding=10,
                            col={"sm": 5},
                            bgcolor="F4F1F1",
                            content=ft.Row(
                                [
                                    ft.Container(
                                        border_radius=ft.border_radius.all(10),
                                        bgcolor="E0DAF4",
                                        width=60,
                                        height=60,
                                        content=ft.Icon(
                                            name=ft.Icons.INSERT_DRIVE_FILE_SHARP
                                        ),
                                    ),
                                    ft.Column(
                                        spacing=3,
                                        controls=[
                                            ft.Text(
                                                "Content", color="#797979", size=16
                                            ),
                                            ft.Text("SEO", color="#232323", size=16),
                                        ],
                                    ),
                                    ft.Row(
                                        controls=[
                                            ft.Container(
                                                width=40,
                                                height=40,
                                                border_radius=ft.border_radius.all(25),
                                                border=ft.border.all(2, "#eaebed"),
                                                content=ft.Image(
                                                    src="https://picsum.photos/200/200?8",
                                                    width=40,
                                                    height=25,
                                                    fit=ft.ImageFit.COVER,
                                                    border_radius=ft.border_radius.all(
                                                        25
                                                    ),
                                                ),
                                                margin=ft.margin.only(
                                                    right=-20
                                                ),  # 负右间距使得头像重叠
                                            )
                                        ]
                                        + [
                                            ft.Container(
                                                bgcolor="#f6f6f8",
                                                width=40,
                                                height=40,
                                                alignment=ft.alignment.center,
                                                border_radius=ft.border_radius.all(40),
                                                border=ft.border.all(2, "#eaebed"),
                                                content=ft.Text(
                                                    "+7",
                                                    size=10,
                                                    color="#909092",
                                                    weight=ft.FontWeight.BOLD,
                                                ),
                                                margin=ft.margin.only(
                                                    right=-20
                                                ),  # 负右间距使得头像重叠
                                            )
                                        ],
                                        alignment=ft.MainAxisAlignment.START,  # 头像从左开始排列
                                    ),
                                ]
                            ),
                        ),
                    ],
                ),
            ]
        ),
    )
    # 整个页面存在于该容器内
    main_box = ft.Container(
        border_radius=ft.border_radius.all(15),
        expand=1,
        padding=5,
        bgcolor=ft.Colors.WHITE,
        content=ft.Row(
            controls=[
                container,
                ft.Container(
                    content=right_box,
                    expand=True,
                    alignment=ft.alignment.top_left,
                    bgcolor=ft.Colors.GREEN,
                    border_radius=ft.border_radius.only(
                        top_left=0, top_right=20, bottom_left=0, bottom_right=20
                    ),
                ),
            ],
            expand=True,
        ),
    )
    # 创建主页面布局
    page.window.height = 800
    page.title = "Flet layout DEMO - 管理仪表盘 by--吖嗪"
    page.add(main_box)


ft.app(target=main)
