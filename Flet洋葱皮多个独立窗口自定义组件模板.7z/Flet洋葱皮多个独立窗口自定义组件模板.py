import flet as ft


def main(page):
    page.title = "窗口 1"
    page.window.width = 600
    page.window.height = 400
    page.add(ft.Text("这是第一个独立窗口"))


def second_window(page):
    page.title = "窗口 2"
    page.window.width = 630
    page.window.height = 430
    page.add(ft.Text("这是第二个独立窗口"))


def third_window(page):
    page.title = "窗口 3"
    page.window.width = 660
    page.window.height = 460
    page.add(ft.Text("这是第三个独立窗口"))


def fourth_window(page):
    page.title = "窗口 4"
    page.window.width = 690
    page.window.height = 490
    page.add(ft.Text("这是第四个独立窗口"))


def fifth_window(page):
    page.title = "窗口 5"
    page.window.width = 720
    page.window.height = 520
    page.add(ft.Text("这是第五个独立窗口"))


def sixth_window(page):
    page.title = "窗口 6"
    page.window.width = 750
    page.window.height = 550
    page.add(ft.Text("这是第六个独立窗口"))


def seventh_window(page):
    page.title = "窗口 7"
    page.window.width = 780
    page.window.height = 580
    page.add(ft.Text("这是第七个独立窗口"))


if __name__ == "__main__":
    # 创建第一个窗口
    ft.app(target=main)

    # 创建第二个窗口
    ft.app(target=second_window)

    # 创建第三个窗口
    ft.app(target=third_window)

    # 创建第四个窗口
    ft.app(target=fourth_window)

    # 创建第五个窗口
    ft.app(target=fifth_window)

    # 创建第六个窗口
    ft.app(target=sixth_window)

    # 创建第七个窗口
    ft.app(target=seventh_window)
