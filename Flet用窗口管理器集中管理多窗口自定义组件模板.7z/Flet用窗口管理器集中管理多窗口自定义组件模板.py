import flet as ft

# 创建子窗口逻辑
class ChildWindow:
    def __init__(self, title, manager):
        self.title = title
        self.manager = manager
        self.visible = False  # 初始状态为不可见
        self.control = self.build()

    def build(self):
        return ft.Container(
            content=ft.Column(
                [
                    ft.Text(self.title, size=20, weight="bold"),
                    ft.Text(f"这是 {self.title} 的内容。"),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.STRETCH,  # 水平拉伸以适应宽度
                expand=True  # 设置 expand 为 True 以自适应宽度和高度
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.BLUE),  # 使用 ft.Colors
            margin=10,
            visible=self.visible,
            expand=True  # 设置 expand 为 True 以自适应宽度和高度
        )

    def show(self):
        if not self.control.page:  # 检查控制是否已经添加到页面
            self.manager.add_child(self)  # 如果没有，则重新添加
        self.control.visible = True
        self.control.update()
        self.visible = True
        print(f"显示子窗口: {self.title}")

    def hide(self):
        if self.control.page:  # 确保控制已经添加到页面
            self.control.visible = False
            self.control.update()
        self.visible = False
        print(f"隐藏子窗口: {self.title}")

# 创建主窗口和窗口管理器逻辑
class WindowManager:
    def __init__(self, page):
        self.page = page
        self.child_windows = {}
        self.display_order = []  # 用于记录子窗口的显示顺序
        self.child_windows_column_ref = ft.Ref[ft.Column]()  # 创建 Ref 对象
        self.control = self.build()

    def build(self):
        buttons = []
        for i in range(1, 4):
            title = f"子窗口 {i}"
            child_window = ChildWindow(title, self)
            self.child_windows[title] = child_window

            buttons.extend([
                ft.ElevatedButton(f"显示 {title}", on_click=lambda e, cw=child_window: cw.show()),
                ft.ElevatedButton(f"隐藏 {title}", on_click=lambda e, cw=child_window: cw.hide()),
                ft.ElevatedButton(f"关闭 {title}", on_click=lambda e, cw=child_window: cw.manager.remove_child(cw)),
            ])

        button_rows = [
            ft.Row(buttons[i*3:(i+1)*3], alignment=ft.MainAxisAlignment.CENTER)
            for i in range(3)
        ]

        # 构建 Column 控件并赋值给 self.child_windows_column_ref
        child_windows_column = ft.Column(ref=self.child_windows_column_ref, controls=[], spacing=10, expand=True)
        
        # 初始化时将子窗口添加到页面并隐藏
        for child_window in self.child_windows.values():
            child_windows_column.controls.append(child_window.control)
            child_window.hide()

        # 添加关闭主窗口的按钮
        close_main_button = ft.ElevatedButton("关闭主窗口", on_click=self.close_main_window)

        return ft.Column(
            [
                ft.Text("窗口管理器", size=30, weight="bold", text_align=ft.TextAlign.CENTER),
                ft.Container(
                    content=ft.Column(button_rows, spacing=10),
                    border=ft.border.all(1, ft.Colors.BLUE),  # 添加边框
                    padding=10,
                    margin=10,
                ),
                child_windows_column,  # 直接使用构建好的 Column 控件
                close_main_button,  # 添加关闭主窗口的按钮
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # 水平居中对齐
            expand=True  # 设置 expand 为 True 以自适应宽度
        )

    def add_child(self, child_window):
        if child_window.control not in self.child_windows_column_ref.current.controls:
            self.child_windows_column_ref.current.controls.append(child_window.control)
            self.child_windows_column_ref.current.update()
            print(f"添加子窗口: {child_window.title}")

    def show_child(self, child_window):
        if not child_window.control.page:  # 检查控制是否已经添加到页面
            self.add_child(child_window)  # 如果没有，则重新添加
        child_window.control.visible = True
        child_window.control.update()
        child_window.visible = True

        # 将子窗口移动到显示顺序列表的末尾
        if child_window in self.display_order:
            self.display_order.remove(child_window)
        self.display_order.append(child_window)

        # 更新子窗口的显示顺序
        self.update_display_order()
        print(f"显示子窗口: {child_window.title}")

    def hide_child(self, child_window):
        if child_window.control.page:  # 确保控制已经添加到页面
            child_window.control.visible = False
            child_window.control.update()
        child_window.visible = False

        # 从显示顺序列表中移除子窗口
        if child_window in self.display_order:
            self.display_order.remove(child_window)

        print(f"隐藏子窗口: {child_window.title}")

    def remove_child(self, child_window):
        if child_window.control in self.child_windows_column_ref.current.controls:
            self.child_windows_column_ref.current.controls.remove(child_window.control)
            self.child_windows_column_ref.current.update()
            child_window.control.visible = False  # 隐藏控件

            # 从显示顺序列表中移除子窗口
            if child_window in self.display_order:
                self.display_order.remove(child_window)

            print(f"关闭子窗口: {child_window.title}")
        else:
            print(f"子窗口 {child_window.title} 不在页面中，无法关闭")

    def update_display_order(self):
        # 根据显示顺序列表更新子窗口的显示顺序
        controls = [cw.control for cw in self.display_order]
        self.child_windows_column_ref.current.controls = controls
        self.child_windows_column_ref.current.update()
        print("更新子窗口显示顺序")

    def update(self):
        self.child_windows_column_ref.current.update()  # 更新 Column 控件以反映变化
        print("更新控件")

    def close_main_window(self, e):
        print("关闭主窗口")
        self.page.window_close()  # 关闭主窗口

# 启动应用
def main(page: ft.Page):
    page.title = "窗口管理器示例"
    page.expand = True  # 设置页面自适应
    manager = WindowManager(page)
    page.add(manager.control)
    page.update()  # 确保页面初始加载时更新

# 运行 Flet 应用
ft.app(target=main)