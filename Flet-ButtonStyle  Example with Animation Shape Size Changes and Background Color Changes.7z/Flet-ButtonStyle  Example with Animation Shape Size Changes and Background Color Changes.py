import flet as ft


def main(page: ft.Page):
    page.title = "Flet Button with Animation Shape Size Changes and Background Color Changes Example"

    page.add(
        ft.FilledButton(
            "Styled button 1",
            style=ft.ButtonStyle(
                color={
                    ft.ControlState.HOVERED: ft.Colors.WHITE,
                    ft.ControlState.FOCUSED: ft.Colors.BLUE,
                    ft.ControlState.DEFAULT: ft.Colors.BLACK,
                },
                bgcolor={
                    ft.ControlState.HOVERED: ft.Colors.PURPLE,  # Change background color to purple on hover
                    ft.ControlState.DEFAULT: ft.Colors.YELLOW,  # Change background color to yellow in default state
                },
                padding={ft.ControlState.HOVERED: 20},
                overlay_color=ft.Colors.TRANSPARENT,
                elevation={"pressed": 0, "": 1},
                animation_duration=500,
                side={
                    ft.ControlState.DEFAULT: ft.BorderSide(1, ft.Colors.BLUE),
                    ft.ControlState.HOVERED: ft.BorderSide(2, ft.Colors.BLUE),
                },
                shape={
                    ft.ControlState.HOVERED: ft.RoundedRectangleBorder(radius=20),
                    ft.ControlState.DEFAULT: ft.BeveledRectangleBorder(
                        radius=10
                    ),  # Change default shape to BeveledRectangleBorder
                },
            ),
        )
    )


ft.app(main)
