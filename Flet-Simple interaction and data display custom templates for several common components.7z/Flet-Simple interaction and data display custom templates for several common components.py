import flet as ft


def main(page: ft.Page):
    page.title = (
        "Flet Common Components Simple Interaction and Data Display Custom Template"
    )
    page.scroll = ft.ScrollMode.AUTO  # Enable scrolling
    page.vertical_alignment = ft.MainAxisAlignment.START  # Align from the top
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.spacing = 5  # Reduce spacing
    page.theme_mode = ft.ThemeMode.LIGHT

    def open_dialog(e):
        dialog = ft.AlertDialog(content=ft.Text("This is a test."), open=True)
        page.open(dialog)

    def change_theme(e):
        page.theme_mode = (
            ft.ThemeMode.DARK
            if page.theme_mode == ft.ThemeMode.LIGHT
            else ft.ThemeMode.LIGHT
        )
        page.update()

    def on_segment_change(e):
        selected_segment = e.control.selected
        print(f"Selected segment: {selected_segment}")

    def on_name_change(e):
        print(f"Name input changed to: {e.control.value}")

    def on_chart_click(e):
        print(f"Chart clicked at position: {e.x}, {e.y}")

    def on_button_click(e):
        print(f"Button clicked: {e.control.text}")

    segments = [
        ft.Segment(
            "1",
            ft.Icon(ft.Icons.LOOKS_ONE),
            ft.Text("cat", size=16),
            tooltip="Meow Meow Meow",
        ),
        ft.Segment(
            "2",
            ft.Icon(ft.Icons.LOOKS_TWO),
            ft.Text("dog", size=16),
            tooltip="Woof Woof Woof",
        ),
    ]

    segment_btn = ft.SegmentedButton(
        segments, selected={"1"}, on_change=on_segment_change
    )

    name_input = ft.TextField(
        width=400,
        hint_text="What's your name?",
        max_length=20,
        on_change=on_name_change,
    )

    bar_group = ft.BarChartGroup(
        x=0,
        bar_rods=[
            ft.BarChartRod(to_y=40, color=ft.Colors.AMBER, tooltip="apple", width=20)
        ],
    )
    bar_group2 = ft.BarChartGroup(
        x=1,
        bar_rods=[
            ft.BarChartRod(to_y=80, color=ft.Colors.BLUE, tooltip="banana", width=20)
        ],
    )
    labels = [
        ft.ChartAxisLabel(value=0, label=ft.Text("apple")),
        ft.ChartAxisLabel(value=1, label=ft.Text("banana")),
    ]
    chart = ft.BarChart(
        bar_groups=[bar_group, bar_group2],
        border=ft.border.all(1, ft.Colors.GREY_400),
        left_axis=ft.ChartAxis(labels_size=40, title=ft.Text("fruits"), title_size=40),
        bottom_axis=ft.ChartAxis(labels=labels, labels_size=32),
        tooltip_bgcolor=ft.Colors.with_opacity(0.5, ft.Colors.GREY_300),
        max_y=100,
        width=600,
    )

    chart_container = ft.Container(
        content=chart,
        width=600,
        height=400,
        on_click=on_chart_click,
    )

    btn = ft.FilledButton(
        "Open Dialog", on_click=lambda e: (open_dialog(e), on_button_click(e))
    )
    btn2 = ft.FilledTonalButton(
        "Change Theme", on_click=lambda e: (change_theme(e), on_button_click(e))
    )
    btn3 = ft.ElevatedButton("Something Happened", on_click=on_button_click)
    btn4 = ft.OutlinedButton("I'm Still the Same.", on_click=on_button_click)

    page.add(segment_btn, name_input, chart_container, btn, btn2, btn3, btn4)


if __name__ == "__main__":
    ft.app(main)
