import flet
from flet import (
    FilePicker,
    FilePickerFileType,
    Page,
    Row,
    Text,
    ElevatedButton,
    Icons,
)


def main(page: Page):
    page.title = "Flet文件选择器选择文件类型枚举示例自定义模板"
    page.horizontal_align = "stretch"
    page.vertical_align = "center"
    
    # 创建文件选择器控件
    file_picker = FilePicker()
    page.overlay.append(file_picker)
    page.update()

    # 显示选择结果的文本控件
    selected_files = Text()

    def handle_file_result(e):
        if e.files:
            # 过滤文件类型
            allowed_extensions = [".jpg", ".jpeg", ".png",".gif", ".svg",".mp4",".mkv", ".mov" ".avi"]
            valid_files = [f for f in e.files if any(f.path.lower().endswith(ext) for ext in allowed_extensions)]
            if valid_files:
                # 显示第一个选中的文件路径
                selected_files.value = valid_files[0].path
            else:
                selected_files.value = "未选择有效的文件"
        else:
            selected_files.value = "未选择文件"
        page.update()

    # 将结果处理函数绑定到文件选择器
    file_picker.on_result = handle_file_result

    # 创建 Row 控件并添加到页面
    row = Row(
        controls=[
            # 示例1：选择任意文件类型
            ElevatedButton(
                "选择任意文件",
                icon=Icons.FILE_OPEN,
                on_click=lambda _: file_picker.pick_files(
                    allow_multiple=False,
                ),
            ),
            # 示例2：选择图片和视频
            ElevatedButton(
                "选择媒体文件",
                icon=Icons.IMAGE,
                on_click=lambda _: file_picker.pick_files(
                    file_type=FilePickerFileType.CUSTOM,
                    allowed_extensions = ["jpg", "jpeg", "png","gif","svg", "mp4","mkv", "mov", "avi"],
                    allow_multiple=True,
                ),
            ),
            # 示例3：自定义文件类型（PDF和文本文件）
            ElevatedButton(
                "选择文档",
                icon=Icons.DESCRIPTION,
                on_click=lambda _: file_picker.pick_files(
                    file_type=FilePickerFileType.CUSTOM,
                    allowed_extensions=["pdf", "txt","docx","doc"],
                    allow_multiple=True,
                ),
            ),
            selected_files,  # 显示选择结果
        ],
        alignment="center",
    )

    # 将 Row 控件添加到页面的 controls 列表中
    page.controls.append(row)
    page.update()


flet.app(target=main)