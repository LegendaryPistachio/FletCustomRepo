import datetime
import flet as ft

def main(page: ft.Page):
    page.locale_configuration = ft.LocaleConfiguration(
        supported_locales=[
            ft.Locale("en", "English"),
            ft.Locale("zh", "Chinese"),
        ],
        current_locale=ft.Locale("zh", "Chinese"),
    )

    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def handle_change(e):
        selected_date = e.control.value
        formatted_date = f"{selected_date.year}年{selected_date.month}月{selected_date.day}日"
        page.add(ft.Text(f"日期变更: {formatted_date}"))

    def handle_dismissal(e):
        page.add(ft.Text(f"日期选择器已关闭"))

    page.add(
        ft.ElevatedButton(
            "选择日期",
            icon=ft.Icons.CALENDAR_MONTH,
            on_click=lambda e: page.open(
                ft.DatePicker(
                    first_date=datetime.datetime(year=2023, month=10, day=1),
                    last_date=datetime.datetime(year=2024, month=10, day=1),
                    on_change=handle_change,
                    on_dismiss=handle_dismissal,
                )
            ),
        )
    )

ft.app(main)