import flet as ft


def main(page: ft.Page):
    page.title = "Main Window"
    page.window.width = 800
    page.window.height = 600

    def open_child_window(e):
        # 使用对话框作为子窗口
        dialog = ft.AlertDialog(
            title=ft.Text("Child Window"),
            content=ft.Column(
                [
                    ft.Text("This is a child window"),
                    ft.ElevatedButton("Close", on_click=lambda e: close_dialog(dialog)),
                ]
            ),
            actions=[],  # 移除 actions 列表中的 OK 按钮
        )
        page.overlay.append(dialog)  # 将对话框添加到页面的叠加层
        dialog.open = True
        page.update()

    def close_dialog(dialog):
        dialog.open = False  # 直接设置对话框的 open 属性为 False
        page.update()

    main_button = ft.ElevatedButton("Open Child Window", on_click=open_child_window)
    page.add(main_button)


# 启动主应用
ft.app(target=main)
