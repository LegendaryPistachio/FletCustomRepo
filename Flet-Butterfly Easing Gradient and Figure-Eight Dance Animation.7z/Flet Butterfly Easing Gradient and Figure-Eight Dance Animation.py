import flet as ft  
import math  
import asyncio  

# Define the function for the figure-eight dance path  
def figure_eight_path(t, radius):  
    """Calculate the coordinates of the figure-eight dance path"""  
    x = radius * math.sin(t * 2 * math.pi)  # X coordinate change  
    y = radius * math.sin(t * 4 * math.pi) / 2  # Y coordinate change  
    return x, y  

async def main(page: ft.Page):  
    # Create a butterfly image control  
    butterfly_image = ft.Image(  
        src="Butterfly.png",  # Ensure the path is correct  
        width=100,  
        height=100,  
    )  

    # Create a container to display the butterfly  
    container = ft.Container(  
        content=butterfly_image,  
        alignment=ft.alignment.center,  
        width=100,  
        height=100,  
    )  

    # Create a stack for absolute positioning of the container  
    stack = ft.Stack(  
        controls=[container],  
        width=400,  
        height=400,  
    )  

    page.add(stack)  

    duration = 5000  # Duration of the animation  
    steps = 300  # Number of steps in the animation  
    radius = 100  # Radius of the figure-eight dance  

    # Run the animation  
    while True:  
        await animate_butterfly(page, container, steps, duration, radius)  

async def animate_butterfly(page, container, steps, duration, radius):  
    for t in range(steps + 1):  
        progress = t / steps  
        x, y = figure_eight_path(progress, radius)  

        # Update the butterfly's position  
        container.left = x + 150  # Add offset  
        container.top = y + 150    # Add offset  

        # Update opacity  
        opacity = 1 - (t / steps) ** 2  
        container.opacity = opacity  
        page.update()  
        await asyncio.sleep(duration / (steps * 1000))  # Control frame rate  

# Run the application  
ft.app(main)