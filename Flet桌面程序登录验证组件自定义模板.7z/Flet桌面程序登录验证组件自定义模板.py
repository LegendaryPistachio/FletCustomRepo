import flet as ft
import sqlite3
from flet import Icons

def main(page: ft.Page):
    page.padding = 0

    # 创建数据库连接
    conn = sqlite3.connect('users.db')
    c = conn.cursor()

    # 创建用户表，如果表不存在则创建
    c.execute('''CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT)''')
    conn.commit()

    def show_page(title, content, buttons, message):
        page.title = title
        page.window.width = 420
        page.window.height = 450
        page.controls.clear()
        page.add(
            ft.Column(
                [
                    ft.Image(src="logo1.png", width=420, height=220, fit=ft.ImageFit.COVER),
                    ft.Column(content, alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
                    ft.Row(buttons, alignment=ft.MainAxisAlignment.CENTER, spacing=10),
                    message
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12
            )
        )

    def show_register():
        username_field = ft.TextField(label="用户名", width=200, height=40)
        password_field = ft.TextField(label="密码", password=True, width=200, height=40)
        go_to_login_button = ft.ElevatedButton("登录", on_click=lambda _: show_login(), disabled=True)
        success_message = ft.Text("", color="green", text_align=ft.TextAlign.CENTER)
        show_page("注册", [username_field, password_field], [ft.ElevatedButton("注册", on_click=lambda _: register(username_field, password_field, go_to_login_button, success_message)), go_to_login_button], success_message)

    def show_login():
        username_field = ft.TextField(label="用户名", width=200, height=40)
        password_field = ft.TextField(label="密码", password=True, width=200, height=40)
        go_to_register_button = ft.ElevatedButton("注册", on_click=lambda _: show_register(), disabled=True)
        login_message = ft.Text("", color="red", text_align=ft.TextAlign.CENTER)
        show_page("登录", [username_field, password_field], [ft.ElevatedButton("登录", on_click=lambda _: login(username_field, password_field, go_to_register_button, login_message)), go_to_register_button], login_message)

    def show_main_window(username):
        page.title = f"欢迎，{username}！"
        page.window.width = 1200
        page.window.height = 600
        page.controls.clear()
        page.add(
            ft.Column(
                [
                    ft.Row(
                        [ft.IconButton(Icons.EXIT_TO_APP, tooltip="退出", on_click=lambda _: show_login())],
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=20
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10
            )
        )

    def register(username_field, password_field, go_to_login_button, success_message):
        username = username_field.value
        password = password_field.value
        if not username or not password:
            success_message.value = "用户名和密码不能为空！"
            success_message.color = "red"
        else:
            try:
                c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
                conn.commit()
                success_message.value = "注册成功！"
                success_message.color = "green"
                go_to_login_button.disabled = False
            except sqlite3.IntegrityError:
                success_message.value = "用户已存在！"
                success_message.color = "red"
                go_to_login_button.disabled = False
        page.update()

    def login(username_field, password_field, go_to_register_button, login_message):
        username = username_field.value
        password = password_field.value
        if not username or not password:
            login_message.value = "用户名和密码不能为空！"
            login_message.color = "red"
        else:
            c.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
            user = c.fetchone()
            if user:
                login_message.value = ""
                show_main_window(username)
            else:
                login_message.value = "用户名或密码错误"
                login_message.color = "red"
                go_to_register_button.disabled = False
        page.update()

    def show_register_and_login():
        show_register()

    def close_db(e):
        conn.close()
        page.window.close()

    page.on_close = close_db
    show_login()

ft.app(target=main)