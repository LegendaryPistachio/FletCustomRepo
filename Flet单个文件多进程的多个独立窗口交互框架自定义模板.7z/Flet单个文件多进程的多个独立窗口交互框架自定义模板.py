import flet as ft
from multiprocessing import Process


def start_second_window_1():
    def second_window_1(page: ft.Page):
        page.title = "子窗口 1"
        page.window.always_on_top = True  # 设置窗口始终在最上层
        page.add(ft.Text("我是子窗口 1"))
        page.update()  # 更新页面以应用 always_on_top 设置

    ft.app(target=second_window_1)


def start_second_window_2():
    def second_window_2(page: ft.Page):
        page.title = "子窗口 2"
        page.window.always_on_top = True  # 设置窗口始终在最上层
        page.add(ft.Text("我是子窗口 2"))
        page.update()  # 更新页面以应用 always_on_top 设置

    ft.app(target=second_window_2)


def start_second_window_3():
    def second_window_3(page: ft.Page):
        page.title = "子窗口 3"
        page.window.always_on_top = True  # 设置窗口始终在最上层
        page.add(ft.Text("我是子窗口 3"))
        page.update()  # 更新页面以应用 always_on_top 设置

    ft.app(target=second_window_3)


def open_second_window_1(e):
    Process(target=start_second_window_1, daemon=True).start()


def open_second_window_2(e):
    Process(target=start_second_window_2, daemon=True).start()


def open_second_window_3(e):
    Process(target=start_second_window_3, daemon=True).start()


def main_window(page: ft.Page):
    page.title = "主窗口-Flet单个文件多进程的多个独立窗口交互框架自定义模板"
    page.add(
        ft.ElevatedButton("启动子窗口 1", on_click=open_second_window_1),
        ft.ElevatedButton("启动子窗口 2", on_click=open_second_window_2),
        ft.ElevatedButton("启动子窗口 3", on_click=open_second_window_3),
    )


if __name__ == "__main__":
    ft.app(target=main_window)
