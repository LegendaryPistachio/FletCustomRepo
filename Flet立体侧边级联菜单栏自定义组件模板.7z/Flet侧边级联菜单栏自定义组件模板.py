import flet as ft


def main(page: ft.Page):
    page.title = "Flet Side Cascading Menu Bar Custom Component Template"

    def handle_change(e: ft.ControlEvent):
        print(f"change on panel with index {e.data}")

    def handle_delete(e: ft.ControlEvent):
        panel.controls.remove(e.control.data)
        page.update()

    panel = ft.ExpansionPanelList(
        expand_icon_color=ft.Colors.AMBER,  # 保持展开图标为琥珀色
        elevation=8,
        divider_color=ft.Colors.GREY_300,  # 将分隔线颜色改为灰色
        on_change=handle_change,
        controls=[],
    )

    icons = [
        ft.Icons.FOLDER,
        ft.Icons.FILE_PRESENT,
        ft.Icons.INSERT_DRIVE_FILE,
    ]

    icon_colors = [
        ft.Colors.BLUE,  # 文件夹图标颜色
        ft.Colors.GREEN,  # 文件图标颜色
        ft.Colors.RED,  # 文件插入图标颜色
    ]

    for i in range(3):
        exp = ft.ExpansionPanel(
            bgcolor=ft.Colors.WHITE,  # 设置背景颜色为白色
            header=ft.ListTile(
                leading=ft.Icon(
                    icons[i % len(icons)], color=icon_colors[i % len(icon_colors)]
                ),  # 设置图标颜色
                title=ft.Text(f"Panel {i}"),
            ),
        )

        exp.content = ft.ListTile(
            title=ft.Text(f"This is in Panel {i}"),
            subtitle=ft.Text(f"Press the icon to delete panel {i}"),
            trailing=ft.IconButton(ft.Icons.DELETE, on_click=handle_delete, data=exp),
        )

        panel.controls.append(exp)

    fixed_width = 200  # 设置固定宽度

    # 使用 Container 包裹 ExpansionPanelList 并设置固定宽度
    page.add(
        ft.Container(
            width=fixed_width,
            content=panel,
        )
    )


ft.app(main)
