import flet as ft

def main(page: ft.Page):
    # Set normal_radius and hover_radius to 2/3 of the original size
    normal_radius = 134
    hover_radius = 160
    normal_title_style = ft.TextStyle(
        size=16, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD
    )
    hover_title_style = ft.TextStyle(
        size=22,
        color=ft.Colors.WHITE,
        weight=ft.FontWeight.BOLD,
        shadow=ft.BoxShadow(blur_radius=2, color=ft.Colors.BLACK54),
    )

    # Define scores and total score
    scores = {
        "Math": 85,
        "Science": 90,
        "English": 78,
        "History": 88
    }
    total_score = sum(scores.values())

    def on_chart_event(e: ft.PieChartEvent):
        for idx, section in enumerate(chart.sections):
            if idx == e.section_index:
                section.radius = hover_radius
                section.title_style = hover_title_style
            else:
                section.radius = normal_radius
                section.title_style = normal_title_style
        chart.update()

    # Calculate the percentage of each subject in the total score and create PieChartSection
    sections = [
        ft.PieChartSection(
            (score / total_score) * 100,
            title=f"{subject}: {score} ({(score / total_score) * 100:.2f}%)",
            title_style=normal_title_style,
            color=ft.Colors.with_opacity(0.6, color),
            radius=normal_radius,
        )
        for subject, score, color in zip(scores.keys(), scores.values(), [ft.Colors.BLUE, ft.Colors.YELLOW, ft.Colors.PURPLE, ft.Colors.GREEN])
    ]

    chart = ft.PieChart(
        sections=sections,
        sections_space=0,
        center_space_radius=106.67,  # Set center space radius to 2/3 of the original size
        on_chart_event=on_chart_event,
        expand=True,
    )

    # Create title
    title = ft.Text(
        value="Percentage of Each Subject in Total Score",
        size=24,
        weight=ft.FontWeight.BOLD,
        color=ft.Colors.BLACK,
        text_align=ft.TextAlign.CENTER
    )

    # Create legend
    legend_items = [
        ft.Row(
            [
                ft.Container(
                    width=20,
                    height=20,
                    bgcolor=ft.Colors.with_opacity(0.6, color),
                    border_radius=5
                ),
                ft.Text(subject, size=16, color=ft.Colors.BLACK)
            ],
            alignment=ft.MainAxisAlignment.START
        )
        for subject, color in zip(scores.keys(), [ft.Colors.BLUE, ft.Colors.YELLOW, ft.Colors.PURPLE, ft.Colors.GREEN])
    ]

    legend = ft.Column(
        controls=legend_items,
        alignment=ft.MainAxisAlignment.START,
        spacing=10
    )

    # Create a Column containing the title
    title_column = ft.Column(
        controls=[
            title
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20
    )

    # Create a Column containing the chart and legend, and add a Container above to move the chart down
    chart_column = ft.Column(
        controls=[
            ft.Container(height=100),  # Add a Container to move the chart down
            chart,
            legend
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20
    )

    # Add title and chart with legend to the page
    page.add(
        ft.Column(
            controls=[
                title_column,
                chart_column
            ],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20
        )
    )

ft.app(target=main)