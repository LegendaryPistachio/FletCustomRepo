import flet as ft
import json
import random
from threading import Timer

# 嵌入 poem.json 内容
poem_json_content = '''
{
    "花": [
        "花开两朵，各表一枝。",
        "落花人独立，微雨燕双飞。",
        "人面桃花，世外桃源。"
    ],
    "山水": [
        "山重水复疑无路，柳暗花明又一村。",
        "白日依山尽，黄河入海流。",
        "飞流直下三千尺，疑是银河落九天。"
    ]
}
'''

# 解析 JSON 内容
poem_data = json.loads(poem_json_content)


class PoemApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.page.title = "Flet辅助背古诗应用程序自定义模板"
        self.page.window.width = 380
        self.page.window.height = 600
        self.page.theme_mode = ft.ThemeMode.LIGHT

        # 初始化状态
        self.category = "花"
        self.poems = poem_data[self.category]
        self.index = 0
        self.show_top = True
        self.backs_count = 0
        self.timer = None
        self.random_prompt = False
        self.random_order = False
        self.order = list(range(len(self.poems)))

        # 创建UI
        self.create_widgets()

    def create_widgets(self):
        # 分类选择
        self.category_var = ft.Dropdown(
            label="选择类别:",
            options=[ft.dropdown.Option(k) for k in poem_data.keys()],
            value=self.category,
            on_change=self.change_category,
        )

        # 提示方式选择
        self.prompt_var = ft.RadioGroup(
            content=ft.Column(
                [
                    ft.Radio(value="上半句", label="提示上半句"),
                    ft.Radio(value="下半句", label="提示下半句"),
                    ft.Radio(value="随机", label="随机"),
                ]
            ),
            value="上半句",
        )

        # 出题顺序选择
        self.order_var = ft.RadioGroup(
            content=ft.Column(
                [
                    ft.Radio(value="顺序", label="顺序"),
                    ft.Radio(value="随机", label="随机"),
                ]
            ),
            value="顺序",
        )

        # 显示诗句
        self.poem_label = ft.Text(
            value="",
            size=20,
            text_align=ft.TextAlign.CENTER,
        )

        # 按钮
        self.prev_button = ft.ElevatedButton(
            text="上一句",
            on_click=self.show_prev_poem,
        )
        self.next_button = ft.ElevatedButton(
            text="下一句",
            on_click=self.show_next_poem,
        )
        self.answer_button = ft.ElevatedButton(
            text="显示答案",
            on_click=self.show_answer,
            disabled=True,
        )

        # 背诵计数
        self.counter_label = ft.Text(
            value=f"已背诵句子数: {self.backs_count}",
            size=16,
        )

        # 布局
        self.page.add(
            ft.Column(
                [
                    ft.Row([self.category_var]),
                    ft.Row([self.prompt_var]),
                    ft.Row([self.order_var]),
                    ft.Row([self.poem_label], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Row([self.prev_button, self.answer_button, self.next_button], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Row([self.counter_label], alignment=ft.MainAxisAlignment.CENTER),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            )
        )

        # 显示第一句
        self.show_poem()

    def change_category(self, e: ft.ControlEvent):
        self.category = e.control.value
        self.poems = poem_data[self.category]
        self.index = 0
        self.order = list(range(len(self.poems)))
        if self.order_var.value == "随机":
            random.shuffle(self.order)
        self.show_poem()

    def show_poem(self):
        if self.timer:
            self.timer.cancel()
        poem = self.poems[self.order[self.index]]
        half = len(poem) // 2

        # 随机或固定提示选择
        if self.prompt_var.value == "随机":
            self.show_top = random.choice([True, False])
        else:
            self.show_top = self.prompt_var.value == "上半句"

        if self.show_top:
            prompt = poem[:half] + " " + "_" * (len(poem) - half)
        else:
            prompt = "_" * half + " " + poem[half:]

        self.poem_label.value = prompt
        self.answer_button.disabled = True
        self.timer = Timer(10, self.enable_answer_button)
        self.timer.start()
        self.page.update()

    def enable_answer_button(self):
        self.answer_button.disabled = False
        self.page.update()

    def show_prev_poem(self, e: ft.ControlEvent):
        self.index = (self.index - 1) % len(self.poems)
        self.show_poem()

    def show_next_poem(self, e: ft.ControlEvent):
        self.index = (self.index + 1) % len(self.poems)
        self.backs_count += 1
        self.counter_label.value = f"已背诵句子数: {self.backs_count}"
        self.show_poem()

    def show_answer(self, e: ft.ControlEvent):
        if self.timer:
            self.timer.cancel()
        self.poem_label.value = self.poems[self.order[self.index]]
        self.answer_button.disabled = True
        self.page.update()


def main(page: ft.Page):
    
    app = PoemApp(page)


ft.app(target=main)