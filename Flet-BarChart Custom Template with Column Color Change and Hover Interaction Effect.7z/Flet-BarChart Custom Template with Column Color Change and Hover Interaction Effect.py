import flet as ft

class SampleRod(ft.BarChartRod):
    def __init__(self, y: float, default_color: str, hover_color: str, hovered: bool = False):
        super().__init__()
        self.hovered = hovered
        self.y = y
        self.default_color = default_color
        self.hover_color = hover_color

    def _before_build_command(self):
        self.to_y = self.y + 1 if self.hovered else self.y
        self.color = self.hover_color if self.hovered else self.default_color
        self.border_side = (
            ft.BorderSide(width=1, color=ft.Colors.GREEN_400)
            if self.hovered
            else ft.BorderSide(width=0, color=ft.Colors.WHITE)
        )
        super()._before_build_command()

    def _build(self):
        self.tooltip = str(self.y)
        self.width = 22
        self.bg_to_y = 20
        self.bg_color = ft.Colors.GREEN_300

def main(page: ft.Page):
    page.title = "Flet Bar Chart with Rod Color Change and Hover Interaction Template"
    
    def on_chart_event(e: ft.BarChartEvent):
        """
        Handle chart events.

        This function is triggered when the user interacts with the bar chart. It mainly updates the hover state of the bars in the chart.

        Parameters:
        - e: ft.BarChartEvent object containing information about the event, such as the group index (group_index) and rod index (rod_index) of the bar involved.
        """
        # Traverse all groups and bars in the chart to update the hover state of each bar
        for group_index, group in enumerate(chart.bar_groups):
            for rod_index, rod in enumerate(group.bar_rods):
                # Determine if the current bar is the one involved in the event and update its hover state
                rod.hovered = e.group_index == group_index and e.rod_index == rod_index
        # Update the chart display to reflect the changes in the hover state of the bars
        chart.update()

    # Define the initial and hover colors for each bar
    colors = [
        (ft.Colors.RED, ft.Colors.YELLOW),
        (ft.Colors.BLUE, ft.Colors.CYAN),
        (ft.Colors.GREEN, ft.Colors.LIME),
        (ft.Colors.ORANGE, ft.Colors.AMBER),
        (ft.Colors.PURPLE, ft.Colors.PINK),
        (ft.Colors.BROWN, ft.Colors.ORANGE),
        (ft.Colors.GREY, ft.Colors.BLUE_GREY),
    ]

    # Define the label text for each bar as English names
    names = ["Zhang San", "Li Si", "Wang Wu", "Zhao Liu", "Sun Qi", "Zhou Ba", "Wu Jiu"]

    chart = ft.BarChart(
        bar_groups=[
            ft.BarChartGroup(
                x=0,
                bar_rods=[SampleRod(5, default_color=colors[0][0], hover_color=colors[0][1])],
            ),
            ft.BarChartGroup(
                x=1,
                bar_rods=[SampleRod(6.5, default_color=colors[1][0], hover_color=colors[1][1])],
            ),
            ft.BarChartGroup(
                x=2,
                bar_rods=[SampleRod(5, default_color=colors[2][0], hover_color=colors[2][1])],
            ),
            ft.BarChartGroup(
                x=3,
                bar_rods=[SampleRod(7.5, default_color=colors[3][0], hover_color=colors[3][1])],
            ),
            ft.BarChartGroup(
                x=4,
                bar_rods=[SampleRod(9, default_color=colors[4][0], hover_color=colors[4][1])],
            ),
            ft.BarChartGroup(
                x=5,
                bar_rods=[SampleRod(11.5, default_color=colors[5][0], hover_color=colors[5][1])],
            ),
            ft.BarChartGroup(
                x=6,
                bar_rods=[SampleRod(6, default_color=colors[6][0], hover_color=colors[6][1])],
            ),
        ],
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(value=0, label=ft.Text(names[0])),
                ft.ChartAxisLabel(value=1, label=ft.Text(names[1])),
                ft.ChartAxisLabel(value=2, label=ft.Text(names[2])),
                ft.ChartAxisLabel(value=3, label=ft.Text(names[3])),
                ft.ChartAxisLabel(value=4, label=ft.Text(names[4])),
                ft.ChartAxisLabel(value=5, label=ft.Text(names[5])),
                ft.ChartAxisLabel(value=6, label=ft.Text(names[6])),
            ],
        ),
        on_chart_event=on_chart_event,
        interactive=True,
    )

    # Add chart title
    title = ft.Text("Weekly Sales Data", size=24, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER)

    # Manually create legend
    legend_items = [
        ft.Row(
            [
                ft.Container(
                    bgcolor=color,
                    width=20,
                    height=20,
                    border_radius=5,
                ),
                ft.Text(name, size=14),
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=10,
        )
        for color, name in zip([c[0] for c in colors], names)
    ]

    legend = ft.Row(
        controls=legend_items,
        alignment=ft.MainAxisAlignment.START,
        spacing=20,
    )

    # Add chart, title, and legend to the page
    page.add(
        ft.Column(
            [
                title,
                ft.Container(
                    chart, bgcolor=ft.Colors.GREEN_200, padding=10, border_radius=5, expand=True
                ),
                legend
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True
        )
    )

ft.app(main)