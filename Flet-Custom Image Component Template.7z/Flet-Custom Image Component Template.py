# Import the Flet library
import flet as ft


# Define the custom image class MyImg
class MyImg(ft.Image):
    def __init__(self, src):
        super().__init__()
        self.src = src
        self.width = 200
        self.height = 300
        self.fit = ft.ImageFit.FIT_WIDTH
        self.repeat = ft.ImageRepeat.NO_REPEAT
        self.border_radius = ft.border_radius.all(10)


# Define the main function
def main(page: ft.Page):
    page.title = "Flet Custom Image Component Template"
    # Create a Row widget and set its properties
    img_row = ft.Row(
        expand=1,  # Expand to available space
        wrap=False,  # Do not wrap
        scroll="always",  # Always show scrollbar
        width=800,  # Width
        height=200,  # Height
    )

    # Add multiple MyImg instances to the Row
    img_row.controls.append(
        MyImg(src="https://scpic.chinaz.net/files/pic/pic9/201911/zzpic21562.jpg")
    )
    img_row.controls.append(
        MyImg(src="https://scpic.chinaz.net/files/pic/pic9/201912/zzpic21916.jpg")
    )
    img_row.controls.append(
        MyImg(src="https://scpic.chinaz.net/files/pic/pic9/201809/zzpic14406.jpg")
    )
    img_row.controls.append(
        MyImg(src="https://scpic.chinaz.net/files/pic/pic9/201808/zzpic13648.jpg")
    )
    img_row.controls.append(
        MyImg(src="https://scpic.chinaz.net/files/pic/pic9/201806/zzpic12256.jpg")
    )

    # Add the Row to the page
    page.add(img_row)


# Run the application
ft.app(target=main)
