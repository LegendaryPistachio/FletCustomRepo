import asyncio
import sys
import uuid

import flet as ft

child_id = str(uuid.uuid4())
reader, writer = None, None


async def handle_():
    global reader, writer
    reader, writer = await asyncio.open_connection('127.0.0.1', 18585)
    writer.write(child_id.encode('utf-8'))
    while True:
        data = await reader.read(100)
        if data.decode() == 'bye':
            print(1111)
            writer.close()
            await writer.wait_closed()
            sys.exit(0)


async def main(page: ft.Page):
    page.run_task(handle_)

    def on_click(e):
        global reader, writer
        writer.write(('exit==' + child_id).encode())

    page.title = "子界面"
    page.add(
        ft.Text(child_id),
        ft.TextButton(text="关闭", on_click=on_click),
        ft.ProgressBar(width=400, color="amber", bgcolor="#eeeeee"),
    )


ft.app(target=main)
