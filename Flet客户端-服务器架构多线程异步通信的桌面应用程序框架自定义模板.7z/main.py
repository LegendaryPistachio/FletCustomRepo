import os
import socket
import threading

import flet as ft

child_dict = {}
cs, ca = None, None
d = ft.Dropdown()


def find_option(option_name):
    for option in d.options:
        if option_name == option.key:
            return option
    return None


def handle(cas, css, page):
    while True:
        data: str = css.recv(1024).decode()
        print(data)
        if not data:
            break
        if data.split('==')[0] == 'exit':
            css.sendall(b'bye')
            value = data.split('==')[1]
            del child_dict[value]
            option = find_option(value)
            if option is not None:
                d.options.remove(option)
            page.update()


def start_socket(page):
    global cs, ca
    server = socket.socket()
    server.bind(("127.0.0.1", 18585))
    server.listen(5)
    while True:
        cs, ca = server.accept()
        print(ca)

        child_id = cs.recv(1024).decode()
        print(child_id)
        child_dict[child_id] = cs
        d.options.append(ft.dropdown.Option(child_id))
        d.value = child_id
        page.update()

        threading.Thread(target=handle, args=(ca, cs, page)).start()


def main(page: ft.Page):
    threading.Thread(target=start_socket, args=(page,)).start()

    def start_child_win(event):
        os.system('python child.py')

    def close_child_win(event):
        global child_dict
        child_dict[d.value].send("bye".encode())
        del child_dict[d.value]
        option = find_option(d.value)
        if option is not None:
            d.options.remove(option)
            page.update()

    page.title = "主界面"
    page.add(
        d,
        ft.TextButton(text="启动", on_click=start_child_win),
        ft.TextButton(text="关闭", on_click=close_child_win),
    )


ft.app(target=main)
