import random
import string
import flet as ft


def generate_random_data(num_lines, line_length):
    """
    Generate a specified number of lines of random string data
    :param num_lines: Number of lines to generate
    :param line_length: Length of each string line
    :return: List containing random strings
    """
    data = []
    for _ in range(num_lines):
        random_string = "".join(
            random.choices(string.ascii_letters + string.digits, k=line_length)
        )
        data.append(random_string)
    return data


def do(num_lines, line_length, output_file):
    """
    Execute the operation to generate random data and save it to a file
    :param num_lines: Number of lines to generate
    :param line_length: Length of each string line
    :param output_file: Output file path
    """
    try:
        data = generate_random_data(num_lines, line_length)
        with open(output_file, "w") as file:
            for line in data:
                file.write(line + "\n")
        print(
            f"Successfully generated {num_lines} lines of random data and saved to {output_file}"
        )
    except Exception as e:
        print(f"Error occurred while generating random data: {e}")


def main(page: ft.Page):
    page.title = "Random Data Generator"
    page.vertical_alignment = ft.MainAxisAlignment.START  # Change to top alignment
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    num_lines_input = ft.TextField(label="Number of Lines", value="10")
    line_length_input = ft.TextField(label="Length of Each Line", value="20")
    output_file_input = ft.TextField(label="Output File Path", value="random_data.txt")
    result_label = ft.Text()

    def generate_click(e):
        try:
            num_lines = int(num_lines_input.value)
            line_length = int(line_length_input.value)
            output_file = output_file_input.value
            do(num_lines, line_length, output_file)
            result_label.value = f"Successfully generated {num_lines} lines of random data and saved to {output_file}"
        except ValueError:
            result_label.value = "Please enter valid numbers"
        except Exception as e:
            result_label.value = f"Error occurred while generating random data: {e}"
        page.update()

    generate_button = ft.ElevatedButton(text="Generate", on_click=generate_click)

    page.add(
        ft.Column(
            [
                num_lines_input,
                line_length_input,
                output_file_input,
                generate_button,
                result_label,
            ],
            alignment=ft.MainAxisAlignment.START,  # Change to top alignment
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )


ft.app(target=main)
