import flet as ft
import time
from time import strftime


def main(page: ft.Page):
    # Window settings
    page.window.frameless = True  # Set window to be frameless
    page.window.bgcolor = (
        ft.Colors.TRANSPARENT
    )  # Set window background to be transparent
    page.bgcolor = ft.Colors.TRANSPARENT  # Set page background to be transparent
    # Set window size
    page.window.width = 200
    page.window.height = 100

    # Center the window
    page.window.center()

    def update_clock():
        timelabel.value = strftime("%H:%M:%S")
        datelabel.value = strftime("%A, %e %B")
        page.update()

    timelabel = ft.Text(
        value="", color=ft.Colors.WHITE, size=40, font_family="NovaMono"
    )
    datelabel = ft.Text(
        value="", color=ft.Colors.WHITE, size=15, font_family="Bahnschrift"
    )

    page.add(
        ft.Column(
            [timelabel, datelabel],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True,
        )
    )

    page.update()
    update_clock()

    while True:
        time.sleep(1)
        update_clock()


ft.app(target=main)
