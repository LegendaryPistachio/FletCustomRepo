import flet as ft


def main(page: ft.Page):
    normal_border = ft.BorderSide(0, ft.Colors.with_opacity(0, ft.Colors.WHITE))
    hovered_border = ft.BorderSide(6, ft.Colors.WHITE)

    def on_chart_event(e: ft.PieChartEvent):
        for idx, section in enumerate(chart.sections):
            section.border_side = (
                hovered_border if idx == e.section_index else normal_border
            )
        chart.update()

    # Simulated data
    scores = {
        "Fill-in-the-Blank": 10,
        "Multiple Choice": 26,
        "Multiple Answer": 21,
        "True/False": 12,
        "Short Answer": 10,
    }

    # Color mapping
    colors = {
        "Fill-in-the-Blank": ft.Colors.BLUE,
        "Multiple Choice": ft.Colors.YELLOW,
        "Multiple Answer": ft.Colors.PINK,
        "True/False": ft.Colors.GREEN,
        "Short Answer": ft.Colors.ORANGE,
    }

    chart = ft.PieChart(
        sections=[
            ft.PieChartSection(
                scores["Fill-in-the-Blank"],
                color=colors["Fill-in-the-Blank"],
                radius=160,  # Enlarged by a factor of two
                border_side=normal_border,
                title="Fill-in-the-Blank",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.68,  # Manually set title position
            ),
            ft.PieChartSection(
                scores["Multiple Choice"],
                color=colors["Multiple Choice"],
                radius=130,  # Enlarged by a factor of two
                border_side=normal_border,
                title="Multiple Choice",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.5,  # Manually set title position
            ),
            ft.PieChartSection(
                scores["Multiple Answer"],
                color=colors["Multiple Answer"],
                radius=120,  # Enlarged by a factor of two
                border_side=normal_border,
                title="Multiple Answer",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.6,  # Manually set title position
            ),
            ft.PieChartSection(
                scores["True/False"],
                color=colors["True/False"],
                radius=140,  # Enlarged by a factor of two
                border_side=normal_border,
                title="True/False",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.5,  # Manually set title position
            ),
            ft.PieChartSection(
                scores["Short Answer"],
                color=colors["Short Answer"],
                radius=110,  # Enlarged by a factor of two
                border_side=normal_border,
                title="ShortAnswer",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.65,  # Manually set title position
            ),
        ],
        sections_space=1,
        center_space_radius=0,
        on_chart_event=on_chart_event,
        expand=True,
    )

    # Chart title
    chart_title = ft.Text(
        value="Mastery of Different Question Types",
        size=24,
        weight=ft.FontWeight.BOLD,
        text_align=ft.TextAlign.CENTER,
    )

    # Legend
    legend_items = [
        ft.Row(
            [
                ft.Container(
                    width=20, height=20, bgcolor=colors[label], border_radius=5
                ),
                ft.Text(value=label, size=16),
            ],
            alignment=ft.MainAxisAlignment.START,
        )
        for label in scores.keys()
    ]

    legend = ft.Column(controls=legend_items, alignment=ft.MainAxisAlignment.START)

    # Add chart, title, and legend to the page
    page.add(
        ft.Column(
            [chart_title, chart, legend],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )


ft.app(target=main)
