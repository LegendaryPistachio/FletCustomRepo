import flet as ft

class SampleRod(ft.BarChartRod):
    def __init__(self, y: float, default_color: str, hover_color: str, hovered: bool = False):
        super().__init__()
        self.hovered = hovered
        self.y = y
        self.default_color = default_color
        self.hover_color = hover_color

    def _before_build_command(self):
        self.to_y = self.y + 1 if self.hovered else self.y
        self.color = self.hover_color if self.hovered else self.default_color
        self.border_side = (
            ft.BorderSide(width=1, color=ft.Colors.GREEN_400)
            if self.hovered
            else ft.BorderSide(width=0, color=ft.Colors.WHITE)
        )
        super()._before_build_command()

    def _build(self):
        self.tooltip = str(self.y)
        self.width = 22
        self.bg_to_y = 20
        self.bg_color = ft.Colors.GREEN_300

def main(page: ft.Page):
    page.title = "Flet带柱子颜色变化带悬停交互效果的条形图自定义模板"
    
    def on_chart_event(e: ft.BarChartEvent):
        """
        处理柱状图事件的函数。

        当用户与柱状图交互时，此函数会被触发。它主要负责根据事件信息更新柱状图中柱子的悬浮状态。

        参数:
        - e: ft.BarChartEvent 类型的事件对象，包含触发事件的柱状图柱子的相关信息，如组索引(group_index)和柱子索引(rod_index)。
        """
        # 遍历柱状图中的所有组和柱子，以更新每个柱子的悬浮状态
        for group_index, group in enumerate(chart.bar_groups):
            for rod_index, rod in enumerate(group.bar_rods):
                # 判断当前柱子是否为事件所涉及的柱子，并更新其悬浮状态
                rod.hovered = e.group_index == group_index and e.rod_index == rod_index
        # 更新柱状图的显示，以反映柱子悬浮状态的变化
        chart.update()

    # 定义每个柱子的初始颜色和悬停颜色
    colors = [
        (ft.Colors.RED, ft.Colors.YELLOW),
        (ft.Colors.BLUE, ft.Colors.CYAN),
        (ft.Colors.GREEN, ft.Colors.LIME),
        (ft.Colors.ORANGE, ft.Colors.AMBER),
        (ft.Colors.PURPLE, ft.Colors.PINK),
        (ft.Colors.BROWN, ft.Colors.ORANGE),
        (ft.Colors.GREY, ft.Colors.BLUE_GREY),
    ]

    # 定义每个柱子的标签文字为中文人名
    names = ["张三", "李四", "王五", "赵六", "孙七", "周八", "吴九"]

    chart = ft.BarChart(
        bar_groups=[
            ft.BarChartGroup(
                x=0,
                bar_rods=[SampleRod(5, default_color=colors[0][0], hover_color=colors[0][1])],
            ),
            ft.BarChartGroup(
                x=1,
                bar_rods=[SampleRod(6.5, default_color=colors[1][0], hover_color=colors[1][1])],
            ),
            ft.BarChartGroup(
                x=2,
                bar_rods=[SampleRod(5, default_color=colors[2][0], hover_color=colors[2][1])],
            ),
            ft.BarChartGroup(
                x=3,
                bar_rods=[SampleRod(7.5, default_color=colors[3][0], hover_color=colors[3][1])],
            ),
            ft.BarChartGroup(
                x=4,
                bar_rods=[SampleRod(9, default_color=colors[4][0], hover_color=colors[4][1])],
            ),
            ft.BarChartGroup(
                x=5,
                bar_rods=[SampleRod(11.5, default_color=colors[5][0], hover_color=colors[5][1])],
            ),
            ft.BarChartGroup(
                x=6,
                bar_rods=[SampleRod(6, default_color=colors[6][0], hover_color=colors[6][1])],
            ),
        ],
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(value=0, label=ft.Text(names[0])),
                ft.ChartAxisLabel(value=1, label=ft.Text(names[1])),
                ft.ChartAxisLabel(value=2, label=ft.Text(names[2])),
                ft.ChartAxisLabel(value=3, label=ft.Text(names[3])),
                ft.ChartAxisLabel(value=4, label=ft.Text(names[4])),
                ft.ChartAxisLabel(value=5, label=ft.Text(names[5])),
                ft.ChartAxisLabel(value=6, label=ft.Text(names[6])),
            ],
        ),
        on_chart_event=on_chart_event,
        interactive=True,
    )

    # 添加图表标题
    title = ft.Text("一周销售数据", size=24, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER)

    # 手动创建图例
    legend_items = [
        ft.Row(
            [
                ft.Container(
                    bgcolor=color,
                    width=20,
                    height=20,
                    border_radius=5,
                ),
                ft.Text(name, size=14),
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=10,
        )
        for color, name in zip([c[0] for c in colors], names)
    ]

    legend = ft.Row(
        controls=legend_items,
        alignment=ft.MainAxisAlignment.START,
        spacing=20,
    )

    # 将图表、标题和图例添加到页面
    page.add(
        ft.Column(
            [
                title,
                ft.Container(
                    chart, bgcolor=ft.Colors.GREEN_200, padding=10, border_radius=5, expand=True
                ),
                legend
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True
        )
    )

ft.app(main)