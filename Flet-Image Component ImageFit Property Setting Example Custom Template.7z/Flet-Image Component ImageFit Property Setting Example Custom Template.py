import flet as ft


def main(page: ft.Page):
    page.title = (
        "Flet Image Component ImageFit Property Setting Example Custom Template"
    )
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 50
    page.update()

    # Define an image path
    image_path = "icons/timg.png"

    # Create a column layout to display the effects of different ImageFit options
    col = ft.Column(
        alignment=ft.MainAxisAlignment.START,
        horizontal_alignment=ft.CrossAxisAlignment.START,
        spacing=20,  # Increase spacing to better view each image
        scroll=ft.ScrollMode.ALWAYS,  # Add scrollbar to view all examples
        width=400,  # Set the width of the column
        height=600,  # Set the height of the column
    )

    # Add initial ImageFit examples
    image_fits = [
        (
            "ImageFit.NONE-Image does not scale, may exceed container boundaries",
            ft.ImageFit.NONE,
        ),
        (
            "ImageFit.CONTAIN-Image scales to fully contain within the container, maintaining the original aspect ratio",
            ft.ImageFit.CONTAIN,
        ),
        (
            "ImageFit.COVER-Image scales to cover the entire container, may crop part of the image",
            ft.ImageFit.COVER,
        ),
        (
            "ImageFit.FILL-Image fills the entire container, does not maintain the original aspect ratio",
            ft.ImageFit.FILL,
        ),
        (
            "ImageFit.FIT_HEIGHT-Image height scales to the container height, width maintains the aspect ratio",
            ft.ImageFit.FIT_HEIGHT,
        ),
        (
            "ImageFit.FIT_WIDTH-Image width scales to the container width, height maintains the aspect ratio.",
            ft.ImageFit.FIT_WIDTH,
        ),
        (
            "ImageFit.SCALE_DOWN-Image scales down to fit the container but does not exceed the original size.",
            ft.ImageFit.SCALE_DOWN,
        ),
    ]

    for label, fit in image_fits:
        col.controls.extend(
            [
                ft.Text(label, size=20),
                ft.Container(
                    content=ft.Image(
                        src=image_path,
                        fit=fit,
                        width=200,
                        height=200,
                    ),
                    width=200,
                    height=250,  # Adjust height to accommodate image and text
                    border=ft.border.all(1, ft.Colors.BLACK),  # Use Colors enum
                ),
            ]
        )

    # Add column layout to the page
    page.add(col)

    page.update()


ft.app(main)
