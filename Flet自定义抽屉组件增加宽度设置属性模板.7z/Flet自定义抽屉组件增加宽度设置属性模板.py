import flet as ft

def main(page: ft.Page):
    page.title = "Flet自定义抽屉组件增加宽度设置属性模板"
    page.horizontal_alignment = ft.CrossAxisAlignment.START
    drawer_width = 300  # 自定义抽屉宽度

    def open_drawer(e):
        drawer.left = 0  # 抽屉滑出
        overlay.visible = True
        page.update()

    def close_drawer(e):
        drawer.left = -drawer_width  # 抽屉滑回
        overlay.visible = False
        page.update()

    # 抽屉内容
    drawer = ft.Container(
        width=drawer_width,
        height=page.window.height,
        bgcolor=ft.Colors.WHITE,
        left=-drawer_width,
        animate=ft.animation.Animation(300, "easeOut"),
        content=ft.Column(
            controls=[
                ft.Container(height=20),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.HOME),
                    title=ft.Text("首页"),
                    on_click=lambda e: print("首页点击"),
                ),
                ft.Divider(),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.MAIL),
                    title=ft.Text("邮件"),
                    on_click=lambda e: print("邮件点击"),
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.PHONE),
                    title=ft.Text("电话"),
                    on_click=lambda e: print("电话点击"),
                ),
            ]
        ),
        shadow=None,  # 不使用阴影
    )

    # 半透明遮罩层
    overlay = ft.Container(
        visible=False,
        on_click=close_drawer,
        bgcolor=ft.Colors.BLACK54,
        expand=True,
        animate_opacity=300,
    )

    # 使用Stack布局组织元素
    page.add(
        ft.Stack(
            controls=[
                # 主内容
                ft.Column(
                    controls=[
                        ft.ElevatedButton(
                            "打开抽屉",
                            icon=ft.Icons.MENU,
                            on_click=open_drawer,
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=10),
                            ),
                        ),
                        ft.Text("主内容区域..."),
                    ],
                    expand=True,
                ),
                overlay,
                drawer,
            ],
            expand=True,
        )
    )

    # 初始化页面
    page.update()

ft.app(target=main)
