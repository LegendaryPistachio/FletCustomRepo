import flet as ft

def main(page: ft.Page):
    normal_border = ft.BorderSide(0, ft.Colors.with_opacity(0, ft.Colors.WHITE))
    hovered_border = ft.BorderSide(6, ft.Colors.WHITE)

    def on_chart_event(e: ft.PieChartEvent):
        for idx, section in enumerate(chart.sections):
            section.border_side = (
                hovered_border if idx == e.section_index else normal_border
            )
        chart.update()

    # 模拟数据
    scores = {
        "填空题": 10,
        "单选题": 26,
        "多选题": 21,
        "判断题": 12,
        "简答题": 10
    }

    # 颜色映射
    colors = {
        "填空题": ft.Colors.BLUE,
        "单选题": ft.Colors.YELLOW,
        "多选题": ft.Colors.PINK,
        "判断题": ft.Colors.GREEN,
        "简答题": ft.Colors.ORANGE
    }

    chart = ft.PieChart(
        sections=[
            ft.PieChartSection(
                scores["填空题"],
                color=colors["填空题"],
                radius=160,  # 放大一倍
                border_side=normal_border,
                title="填空题",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.5,  # 手动设置标题位置
            ),
            ft.PieChartSection(
                scores["单选题"],
                color=colors["单选题"],
                radius=130,  # 放大一倍
                border_side=normal_border,
                title="单选题",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.5,  # 手动设置标题位置
            ),
            ft.PieChartSection(
                scores["多选题"],
                color=colors["多选题"],
                radius=120,  # 放大一倍
                border_side=normal_border,
                title="多选题",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.5,  # 手动设置标题位置
            ),
            ft.PieChartSection(
                scores["判断题"],
                color=colors["判断题"],
                radius=140,  # 放大一倍
                border_side=normal_border,
                title="判断题",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.5,  # 手动设置标题位置
            ),
            ft.PieChartSection(
                scores["简答题"],
                color=colors["简答题"],
                radius=110,  # 放大一倍
                border_side=normal_border,
                title="简答题",
                title_style=ft.TextStyle(color=ft.Colors.BLACK),
                title_position=0.5,  # 手动设置标题位置
            ),
        ],
        sections_space=1,
        center_space_radius=0,
        on_chart_event=on_chart_event,
        expand=True,
    )

    # 图表标题
    chart_title = ft.Text(
        value="不同题型的掌握程度",
        size=24,
        weight=ft.FontWeight.BOLD,
        text_align=ft.TextAlign.CENTER
    )

    # 图例
    legend_items = [
        ft.Row(
            [
                ft.Container(
                    width=20,
                    height=20,
                    bgcolor=colors[label],
                    border_radius=5
                ),
                ft.Text(value=label, size=16)
            ],
            alignment=ft.MainAxisAlignment.START
        )
        for label in scores.keys()
    ]

    legend = ft.Column(
        controls=legend_items,
        alignment=ft.MainAxisAlignment.START
    )

    # 将图表、标题和图例添加到页面
    page.add(
        ft.Column(
            [
                chart_title,
                chart,
                legend
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

ft.app(target=main)