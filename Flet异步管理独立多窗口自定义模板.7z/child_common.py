import asyncio
import flet as ft


async def handle_(child_id, reader, writer, page):
    page.title = f"子窗口 {child_id}"
    page.window.always_on_top = True  # 设置窗口始终在最上层
    await page.add_async(ft.Text(f"这是子窗口 {child_id}"))  # 使用 await
    while True:
        data = await reader.read(100)
        message = data.decode()
        if message == "bye":
            break
        print(f"Received: {message}")
    writer.close()
    await writer.wait_closed()


async def setup_child_window(page, child_id):
    reader, writer = await asyncio.open_connection("127.0.0.1", 18585)
    await handle_(child_id, reader, writer, page)  # 使用 await
