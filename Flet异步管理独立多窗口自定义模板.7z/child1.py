import asyncio
import flet as ft
from child_common import setup_child_window


async def main(page: ft.Page):
    await setup_child_window(page, "child1")


ft.app(target=main)
