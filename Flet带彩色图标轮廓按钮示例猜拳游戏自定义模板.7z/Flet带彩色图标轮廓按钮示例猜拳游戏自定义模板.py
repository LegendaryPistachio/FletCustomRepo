import flet as ft
import random

def main(page: ft.Page):
    page.title = "Flet带彩色图标轮廓按钮示例猜拳游戏自定义模板"

    # 初始化结果标签
    result_label = ft.Text(value="请选择一个选项", size=16)

    # 定义猜拳逻辑
    def play_game(user_choice):
        choices = ["✊", "✌️", "✋"]  # 将文字替换为图标字符
        computer_choice = random.choice(choices)
        if user_choice == computer_choice:
            result = "平局"
        elif (user_choice == "✊" and computer_choice == "✌️") or \
             (user_choice == "✌️" and computer_choice == "✋") or \
             (user_choice == "✋" and computer_choice == "✊"):
            result = "你赢了 😀"  # 添加笑脸字符图标
        else:
            result = "你输了 😢"  # 添加哭字符图标
        result_label.value = f"你选择了： {user_choice}, 电脑选择了： {computer_choice}，结果是： {result}"
        page.update()

    page.add(
        ft.Row(
            [
                ft.OutlinedButton("石头", icon="pan_tool_outlined", icon_color="red400", on_click=lambda e: play_game("✊")),
                ft.OutlinedButton("剪刀", icon="content_cut_outlined", icon_color="yellow400", on_click=lambda e: play_game("✌️")),
                ft.OutlinedButton("布", icon="crop_free_outlined", icon_color="blue400", on_click=lambda e: play_game("✋")),
            ]
        ),
        result_label  # 添加结果标签
    )

ft.app(target=main)