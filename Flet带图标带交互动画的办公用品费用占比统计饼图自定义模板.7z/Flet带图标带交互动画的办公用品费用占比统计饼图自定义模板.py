import flet as ft

def main(page: ft.Page):
    page.title = "Flet带图标带交互动画的办公用品费用占比统计饼图自定义模板"
    normal_radius = 100
    hover_radius = 110
    normal_title_style = ft.TextStyle(
        size=12, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD
    )
    hover_title_style = ft.TextStyle(
        size=16,
        color=ft.Colors.WHITE,
        weight=ft.FontWeight.BOLD,
        shadow=ft.BoxShadow(blur_radius=2, color=ft.Colors.BLACK54),
    )
    normal_badge_size = 40
    hover_badge_size = 50

    def badge(icon, size):
        return ft.Container(
            ft.Icon(icon),
            width=size,
            height=size,
            border=ft.border.all(1, ft.Colors.BROWN),
            border_radius=size / 2,
            bgcolor=ft.Colors.WHITE,
        )

    def on_chart_event(e: ft.PieChartEvent):
        for idx, section in enumerate(chart.sections):
            if idx == e.section_index:
                section.radius = hover_radius
                section.title_style = hover_title_style
            else:
                section.radius = normal_radius
                section.title_style = normal_title_style
        chart.update()

    chart = ft.PieChart(
        sections=[
            ft.PieChartSection(
                20,
                title="20%",
                title_style=normal_title_style,
                color=ft.Colors.BLUE,
                radius=normal_radius,
                badge=badge(ft.Icons.DESKTOP_WINDOWS, normal_badge_size),  # 台式机
                badge_position=0.98,
            ),
            ft.PieChartSection(
                25,
                title="25%",
                title_style=normal_title_style,
                color=ft.Colors.YELLOW,
                radius=normal_radius,
                badge=badge(ft.Icons.LAPTOP, normal_badge_size),  # 笔记本电脑
                badge_position=0.98,
            ),
            ft.PieChartSection(
                15,
                title="15%",
                title_style=normal_title_style,
                color=ft.Colors.GREEN,
                radius=normal_radius,
                badge=badge(ft.Icons.PRINT, normal_badge_size),  # 打印机
                badge_position=0.98,
            ),
            ft.PieChartSection(
                20,
                title="20%",
                title_style=normal_title_style,
                color=ft.Colors.PURPLE,
                radius=normal_radius,
                badge=badge(ft.Icons.SCANNER, normal_badge_size),  # 扫描仪
                badge_position=0.98,
            ),
            ft.PieChartSection(
                20,
                title="20%",
                title_style=normal_title_style,
                color=ft.Colors.ORANGE,
                radius=normal_radius,
                badge=badge(ft.Icons.TABLET_ANDROID, normal_badge_size),  # 平板
                badge_position=0.98,
            ),
        ],
        sections_space=0,
        center_space_radius=0,
        on_chart_event=on_chart_event,
        expand=True,
    )

    # 图表标题
    chart_title = ft.Text(
        value="办公用品费用占比统计",
        size=24,
        weight=ft.FontWeight.BOLD,
        color=ft.Colors.BLACK,
        text_align=ft.TextAlign.CENTER
    )

    # 图例
    legend_items = [
        ft.Row([
            ft.Container(
                width=20,
                height=20,
                bgcolor=color,
                border_radius=5
            ),
            ft.Text(label, size=14, color=ft.Colors.BLACK)
        ])
        for color, label in [
            (ft.Colors.BLUE, "台式机"),
            (ft.Colors.YELLOW, "笔记本电脑"),
            (ft.Colors.GREEN, "打印机"),
            (ft.Colors.PURPLE, "扫描仪"),
            (ft.Colors.ORANGE, "平板")
        ]
    ]

    legend = ft.Column(
        controls=legend_items,
        alignment=ft.MainAxisAlignment.START,
        spacing=10
    )

    # 整合图表、标题和图例
    page.add(
        ft.Column(
            [
                chart_title,
                chart,
                legend
            ],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20
        )
    )

ft.app(target=main)