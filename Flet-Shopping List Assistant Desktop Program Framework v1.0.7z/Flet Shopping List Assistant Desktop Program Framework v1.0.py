import flet as ft
import sqlite3
import os

# Constant Definitions
DB_NAME = 'shopping_list.db'
PRIMARY_COLOR = ft.colors.GREEN_500
SECONDARY_COLOR = ft.colors.GREEN_400
BG_COLOR = ft.colors.WHITE
WINDOW_WIDTH = 1248
WINDOW_HEIGHT = 840

class ShoppingListApp:
    def __init__(self):
        self.page = None
        self.items = []
        self.current_tab = None
        self.name_field = None
        self.list_view = None
        self.data_table = None
        self.tab_contents = None

    def init_db(self):
        if not os.path.exists(DB_NAME):
            with sqlite3.connect(DB_NAME) as conn:
                c = conn.cursor()
                c.execute('''CREATE TABLE items (name TEXT, checked INTEGER)''')

    def add_item_to_db(self, name, checked=0):
        with sqlite3.connect(DB_NAME) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO items VALUES (?, ?)", (name, checked))

    def get_items_from_db(self):
        with sqlite3.connect(DB_NAME) as conn:
            c = conn.cursor()
            c.execute("SELECT * FROM items")
            return [{"name": row[0], "checked": bool(row[1])} for row in c.fetchall()]

    def update_item_in_db(self, name, checked):
        with sqlite3.connect(DB_NAME) as conn:
            c = conn.cursor()
            c.execute("UPDATE items SET checked = ? WHERE name = ?", (int(checked), name))

    def delete_item_from_db(self, name):
        with sqlite3.connect(DB_NAME) as conn:
            c = conn.cursor()
            c.execute("DELETE FROM items WHERE name = ?", (name,))

    def add_item_to_list(self, e):
        item_name = self.name_field.value
        if item_name:
            self.add_item_to_db(item_name)
            self.items = self.get_items_from_db()
            self.update_list_view()
            self.name_field.value = ""
            self.page.update()

    def update_list_view(self):
        self.items = self.get_items_from_db()
        self.list_view.controls.clear()
        for item in self.items:
            checkbox = ft.Checkbox(value=item["checked"])
            checkbox.on_change = lambda e, item=item: self.toggle_item_status(e, item)
            
            # Create a centered text control
            centered_text = ft.Container(
                content=ft.Text(item["name"], size=16),
                alignment=ft.alignment.center,
                expand=True
            )
            
            # Place the checkbox and text in a horizontal row
            row = ft.Row(
                controls=[
                    checkbox,
                    centered_text
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                width=780  # Set a fixed width, slightly less than the container width
            )
            
            # Wrap the row in a container
            item_container = ft.Container(
                content=row,
                alignment=ft.alignment.center,
                width=800,
                border=ft.border.all(1, ft.colors.GREY_400),
                border_radius=5,
                padding=5
            )
            
            self.list_view.controls.append(item_container)
        self.page.update()

    def update_data_table(self, e=None):
        self.items = self.get_items_from_db()
        self.data_table.rows.clear()
        for item in self.items:
            status = "Purchased" if item["checked"] else "Not Purchased"
            self.data_table.rows.append(
                ft.DataRow(cells=[ft.DataCell(ft.Text(item["name"])), ft.DataCell(ft.Text(status))])
            )
        self.page.update()

    def toggle_item_status(self, e, item):
        item["checked"] = e.control.value
        self.update_item_in_db(item["name"], item["checked"])
        self.page.update()

    def delete_selected_items(self, e):
        for item in self.items:
            if item["checked"]:
                self.delete_item_from_db(item["name"])
        self.items = self.get_items_from_db()
        self.update_list_view()

    def tab_clicked(self, e):
        tab_text = e.control.content.controls[1].controls[0].value
        print(f"{tab_text} tab clicked")

        if self.current_tab:
            self.current_tab.bgcolor = PRIMARY_COLOR
        
        self.current_tab = e.control
        self.current_tab.bgcolor = SECONDARY_COLOR
        self.page.update()

        content_container = self.page.controls[0].content.controls[1]
        content_container.clean()
        content_container.controls.append(self.tab_contents[tab_text])
        
        if tab_text == "My Selections":
            self.update_list_view()
        elif tab_text == "List Details":
            self.update_data_table()
        
        self.page.update()

    def create_app_title(self):
        app_title_row = ft.Row(
            controls=[
                ft.IconButton(ft.icons.SHOPPING_CART, tooltip="Shopping Cart", icon_color=BG_COLOR),
                ft.Text("Shopping List Assistant Desktop Program 1.0", color=BG_COLOR, size=16)
            ],
            alignment=ft.MainAxisAlignment.START
        )
        close_button = ft.IconButton(
            ft.icons.CLOSE,
            tooltip="Close",
            icon_color=ft.colors.RED,
            on_click=lambda _: self.page.window.close()
        )
        icons_row = ft.Row(
            controls=[
                ft.IconButton(ft.icons.ADD, tooltip="Add", icon_color=ft.colors.GREEN, on_click=self.add_item_to_list),
                ft.IconButton(ft.icons.HELP, tooltip="Help", icon_color=ft.colors.BLUE, on_click=lambda _: print("Help button clicked")),
                ft.IconButton(ft.icons.INFO, tooltip="About", icon_color=ft.colors.RED, on_click=lambda _: print("About button clicked")),
                close_button
            ],
            alignment=ft.MainAxisAlignment.END
        )
        return ft.Container(
            content=ft.Row(
                controls=[app_title_row, icons_row],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                height=50,
                width=1200
            ),
            bgcolor=PRIMARY_COLOR,
            padding=10,
        )

    def create_tabs(self):
        return ft.Row(
            [
                self.create_tab(text="My Selections", icon_path="gg.png", on_click=self.tab_clicked),
                self.create_tab(text="List Details", icon_path="hh.png", on_click=self.tab_clicked),
                self.create_tab(text="Add Product", icon_path="ii.png", on_click=self.tab_clicked),
                self.create_tab(text="Save Product", icon_path="jj.png", on_click=self.tab_clicked),
                self.create_tab(text="Delete Product", icon_path="kk.png", on_click=self.tab_clicked),
                self.create_tab(text="Contact Us", icon_path="ll.png", on_click=self.tab_clicked),
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=0,
            width=1260
        )

    def create_tab(self, text, icon_path, on_click):
        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(controls=[ft.Image(src=icon_path, width=64, height=64)], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Row(controls=[ft.Text(text, color=BG_COLOR, size=16)], alignment=ft.MainAxisAlignment.CENTER)
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=5
            ),
            bgcolor=PRIMARY_COLOR,
            height=200,
            width=200,
            on_click=on_click,
            ink=True
        )

    def create_layout(self):
        self.name_field = ft.TextField(label="Please enter the product name", width=500)
        self.list_view = ft.ListView(expand=1, spacing=10, padding=10, auto_scroll=True)
        self.data_table = ft.DataTable(
            columns=[ft.DataColumn(ft.Text("Product Name")), ft.DataColumn(ft.Text("Status"))],
            rows=[],
        )

        my_selections_content = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Container(
                        height=100,
                        content=ft.Row(
                            controls=[
                                self.name_field,
                                ft.IconButton(ft.icons.ADD, tooltip="Add", icon_color=ft.colors.GREEN, on_click=self.add_item_to_list),
                                ft.IconButton(ft.icons.SAVE, tooltip="Save", icon_color=ft.colors.BLUE, on_click=self.update_data_table),
                                ft.IconButton(ft.icons.DELETE, tooltip="Delete", icon_color=ft.colors.RED, on_click=self.delete_selected_items)
                            ],
                            alignment=ft.MainAxisAlignment.CENTER
                        )
                    ),
                    ft.Container(
                        content=self.list_view,
                        width=800,
                        height=400,
                        border=ft.border.all(1, ft.colors.GREY_400),
                        border_radius=5,
                        padding=10
                    )
                ],
                spacing=10,
                alignment=ft.MainAxisAlignment.START,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            width=1200,
            height=522,
            bgcolor=ft.colors.WHITE,
            padding=10,
        )

        contact_us_content = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Container(
                        content=ft.Image(src="logo.jpg", width=200, height=200, fit=ft.ImageFit.COVER),
                        width=200, height=200, border_radius=100, clip_behavior=ft.ClipBehavior.ANTI_ALIAS, margin=50
                    ),
                    ft.Text("Shopping List Assistant Desktop Program 1.0", size=20, weight=ft.FontWeight.BOLD),
                    ft.Text("Creative programming based on FLet by Legendary Pistachio", size=16),
                    ft.Text("Completed at home in Guazhou on October 14, 2024", size=16),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=20,
            ),
            alignment=ft.alignment.center,
            width=1200,
            height=522,
            bgcolor=ft.colors.WHITE,
            padding=10,
        )

        self.tab_contents = {
            "My Selections": my_selections_content,
            "List Details": ft.Container(
                content=ft.Column(
                    controls=[
                        ft.Container(content=ft.Text("Product List", size=20, weight=ft.FontWeight.BOLD), alignment=ft.alignment.center),
                        ft.Container(
                            content=ft.ListView(
                                [
                                    ft.Container(
                                        content=self.data_table,
                                        width=800,
                                    )
                                ],
                                expand=1,
                                spacing=10,
                                padding=20,
                                auto_scroll=True
                            ),
                            width=800,
                            height=400,
                            border=ft.border.all(1, ft.colors.GREY_400),
                            border_radius=5,
                        )
                    ],
                    spacing=20,
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
                width=1200,
                height=522,
                bgcolor=ft.colors.WHITE,
                padding=10,
            ),
            "Add Product": ft.Container(
                content=ft.Text("This is the Add Product page"),
                width=1200,
                height=522,
                bgcolor=ft.colors.WHITE,
                padding=10,
                alignment=ft.alignment.center
            ),
            "Save Product": ft.Container(
                content=ft.Text("This is the Save Product page"),
                width=1200,
                height=522,
                bgcolor=ft.colors.WHITE,
                padding=10,
                alignment=ft.alignment.center
            ),
            "Delete Product": ft.Container(
                content=ft.Text("This is the Delete Product page"),
                width=1200,
                height=522,
                bgcolor=ft.colors.WHITE,
                padding=10,
                alignment=ft.alignment.center
            ),
            "Contact Us": contact_us_content,
        }

        return ft.Column(controls=[self.create_app_title(), self.create_tabs()], spacing=0)

    def main(self, page: ft.Page):
        self.page = page
        self.init_db()
        self.items = self.get_items_from_db()
        
        self.page.window.width = WINDOW_WIDTH
        self.page.window.height = WINDOW_HEIGHT
        self.page.window.frameless = True
        self.page.window.resizable = False
        
        self.page.bgcolor = BG_COLOR
        self.page.padding = 20

        main_container = ft.Container(
            content=ft.Column(spacing=0),
            expand=True,
            bgcolor=ft.colors.GREY_200,
            border=ft.border.all(2, PRIMARY_COLOR),
            padding=2
        )

        content_container = ft.Column()

        layout_column = self.create_layout()
        main_container.content.controls.extend([layout_column, content_container])
        self.page.add(main_container)

        # Default selection of "My Selections" tab and load data
        self.current_tab = layout_column.controls[1].controls[0]
        self.current_tab.bgcolor = SECONDARY_COLOR
        content_container.controls.append(self.tab_contents["My Selections"])
        self.update_list_view()

if __name__ == "__main__":
    app = ShoppingListApp()
    ft.app(target=app.main)