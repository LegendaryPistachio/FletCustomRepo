import flet as ft


def main(page: ft.Page):
    page.title = "Flet Responsive Row Component Example - Book Management System Responsive Row Layout Custom Template"

    def page_resized(e):
        pw.value = f"{page.width} px"
        pw.update()

    page.on_resized = page_resized

    pw = ft.Text(bottom=50, right=50, style="displaySmall")
    page.overlay.append(pw)
    page.add(
        ft.ResponsiveRow(
            [
                ft.Container(
                    ft.TextButton(
                        text="Search Books",
                        icon=ft.Icons.SEARCH,
                        on_click=lambda e: print("Search Books"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.YELLOW,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
                ft.Container(
                    ft.TextButton(
                        text="Add Books",
                        icon=ft.Icons.ADD,
                        on_click=lambda e: print("Add Books"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.GREEN,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
                ft.Container(
                    ft.TextButton(
                        text="Delete Books",
                        icon=ft.Icons.DELETE,
                        on_click=lambda e: print("Delete Books"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.BLUE,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
                ft.Container(
                    ft.TextButton(
                        text="Modify Books",
                        icon=ft.Icons.EDIT,
                        on_click=lambda e: print("Modify Books"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.PINK_300,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
            ],
        ),
        ft.ResponsiveRow(
            [
                ft.TextField(
                    label="Search", prefix_icon=ft.Icons.SEARCH, col={"md": 4}
                ),
                ft.TextField(label="Book Name", col={"md": 4}),
                ft.TextField(label="Author", col={"md": 4}),
            ],
            run_spacing={"xs": 10},
        ),
    )
    page_resized(None)


ft.app(target=main)
