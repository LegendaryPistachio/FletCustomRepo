import flet as ft
import time

def main(page: ft.Page):
    page.title = "Heart Seesaw Animation"
    
    # Create a Stack control
    stack = ft.Stack()

    # Create two heart icons, reduced to half the original size
    heart1 = ft.Icon(ft.icons.FAVORITE, size=50, color=ft.colors.RED)  # Originally 100
    heart2 = ft.Icon(ft.icons.FAVORITE, size=50, color=ft.colors.RED)  # Originally 100

    # Set the initial positions of the heart icons
    heart1.left = 50  # Heart 1 on the left
    heart1.top = 100
    heart2.left = 150  # Heart 2 on the right
    heart2.top = 100

    # Add the heart icons to the Stack control
    stack.controls.append(heart1)
    stack.controls.append(heart2)

    # Add the Stack control to the page
    page.add(stack)

    # Animation loop
    while True:
        for i in range(20):
            heart1.top -= 2  # Heart 1 moves up
            heart2.top += 2  # Heart 2 moves down
            page.update()
            time.sleep(0.05)

        for i in range(20):
            heart1.top += 2  # Heart 1 moves down
            heart2.top -= 2  # Heart 2 moves up
            page.update()
            time.sleep(0.05)

ft.app(target=main)