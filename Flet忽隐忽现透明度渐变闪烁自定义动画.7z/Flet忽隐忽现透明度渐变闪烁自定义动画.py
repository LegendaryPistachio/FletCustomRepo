import flet as ft
import asyncio

def main(page: ft.Page):

    c = ft.Container(
        width=150,
        height=150,
        bgcolor="white",
        border_radius=10,
        animate_opacity=100,  # 设置动画不透明度的速度
        content=ft.Image(src="fletlogo.png", width=150, height=150),  # 加载logo图片
    )

    async def animate_blink():
        while True:
            c.opacity = 0  # 完全透明
            await c.update_async()
            await asyncio.sleep(1)  # 等待1秒
            c.opacity = 1  # 完全不透明
            await c.update_async()
            await asyncio.sleep(0.5)  # 等待0.5秒

    async def start_blink(e):
        asyncio.create_task(animate_blink())

    page.add(c)

    # 启动闪烁效果
    page.add(ft.ElevatedButton("Start Blinking", on_click=start_blink))

ft.app(target=main)