# file:c:\Users\lxmcq\Desktop\Flet字体粗细FontWeight属性设置枚举示例自定义模板.py
import flet as ft


def main(page: ft.Page):
    page.title = "Flet字体粗细FontWeight属性设置枚举示例自定义模板"
    page.padding = 30

    # 创建包含不同字重的文本组件
    text_samples = ft.Column(
        controls=[
            ft.Text("NORMAL - 默认正常字重", weight=ft.FontWeight.NORMAL),
            ft.Text("BOLD - 加粗字重", weight=ft.FontWeight.BOLD),
            ft.Text("W_100 - 细体", weight=ft.FontWeight.W_100),
            ft.Text("W_200 - 较轻", weight=ft.FontWeight.W_200),
            ft.Text("W_300 - 轻体", weight=ft.FontWeight.W_300),
            ft.Text("W_400 - 常规（同NORMAL）", weight=ft.FontWeight.W_400),
            ft.Text("W_500 - 中等", weight=ft.FontWeight.W_500),
            ft.Text("W_600 - 半粗", weight=ft.FontWeight.W_600),
            ft.Text("W_700 - 加粗（同BOLD）", weight=ft.FontWeight.W_700),
            ft.Text("W_800 - 更粗", weight=ft.FontWeight.W_800),
            ft.Text("W_900 - 最粗", weight=ft.FontWeight.W_900),
        ],
        spacing=10,
    )

    # 添加说明文本
    description = ft.Text(
        "注意：实际效果取决于字体是否支持对应字重，字重就是字体粗细程度的一种描述方式。",
        italic=True,
        color=ft.Colors.GREY_600,  # 修改这里
    )

    page.add(text_samples, description)


ft.app(target=main)
