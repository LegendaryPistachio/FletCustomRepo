import flet as ft
import time
from threading import Thread

def main(page: ft.Page):
    page.title = "Flet-Custom Image Carousel Component Template"
    # List of local image paths
    images = [
        'desktop computer.jpg',
        'smartphone2.jpg',
        'smartearbuds2.jpg',
        'laptop.jpg',
        'smartband1.jpg',
        'smartband2.jpg',  
        'smartphone1.jpg',
        'smartphone3.jpg'
    ]
    
    # Current displayed image index
    current_index = 0
    
    # Image control
    image_control = ft.Image(
        src=images[current_index],
        width=400,
        height=300,
        fit=ft.ImageFit.CONTAIN
    )
    
    # Function to update the image
    def update_image():
        nonlocal current_index
        while True:
            time.sleep(3)  # Switch image every 3 seconds
            current_index = (current_index + 1) % len(images)
            image_control.src = images[current_index]
            page.update()  # Update the page
    
    # Start a thread to automatically update the image
    thread = Thread(target=update_image, daemon=True)
    thread.start()
    
    # Add the image control to the page
    page.add(image_control)

# Run the application
ft.app(target=main)