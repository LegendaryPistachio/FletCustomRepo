import flet as ft

def open_main(page):
    page.clean()
    page.add(
        ft.Text("Main Window"),
        ft.ElevatedButton(text="Open Window 1", on_click=lambda e: open_window1(page)),
        ft.ElevatedButton(text="Open Window 2", on_click=lambda e: open_window2(page)),
        ft.ElevatedButton(text="Open Window 3", on_click=lambda e: open_window3(page))
    )

def open_window1(page):
    page.clean()
    page.add(
        ft.Text("Window 1"),
        ft.ElevatedButton(text="Back to Main", on_click=lambda e: open_main(page))
    )

def open_window2(page):
    page.clean()
    page.add(
        ft.Text("Window 2"),
        ft.ElevatedButton(text="Back to Main", on_click=lambda e: open_main(page))
    )

def open_window3(page):
    page.clean()
    page.add(
        ft.Text("Window 3"),
        ft.ElevatedButton(text="Back to Main", on_click=lambda e: open_main(page))
    )

def main(page: ft.Page):
    page.title = "Flet事件驱动模型管理多窗口自定义组件模板"
    
    # 初始化页面
    open_main(page)

# 运行应用
ft.app(target=main)