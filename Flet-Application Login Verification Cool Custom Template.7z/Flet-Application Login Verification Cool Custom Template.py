import flet as ft
from flet import (
    Page,
    TextField,
    Checkbox,
    ElevatedButton,
    Text,
    Row,
    Column,
    ControlEvent,
    app,
)


def main(page: ft.Page):
    # Set page background and theme
    def login_page():
        # Set page basic properties
        page.title = "Flet Application Login Verification Cool Custom Template"
        page.vertical_alignment = ft.MainAxisAlignment.CENTER
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.theme = ft.Theme(color_scheme_seed=ft.Colors.BLUE)
        page.window.width = 1000
        page.window.height = 700
        page.window.resizable = False
        page.bgcolor = ft.Colors.WHITE

        # Save references to input field components
        text_username = TextField(
            label="Username",
            text_align=ft.TextAlign.LEFT,
            width=300,
            prefix_icon=ft.Icons.PERSON_OUTLINE,
            border=ft.InputBorder.UNDERLINE,
            hint_text="Enter your username",
        )

        text_password = TextField(
            label="Password",
            text_align=ft.TextAlign.LEFT,
            width=300,
            password=True,
            can_reveal_password=True,
            prefix_icon=ft.Icons.LOCK_OUTLINE,
            border=ft.InputBorder.UNDERLINE,
            hint_text="Enter your password",
        )

        checkbox_signup = Checkbox(
            label="I have read and agree to the user agreement and privacy policy",
            value=False,
            fill_color=ft.Colors.BLUE,
        )

        button_submit = ElevatedButton(
            content=ft.Text("Login", size=16, weight=ft.FontWeight.W_500),
            style=ft.ButtonStyle(
                color=ft.Colors.WHITE,
                bgcolor=ft.Colors.BLUE,
                padding=ft.padding.symmetric(horizontal=100, vertical=20),
            ),
            width=300,
            disabled=True,
        )

        # Create login card
        login_card = ft.Container(
            width=400,
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    # Logo and title
                    ft.Icon(
                        ft.Icons.ACCOUNT_CIRCLE_ROUNDED, size=80, color=ft.Colors.BLUE
                    ),
                    ft.Text(
                        "User Login",
                        size=28,
                        weight=ft.FontWeight.BOLD,
                        color=ft.Colors.BLUE_900,
                    ),
                    ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
                    # Username input field
                    ft.Container(
                        content=text_username, margin=ft.margin.only(bottom=10)
                    ),
                    # Password input field
                    ft.Container(
                        content=text_password, margin=ft.margin.only(bottom=20)
                    ),
                    # Agreement checkbox
                    ft.Container(
                        content=checkbox_signup, margin=ft.margin.only(bottom=20)
                    ),
                    # Login button
                    ft.Container(content=button_submit),
                    # Bottom text
                    ft.Container(
                        content=ft.Text(
                            "hhhhhh System v1.0",
                            size=12,
                            color=ft.Colors.GREY_600,
                        ),
                        margin=ft.margin.only(top=30),
                    ),
                ],
                spacing=5,
            ),
            padding=40,
            bgcolor=ft.Colors.WHITE,
            border_radius=8,
            shadow=ft.BoxShadow(
                spread_radius=1,
                blur_radius=15,
                color=ft.Colors.BLUE_GREY_100,
            ),
        )

        def validate(e: ControlEvent) -> None:
            if all([text_username.value, text_password.value, checkbox_signup.value]):
                button_submit.disabled = False
            else:
                button_submit.disabled = True
            page.update()

        def submit(e: ControlEvent) -> None:
            # Show loading animation
            progress_ring = ft.ProgressRing()
            page.overlay.append(progress_ring)
            page.update()

            print("Username:", text_username.value)
            print("Password:", text_password.value)

            # Remove loading animation
            page.overlay.remove(progress_ring)
            page.clean()

        # Bind event handlers
        checkbox_signup.on_change = validate
        text_username.on_change = validate
        text_password.on_change = validate
        button_submit.on_click = submit

        # Add login card to the page
        page.add(
            ft.Container(
                content=login_card,
                alignment=ft.alignment.center,
            )
        )
        # Initialize display of login page

    login_page()


ft.app(target=main)
