import flet as ft

def main(page: ft.Page):
    def create_custom_switch(scale: float = 1.0, label: str = ""):
        return ft.Row(
            [
                ft.Container(
                    content=ft.Switch(),
                    scale=scale,
                    alignment=ft.alignment.center,
                ),
                ft.Text(label) if label else None
            ],
            alignment=ft.MainAxisAlignment.START,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    small_switch = create_custom_switch(0.5, "Small Switch")
    normal_switch = create_custom_switch(0.8, "Normal Size Switch")
    large_switch = create_custom_switch(1.1, "Large Switch")
    extra_large_switch = create_custom_switch(1.4, "Extra Large Switch")

    page.add(small_switch, normal_switch, large_switch, extra_large_switch)

ft.app(target=main)