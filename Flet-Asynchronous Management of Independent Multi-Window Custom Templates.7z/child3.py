import flet as ft
from child_common import setup_child_window

child_id = "child3"


async def main(page: ft.Page):
    await setup_child_window(page, child_id)


ft.app(target=main)
