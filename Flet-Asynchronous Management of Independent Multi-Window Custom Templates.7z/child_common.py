import asyncio
import flet as ft


async def handle_(child_id, reader, writer, page):
    page.title = f"Child Window {child_id}"
    page.window.always_on_top = True  # Set the window to always be on top
    await page.add_async(ft.Text(f"This is Child Window {child_id}"))  # Use await
    while True:
        data = await reader.read(100)
        message = data.decode()
        if message == "bye":
            break
        print(f"Received: {message}")
    writer.close()
    await writer.wait_closed()


async def setup_child_window(page, child_id):
    reader, writer = await asyncio.open_connection("127.0.0.1", 18585)
    await handle_(child_id, reader, writer, page)  # Use await
