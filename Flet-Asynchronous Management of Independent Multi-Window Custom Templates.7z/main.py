import os
import threading
import flet as ft
import asyncio


# Assume you have a function to start the socket service
def start_socket(page):
    async def handle_client(reader, writer):
        data = await reader.read(100)
        message = data.decode()
        addr = writer.get_extra_info("peername")
        print(f"Received {message} from {addr}")
        if message == "bye":
            writer.close()
            await writer.wait_closed()
        else:
            response = f"Echo: {message}"
            writer.write(response.encode())
            await writer.drain()

    async def main():
        server = await asyncio.start_server(handle_client, "127.0.0.1", 18585)
        async with server:
            await server.serve_forever()

    asyncio.run(main())


def start_child_win(event, child_script):
    os.system(f"python {child_script}")


async def main(page: ft.Page):
    threading.Thread(target=start_socket, args=(page,)).start()

    page.title = "Main Interface - Flet Asynchronous Management Independent Multi-Window Custom Template"
    page.add(
        ft.TextButton(
            text="Start Child Window 1",
            on_click=lambda e: start_child_win(e, "child1.py"),
        ),
        ft.TextButton(
            text="Start Child Window 2",
            on_click=lambda e: start_child_win(e, "child2.py"),
        ),
        ft.TextButton(
            text="Start Child Window 3",
            on_click=lambda e: start_child_win(e, "child3.py"),
        ),
    )


ft.app(target=main)
