import flet as ft
from flet import Icons, Colors

def create_app_title(page):
    return ft.Container(
        content=ft.Row(
            controls=[
                ft.Row(
                    controls=[
                        ft.IconButton(ft.icons(Icons.SHOPPING_CART), tooltip="Shopping Cart", icon_color=ft.colors(Colors.WHITE)),
                        ft.Text("Flet Custom Title Bar", color=ft.colors(Colors.WHITE), size=16)
                    ],
                    alignment=ft.MainAxisAlignment.START
                ),
                ft.Row(
                    controls=[
                        ft.IconButton(ft.icons(Icons.ADD), tooltip="Add", icon_color=ft.colors(Colors.GREEN), on_click=lambda _: print("Add button clicked")),
                        ft.IconButton(ft.icons(Icons.HELP), tooltip="Help", icon_color=ft.colors(Colors.BLUE), on_click=lambda _: print("Help button clicked")),
                        ft.IconButton(ft.icons(Icons.INFO), tooltip="About", icon_color=ft.colors(Colors.RED), on_click=lambda _: print("About button clicked")),
                        ft.IconButton(ft.icons(Icons.CLOSE), tooltip="Close", icon_color=ft.colors(Colors.RED), on_click=lambda _: page.window.close())
                    ],
                    alignment=ft.MainAxisAlignment.END
                )
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            height=50,
            width=1200
        ),
        bgcolor=ft.colors(Colors.GREEN_500),
        padding=10,
    )

def main(page: ft.Page):
    page.window.frameless = True
    page.add(create_app_title(page))

if __name__ == "__main__":
    ft.app(target=main)