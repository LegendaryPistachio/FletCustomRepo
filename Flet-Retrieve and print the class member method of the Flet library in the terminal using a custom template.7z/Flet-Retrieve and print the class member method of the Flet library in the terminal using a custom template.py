import flet
import inspect

classes = [name for name, obj in inspect.getmembers(flet) if inspect.isclass(obj)]
for cls in classes:
    print(cls)
