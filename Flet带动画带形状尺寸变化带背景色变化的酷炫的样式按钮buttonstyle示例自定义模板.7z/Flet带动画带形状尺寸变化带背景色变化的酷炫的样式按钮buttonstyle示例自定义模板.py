import flet as ft


def main(page: ft.Page):
    page.title = (
        "Flet带动画带形状尺寸变化带背景色变化的酷炫的样式按钮buttonstyle示例自定义模板"
    )

    page.add(
        ft.FilledButton(
            "Styled button 1",
            style=ft.ButtonStyle(
                color={
                    ft.ControlState.HOVERED: ft.Colors.WHITE,
                    ft.ControlState.FOCUSED: ft.Colors.BLUE,
                    ft.ControlState.DEFAULT: ft.Colors.BLACK,
                },
                bgcolor={
                    ft.ControlState.HOVERED: ft.Colors.PURPLE,  # 修改悬停时的背景颜色为紫色
                    ft.ControlState.DEFAULT: ft.Colors.YELLOW,  # 修改默认状态下的背景颜色为黄色
                },
                padding={ft.ControlState.HOVERED: 20},
                overlay_color=ft.Colors.TRANSPARENT,
                elevation={"pressed": 0, "": 1},
                animation_duration=500,
                side={
                    ft.ControlState.DEFAULT: ft.BorderSide(1, ft.Colors.BLUE),
                    ft.ControlState.HOVERED: ft.BorderSide(2, ft.Colors.BLUE),
                },
                shape={
                    ft.ControlState.HOVERED: ft.RoundedRectangleBorder(radius=20),
                    ft.ControlState.DEFAULT: ft.BeveledRectangleBorder(
                        radius=10
                    ),  # 修改默认形状为 BeveledRectangleBorder
                },
            ),
        )
    )


ft.app(main)
