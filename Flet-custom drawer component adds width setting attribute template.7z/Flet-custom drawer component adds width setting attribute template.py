import flet as ft

def main(page: ft.Page):
    page.title = "Flet Custom Drawer Component with Width Setting Attribute Template"
    page.horizontal_alignment = ft.CrossAxisAlignment.START
    drawer_width = 300  # Custom drawer width

    def open_drawer(e):
        drawer.left = 0  # Drawer slides out
        overlay.visible = True
        page.update()

    def close_drawer(e):
        drawer.left = -drawer_width  # Drawer slides back
        overlay.visible = False
        page.update()

    # Drawer content
    drawer = ft.Container(
        width=drawer_width,
        height=page.window.height,
        bgcolor=ft.Colors.WHITE,
        left=-drawer_width,
        animate=ft.animation.Animation(300, "easeOut"),
        content=ft.Column(
            controls=[
                ft.Container(height=20),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.HOME),
                    title=ft.Text("Home"),
                    on_click=lambda e: print("Home clicked"),
                ),
                ft.Divider(),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.MAIL),
                    title=ft.Text("Mail"),
                    on_click=lambda e: print("Mail clicked"),
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.PHONE),
                    title=ft.Text("Phone"),
                    on_click=lambda e: print("Phone clicked"),
                ),
            ]
        ),
        shadow=None,  # No shadow
    )

    # Semi-transparent overlay
    overlay = ft.Container(
        visible=False,
        on_click=close_drawer,
        bgcolor=ft.Colors.BLACK54,
        expand=True,
        animate_opacity=300,
    )

    # Organize elements using Stack layout
    page.add(
        ft.Stack(
            controls=[
                # Main content
                ft.Column(
                    controls=[
                        ft.ElevatedButton(
                            "Open Drawer",
                            icon=ft.Icons.MENU,
                            on_click=open_drawer,
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=10),
                            ),
                        ),
                        ft.Text("Main content area..."),
                    ],
                    expand=True,
                ),
                overlay,
                drawer,
            ],
            expand=True,
        )
    )

    # Initialize page
    page.update()

ft.app(target=main)