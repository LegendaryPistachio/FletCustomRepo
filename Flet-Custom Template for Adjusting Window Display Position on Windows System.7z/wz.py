import flet as ft


def main(page):
    # Set window title
    page.title = "Flet Custom Template for Adjusting Window Position on Windows System"

    # Set window size
    page.window.width = 800
    page.window.height = 600

    # Adjust window position
    page.window.left = 500  # Distance from the left
    page.window.top = 400  # Distance from the top

    # Add components
    page.add(ft.Text("Welcome to the Flet framework!"))


# Run the application
ft.app(target=main)
