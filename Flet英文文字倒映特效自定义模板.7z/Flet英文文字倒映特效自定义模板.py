import flet as ft
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import base64

# 创建倒影效果的函数
def create_reflected_text(text: str, font_family: str, font_size: int, text_color: tuple, background_color: tuple, gap: int):
    # 使用根目录下的 MISTRAL.TTF 字体路径
    font_path = "MISTRAL.TTF"
    
    # 打印字体文件路径进行调试
    print(f"Font path: {font_path}")
    
    # 加载字体
    try:
        font = ImageFont.truetype(font_path, font_size)
    except OSError as e:
        print(f"Error loading font: {e}")
        return None
    
    # 获取文本尺寸
    text_bbox = font.getbbox(text)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    
    # 创建原始文本图像
    original_image = Image.new('RGBA', (text_width, text_height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(original_image)
    draw.text((0, 0), text, fill=text_color, font=font)
    
    # 创建倒影图像
    reflected_image = original_image.transpose(Image.FLIP_TOP_BOTTOM)
    
    # 创建最终图像
    total_height = text_height * 2 + gap
    final_image = Image.new('RGBA', (text_width, total_height), background_color)
    
    # 粘贴原始文本
    final_image.paste(original_image, (0, 0), original_image)
    
    # 粘贴倒影文本
    final_image.paste(reflected_image, (0, text_height + gap), reflected_image)
    
    # 创建遮罩
    mask = Image.new('L', (text_width, total_height), 255)
    mask_draw = ImageDraw.Draw(mask)
    for i in range(text_height):
        alpha = int(255 * (1 - i / text_height))
        mask_draw.line([(0, text_height + gap + i), (text_width, text_height + gap + i)], fill=alpha)
    
    # 应用遮罩
    final_image.putalpha(mask)
    
    return final_image

# 主函数
def main(page: ft.Page):
    # 设置页面标题
    page.title = "Text Reflection Example"
    
    # 创建文字倒影图像
    text = "Hello, Flet"
    font_family = "MISTRAL.TTF"  # 使用 MISTRAL.TTF 字体
    font_size = 150
    text_color = (0, 102, 204)  # blue-500
    background_color = (255, 255, 255)  # 白色
    gap = 10  # 文字和倒影之间的间距
    
    image = create_reflected_text(text, font_family, font_size, text_color, background_color, gap)
    
    if image is None:
        print("Failed to create reflected text image")
        return
    
    # 将图像转换为字节流
    byte_arr = BytesIO()
    image.save(byte_arr, format='PNG')
    byte_arr.seek(0)
    
    # 将字节流转换为 base64 编码的字符串
    img_base64 = base64.b64encode(byte_arr.read()).decode('utf-8')
    
    # 创建 Flet 图像组件
    img = ft.Image(src_base64=img_base64, width=image.width, height=image.height)
    
    # 添加图像到页面
    page.add(img)

# 运行应用
if __name__ == "__main__":
    ft.app(target=main)