import flet as ft

class CustomTab(ft.Control):
    def __init__(self, title, content_text, sub_menu_items, page):
        super().__init__()
        self.title = title
        self.content_text = content_text
        self.sub_menu_items = sub_menu_items
        self.page = page
        self.is_active = False
        self._build()

    def _build(self):
        self.tab_button = ft.TextButton(
            text=self.title,
            on_click=self.switch_tab,
            style=ft.ButtonStyle(
                color={"hovered": ft.Colors.BLUE},
                bgcolor={"active": ft.Colors.BLUE_100}
            )
        )
        
        # 将子菜单项分成每行四个按钮
        rows = []
        for i in range(0, len(self.sub_menu_items), 4):
            row_items = self.sub_menu_items[i:i+4]
            rows.append(ft.Row(row_items, alignment=ft.MainAxisAlignment.START))
        
        self.sub_menu_rows = rows
        
        for row in self.sub_menu_rows:
            row.visible = self.is_active
        
        # 创建内容文本控件
        self.content_label = ft.Text(value=self.content_text, expand=True)
        
        self.container = ft.Container(
            content=ft.Column([*self.sub_menu_rows, self.content_label], expand=True),
            visible=self.is_active,
            expand=True
        )

    def switch_tab(self, e):
        self.is_active = not self.is_active
        for row in self.sub_menu_rows:
            row.visible = self.is_active
        self.container.visible = self.is_active
        self.content_label.visible = self.is_active
        self.update()
        self.page.update()  # 强制更新整个页面

    def build(self):
        return ft.Column([self.tab_button, self.container])

def main(page: ft.Page):
    # 设置页面标题
    page.title = "Flet自定义桌面程序组件Custom Ribbon组件模板"
    
    # 定义按钮样式
    button_style = {
        "height": 40,
        "width": 90,
        "style": ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=5)
        )
    }

    # 创建文件选项卡内容
    file_sub_menu_items = [
        ft.TextButton(text="新建", icon=ft.Icons.CREATE_NEW_FOLDER, on_click=lambda _: print("新建文件"), **button_style),
        ft.TextButton(text="打开", icon=ft.Icons.FOLDER_OPEN, on_click=lambda _: print("打开文件"), **button_style),
        ft.TextButton(text="保存", icon=ft.Icons.SAVE, on_click=lambda _: print("保存文件"), **button_style),
        ft.TextButton(text="另存为", icon=ft.Icons.SAVE_AS, on_click=lambda _: print("另存为文件"), **button_style),
        ft.TextButton(text="打印", icon=ft.Icons.PRINT, on_click=lambda _: print("打印文件"), **button_style),
        ft.TextButton(text="导出", icon=ft.Icons.IMPORT_EXPORT, on_click=lambda _: print("导出文件"), **button_style),
        ft.TextButton(text="导入", icon=ft.Icons.UPLOAD_FILE, on_click=lambda _: print("导入文件"), **button_style),
        ft.TextButton(text="删除", icon=ft.Icons.DELETE, on_click=lambda _: print("删除文件"), **button_style),
    ]
    file_content_text = "这是文件页面"

    # 创建编辑选项卡内容
    edit_sub_menu_items = [
        ft.TextButton(text="剪切", icon=ft.Icons.CONTENT_CUT, on_click=lambda _: print("执行剪切"), **button_style),
        ft.TextButton(text="复制", icon=ft.Icons.CONTENT_COPY, on_click=lambda _: print("执行复制"), **button_style),
        ft.TextButton(text="粘贴", icon=ft.Icons.CONTENT_PASTE, on_click=lambda _: print("执行粘贴"), **button_style),
        ft.TextButton(text="撤销", icon=ft.Icons.UNDO, on_click=lambda _: print("撤销操作"), **button_style),
        ft.TextButton(text="重做", icon=ft.Icons.REDO, on_click=lambda _: print("重做操作"), **button_style),
        ft.TextButton(text="查找", icon=ft.Icons.SEARCH, on_click=lambda _: print("查找内容"), **button_style),
        ft.TextButton(text="替换", icon=ft.Icons.EDIT, on_click=lambda _: print("替换内容"), **button_style),  # 替换图标
        ft.TextButton(text="选择全部", icon=ft.Icons.SELECT_ALL, on_click=lambda _: print("选择全部内容"), **button_style),
    ]
    edit_content_text = "这是编辑页面"

    # 创建视图选项卡内容
    view_sub_menu_items = [
        ft.TextButton(text="放大", icon=ft.Icons.ZOOM_IN, on_click=lambda _: print("放大视图"), **button_style),
        ft.TextButton(text="缩小", icon=ft.Icons.ZOOM_OUT, on_click=lambda _: print("缩小视图"), **button_style),
        ft.TextButton(text="全屏", icon=ft.Icons.FULLSCREEN, on_click=lambda _: print("切换全屏"), **button_style),
        ft.TextButton(text="恢复", icon=ft.Icons.FULLSCREEN_EXIT, on_click=lambda _: print("退出全屏"), **button_style),
        ft.TextButton(text="实际大小", icon=ft.Icons.PHOTO_SIZE_SELECT_ACTUAL, on_click=lambda _: print("实际大小"), **button_style),
        ft.TextButton(text="适合宽度", icon=ft.Icons.PHOTO_SIZE_SELECT_LARGE, on_click=lambda _: print("适合宽度"), **button_style),
        ft.TextButton(text="适合高度", icon=ft.Icons.PHOTO_SIZE_SELECT_SMALL, on_click=lambda _: print("适合高度"), **button_style),
        ft.TextButton(text="重置视图", icon=ft.Icons.PAN_TOOL, on_click=lambda _: print("重置视图"), **button_style),
    ]
    view_content_text = "这是视图页面"

    # 创建自定义选项卡
    file_tab = CustomTab("文件", file_content_text, file_sub_menu_items, page)
    edit_tab = CustomTab("编辑", edit_content_text, edit_sub_menu_items, page)
    view_tab = CustomTab("视图", view_content_text, view_sub_menu_items, page)

    # 初始化第一个选项卡为激活状态
    file_tab.is_active = True
    file_tab.container.visible = True
    for row in file_tab.sub_menu_rows:
        row.visible = True
    file_tab.content_label.visible = True

    # 创建选项卡标题栏
    tab_titles = ft.Row([
        file_tab.tab_button,
        edit_tab.tab_button,
        view_tab.tab_button,
    ], alignment=ft.MainAxisAlignment.START)

    # 创建主布局
    main_layout = ft.Column([
        tab_titles,
        ft.Divider(height=1, color=ft.Colors.GREY_300),
        ft.Column([
            file_tab.container,
            edit_tab.container,
            view_tab.container,
        ], expand=True)
    ])

    # 添加主布局到页面
    page.add(main_layout)

    # 定义一个方法来切换选项卡
    def switch_to_tab(tab):
        for t in [file_tab, edit_tab, view_tab]:
            if t == tab:
                t.is_active = True
                t.container.visible = True
                for row in t.sub_menu_rows:
                    row.visible = True
                t.content_label.visible = True
            else:
                t.is_active = False
                t.container.visible = False
                for row in t.sub_menu_rows:
                    row.visible = False
                t.content_label.visible = False
        page.update()

    # 绑定切换选项卡的方法
    file_tab.tab_button.on_click = lambda e: switch_to_tab(file_tab)
    edit_tab.tab_button.on_click = lambda e: switch_to_tab(edit_tab)
    view_tab.tab_button.on_click = lambda e: switch_to_tab(view_tab)

ft.app(target=main)