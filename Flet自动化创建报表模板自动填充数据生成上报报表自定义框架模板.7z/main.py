import flet as ft
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, Border, Side, PatternFill
import os

def create_sales_report_template1():
    # 创建一个新的工作簿
    wb = Workbook()
    ws = wb.active
    
    # 设置工作表名称
    ws.title = "销售报表1"
    
    # 添加标题
    ws['A1'] = "销售报表1"
    
    # 合并单元格以居中显示标题
    ws.merge_cells('A1:F1')
    
    # 设置标题样式（可选）
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
    
    # 添加列标题
    headers = ["产品名称", "数量", "单价", "折扣", "税额", "总价"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # 设置列标题样式（可选）
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="4F8A3D", end_color="4F8A3D", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # 设置列宽
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    
    # 保存工作簿
    wb.save("sales_report_template1.xlsx")
    return "sales_report_template1.xlsx"

def create_sales_report_template2():
    # 创建一个新的工作簿
    wb = Workbook()
    ws = wb.active
    
    # 设置工作表名称
    ws.title = "销售报表2"
    
    # 添加标题
    ws['A1'] = "销售报表2"
    
    # 合并单元格以居中显示标题
    ws.merge_cells('A1:F1')
    
    # 设置标题样式（可选）
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
    
    # 添加列标题
    headers = ["产品名称", "数量", "单价", "折扣", "税额", "总价"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # 设置列标题样式（可选）
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="4F8A3D", end_color="4F8A3D", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # 设置列宽
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    
    # 保存工作簿
    wb.save("sales_report_template2.xlsx")
    return "sales_report_template2.xlsx"

def create_sales_report_template3():
    # 创建一个新的工作簿
    wb = Workbook()
    ws = wb.active
    
    # 设置工作表名称
    ws.title = "销售报表3"
    
    # 添加标题
    ws['A1'] = "销售报表3"
    
    # 合并单元格以居中显示标题
    ws.merge_cells('A1:F1')
    
    # 设置标题样式（可选）
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
    
    # 添加列标题
    headers = ["产品名称", "数量", "单价", "折扣", "税额", "总价"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # 设置列标题样式（可选）
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="4F8A3D", end_color="4F8A3D", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # 设置列宽
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    
    # 保存工作簿
    wb.save("sales_report_template3.xlsx")
    return "sales_report_template3.xlsx"

def load_template(template_path):
    if os.path.exists(template_path):
        return load_workbook(template_path)
    else:
        return None

def fill_data(ws, data):
    for row_num, row_data in enumerate(data, start=3):
        for col_num, cell_value in enumerate(row_data, start=1):
            ws.cell(row=row_num, column=col_num, value=cell_value)

def save_report(wb, file_name):
    wb.save(file_name)
    return file_name

def clear_data(ws):
    for row in ws.iter_rows(min_row=3):
        for cell in row:
            cell.value = None

def main(page: ft.Page):
    page.title = "Flet自动化创建报表模板自动填充数据生成上报报表自定义框架模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    template_options = {
        "销售报表1": create_sales_report_template1,
        "销售报表2": create_sales_report_template2,
        "销售报表3": create_sales_report_template3,
    }
    
    def create_template_click(e):
        selected_template = template_dropdown.value
        if selected_template:
            template_path = template_options[selected_template]()
            template_text.value = f"模板已创建: {template_path}"
            template_container.update()
        else:
            template_text.value = "请选择一个模板"
            template_container.update()
    
    def select_template_click(e):
        file_picker.pick_files(allowed_extensions=["xlsx"])
    
    def file_picker_result(e: ft.FilePickerResultEvent):
        if e.files:
            selected_template_path.value = e.files[0].path
            selected_template_text.value = f"已选择模板: {e.files[0].name}"
            selected_template_container.update()
        else:
            selected_template_text.value = "未选择任何文件"
            selected_template_container.update()
    
    def fill_data_click(e):
        if selected_template_path.value:
            wb = load_template(selected_template_path.value)
            if wb:
                ws = wb.active
                data = [
                    ["产品A", 10, 50, 0.1, 5, 450],
                    ["产品B", 5, 100, 0.05, 2.5, 472.5]
                ]
                fill_data(ws, data)
                save_report(wb, "filled_sales_report.xlsx")
                result_text.value = "数据已填充并保存为 filled_sales_report.xlsx"
                result_container.update()
            else:
                result_text.value = "无法加载模板文件"
                result_container.update()
        else:
            result_text.value = "请选择一个模板文件"
            result_container.update()
    
    def clear_data_click(e):
        if selected_template_path.value:
            wb = load_template(selected_template_path.value)
            if wb:
                ws = wb.active
                clear_data(ws)
                save_report(wb, "cleared_sales_report.xlsx")
                result_text.value = "数据已清除并保存为 cleared_sales_report.xlsx"
                result_container.update()
            else:
                result_text.value = "无法加载模板文件"
                result_container.update()
        else:
            result_text.value = "请选择一个模板文件"
            result_container.update()
    
    template_text = ft.Text(value="", color="green")
    selected_template_text = ft.Text(value="", color="blue")
    result_text = ft.Text(value="", color="red")
    selected_template_path = ft.Ref[str]()

    template_dropdown = ft.Dropdown(
        label="选择创建报表模板脚本",
        options=[ft.dropdown.Option(k) for k in template_options.keys()],
        width=300
    )

    file_picker = ft.FilePicker(on_result=file_picker_result)
    page.overlay.append(file_picker)

    # 创建带有图标的按钮
    create_template_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.PLAY_ARROW, color="blue", size=24),  # 更改图标为 PLAY_ARROW 并设置固定宽度
                ft.Text("运行脚本创建样式报表模板")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=create_template_click,
        width=300  # 恢复固定宽度
    )

    select_template_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.FOLDER_OPEN, color="blue", size=24),  # 添加文件夹打开图标
                ft.Text("选择你喜欢的样式报表模板")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=select_template_click,
        width=300  # 恢复固定宽度
    )

    fill_data_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.ADD, color="blue", size=24),  # 添加加号图标
                ft.Text("填充数据和保存生成的报表")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=fill_data_click,
        width=300  # 恢复固定宽度
    )

    clear_data_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.CLEAR, color="blue", size=24),  # 添加清除图标
                ft.Text("清除数据保存空白样式报表")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=clear_data_click,
        width=300  # 恢复固定宽度
    )

    # 使用 Container 包裹 template_text 并设置边框
    template_container = ft.Container(
        content=template_text,
        border=ft.border.all(1, "black"),  # 设置边框宽度为 1，颜色为黑色
        padding=10,  # 设置内边距
        width=300  # 设置宽度
    )

    # 使用 Container 包裹 selected_template_text 并设置边框
    selected_template_container = ft.Container(
        content=selected_template_text,
        border=ft.border.all(1, "black"),  # 设置边框宽度为 1，颜色为黑色
        padding=10,  # 设置内边距
        width=300  # 设置宽度
    )

    # 使用 Container 包裹 result_text 并设置边框
    result_container = ft.Container(
        content=result_text,
        border=ft.border.all(1, "black"),  # 设置边框宽度为 1，颜色为黑色
        padding=10,  # 设置内边距
        width=300  # 设置宽度
    )

    page.add(
        ft.Column([
            template_dropdown,
            create_template_button,  # 使用带有图标的按钮
            template_container,  # 使用带有边框的 Container
            select_template_button,
            selected_template_container,  # 使用带有边框的 Container
            fill_data_button,
            clear_data_button,
            result_container,  # 使用带有边框的 Container
        ])
    )

ft.app(target=main)