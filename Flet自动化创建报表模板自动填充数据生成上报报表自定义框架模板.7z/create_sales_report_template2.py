# create_sales_report_template2.py
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, Border, Side, PatternFill

def create_sales_report_template2():
    # 创建一个新的工作簿
    wb = Workbook()
    ws = wb.active
    
    # 设置工作表名称
    ws.title = "销售报表2"
    
    # 添加标题
    ws['A1'] = "销售报表2"
    
    # 合并单元格以居中显示标题
    ws.merge_cells('A1:E1')
    
    # 设置标题样式（可选）
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="FF9900", end_color="FF9900", fill_type="solid")
    
    # 添加列标题
    headers = ["产品名称", "数量", "单价", "折扣", "总价"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # 设置列标题样式（可选）
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="CC7722", end_color="CC7722", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # 设置列宽
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    
    # 保存工作簿
    wb.save("sales_report_template2.xlsx")

if __name__ == "__main__":
    create_sales_report_template2()
    print("销售报表模板文件 'sales_report_template2.xlsx' 已成功创建。")