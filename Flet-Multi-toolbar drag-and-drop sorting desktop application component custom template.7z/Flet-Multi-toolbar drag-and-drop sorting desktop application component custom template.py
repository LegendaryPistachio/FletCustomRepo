import flet as ft

class Toolbar(ft.Container):

    def __init__(self, page, toolbar_name, width=None, height=None, icons=None):
        super().__init__()
        self.page = page
        self.toolbar_name = toolbar_name
        self.width = width
        self.height = height
        self.items = ft.Row([], tight=True, spacing=1)
        self.end_indicator = ft.Container(
            bgcolor=ft.colors.BLACK26,
            border_radius=ft.border_radius.all(30),
            height=3,
            width=200,
            opacity=0.0
        )
        self.undo_stack = []
        self.redo_stack = []

        self.content = ft.Draggable(
            group="toolbars",
            content=ft.DragTarget(
                group="items",
                content=ft.DragTarget(
                    group="toolbars",
                    content=ft.Container(
                        content=ft.Column([
                            self._create_icon_row(icons),
                            self.items,
                            self.end_indicator
                        ], spacing=4, tight=True, expand=True),
                        border=ft.border.all(2, ft.colors.BLACK12),
                        border_radius=ft.border_radius.all(1),
                        bgcolor=ft.colors.TRANSPARENT,
                        padding=ft.padding.all(2),
                        width=self.width,
                        height=self.height,
                        alignment=ft.alignment.center
                    ),
                    data=self,
                    on_accept=self.drag_accept,
                    on_will_accept=self.drag_will_accept,
                    on_leave=self.drag_will_accept
                ),
                data=self,
                on_accept=self.item_drag_accept,
                on_will_accept=self.item_drag_will_accept,
                on_leave=self.item_drag_leave
            )
        )

    def _create_icon_row(self, icons):
        # Create a row containing multiple icons, each icon button has a corresponding click event handler function
        icon_buttons = [
            ft.IconButton(icon, on_click=getattr(self, action), padding=1)
            for icon, action in icons
        ]
        return ft.Container(
            content=ft.Row(icon_buttons, spacing=0, alignment=ft.MainAxisAlignment.START),
            alignment=ft.alignment.top_left,
            height=50,
            margin=ft.margin.only(top=0)
        )

    def new(self, e):
        print("New operation")

    def open(self, e):
        print("Open operation")

    def save(self, e):
        print("Save operation")

    def save_as(self, e):
        print("Save As operation")

    def print(self, e):
        print("Print operation")

    def import_file(self, e):
        print("Import operation")

    def export(self, e):
        print("Export operation")

    def undo(self, e):
        print("Undo operation")

    def redo(self, e):
        print("Redo operation")

    def cut(self, e):
        print("Cut operation")

    def copy(self, e):
        print("Copy operation")

    def paste(self, e):
        print("Paste operation")

    def add_item(self, item: str = None, chosen_control: ft.Draggable = None, swap_control: ft.Draggable = None):
        # Add or move an item to the toolbar, supporting drag-and-drop operations, and update the interface
        controls_list = [x.controls[1] for x in self.items.controls]
        to_index = controls_list.index(swap_control) if swap_control in controls_list else None
        from_index = controls_list.index(chosen_control) if chosen_control in controls_list else None

        self.undo_stack.append((self.items.controls.copy(), self.redo_stack.copy()))
        self.redo_stack.clear()

        if from_index is not None and to_index is not None:
            self.items.controls.insert(to_index, self.items.controls.pop(from_index))
            self.set_indicator_opacity(swap_control, 0.0)
        elif to_index is not None:
            new_item = Item(self, item)
            self.items.controls.insert(to_index, new_item.view)
        else:
            new_item = Item(self, item) if item else Item(self, "")
            self.items.controls.append(new_item.view)

        self.content.update()
        self.page.update()

    def set_indicator_opacity(self, item, opacity):
        # Set the opacity of the indicator
        controls_list = [x.controls[1] for x in self.items.controls]
        self.items.controls[controls_list.index(item)].controls[0].opacity = opacity
        self.content.update()

    def remove_item(self, item):
        # Remove an item from the toolbar
        controls_list = [x.controls[1] for x in self.items.controls]
        del self.items.controls[controls_list.index(item)]
        self.content.update()

    def drag_accept(self, e):
        # Handle drag accept event, swap the positions of two toolbars, and update the interface
        src = self.page.get_control(e.src_id)
        l = self.page.toolbars.controls
        to_index = l.index(e.control.data)
        from_index = l.index(src.content.data)
        l[to_index], l[from_index] = l[from_index], l[to_index]
        self.end_indicator.opacity = 0.0
        self.page.update()

    def drag_will_accept(self, e):
        # Handle drag will accept event
        self.end_indicator.opacity = 0.0
        self.page.update()

    def drag_leave(self, e):
        # Handle drag leave event
        self.end_indicator.opacity = 0.0
        self.page.update()

    def item_drag_accept(self, e):
        # Handle item drag accept event
        src = self.page.get_control(e.src_id)
        self.add_item(src.data.item_text)
        src.data.toolbar.remove_item(src)
        self.end_indicator.opacity = 0.0
        self.update()

    def item_drag_will_accept(self, e):
        # Handle item drag will accept event
        self.end_indicator.opacity = 1.0
        self.update()

    def item_drag_leave(self, e):
        # Handle item drag leave event
        self.end_indicator.opacity = 0.0
        self.update()


class Item:

    def __init__(self, toolbar: Toolbar, item_text: str):
        self.toolbar = toolbar
        self.item_text = item_text
        self.card_item = ft.Card(
            content=ft.Container(
                content=ft.Row([
                    ft.Icon(name=ft.icons.CIRCLE_OUTLINED),
                    ft.Text(value=f"{self.item_text}")
                ], alignment="start"),
                width=None,
                padding=7
            ),
            elevation=1,
            data=self.toolbar
        )
        self.view = ft.Draggable(
            group="items",
            content=ft.DragTarget(
                group="items",
                content=self.card_item,
                on_accept=self.drag_accept,
                on_leave=self.drag_leave,
                on_will_accept=self.drag_will_accept,
            ),
            data=self
        )

    def drag_accept(self, e):
        # Handle item drag accept event
        src = self.toolbar.page.get_control(e.src_id)
        if src.content.content == e.control.content:
            e.control.content.elevation = 1
            self.toolbar.set_indicator_opacity(self.view, 0.0)
            e.control.update()
            return

        if src.data.toolbar == self.toolbar:
            self.toolbar.add_item(chosen_control=src, swap_control=self.view)
            self.toolbar.set_indicator_opacity(self.view, 0.0)
            e.control.content.elevation = 1
            e.control.update()
            return

        self.toolbar.add_item(src.data.item_text, swap_control=self.view)
        src.data.toolbar.remove_item(src)
        self.toolbar.set_indicator_opacity(self.view, 0.0)
        e.control.update()

    def drag_will_accept(self, e):
        # Handle item drag will accept event
        self.toolbar.set_indicator_opacity(self.view, 1.0)
        e.control.content.elevation = 20 if e.data == "true" else 1
        e.control.update()

    def drag_leave(self, e):
        # Handle item drag leave event
        self.toolbar.set_indicator_opacity(self.view, 0.0)
        e.control.content.elevation = 1
        e.control.update()


def main(page: ft.Page):
    page.title = "Flet-Custom Template for Multi-Toolbar Drag-and-Drop Sorting Desktop Application Component"
    page.toolbars = ft.Row([
        Toolbar(page, "Toolbar 1", width=120, height=45, icons=[
            (ft.icons.NEW_LABEL, 'new'),
            (ft.icons.FOLDER_OPEN, 'open'),
            (ft.icons.SAVE, 'save')
        ]),
        Toolbar(page, "Toolbar 2", width=160, height=45, icons=[
            (ft.icons.SAVE_AS, 'save_as'),
            (ft.icons.PRINT, 'print'),
            (ft.icons.FILE_DOWNLOAD, 'import_file'),
            (ft.icons.FILE_UPLOAD, 'export')
        ]),
        Toolbar(page, "Toolbar 3", width=200, height=45, icons=[
            (ft.icons.UNDO, 'undo'),
            (ft.icons.REDO, 'redo'),
            (ft.icons.CONTENT_CUT, 'cut'),
            (ft.icons.CONTENT_COPY, 'copy'),
            (ft.icons.CONTENT_PASTE, 'paste')
        ])
    ], alignment=ft.MainAxisAlignment.START, vertical_alignment=ft.CrossAxisAlignment.CENTER, spacing=1)

    page.add(page.toolbars)


ft.app(target=main)