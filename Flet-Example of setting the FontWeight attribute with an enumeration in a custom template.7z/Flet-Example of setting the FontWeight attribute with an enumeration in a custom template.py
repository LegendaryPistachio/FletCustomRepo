# file:c:\Users\lxmcq\Desktop\Flet字体粗细FontWeight属性设置枚举示例自定义模板.py
import flet as ft


def main(page: ft.Page):
    page.title = "Flet Font Weight Attribute Setting Example Custom Template"
    page.padding = 30

    # Create text components with different font weights
    text_samples = ft.Column(
        controls=[
            ft.Text("NORMAL - Default Normal Weight", weight=ft.FontWeight.NORMAL),
            ft.Text("BOLD - Bold Weight", weight=ft.FontWeight.BOLD),
            ft.Text("W_100 - Thin", weight=ft.FontWeight.W_100),
            ft.Text("W_200 - Extra Light", weight=ft.FontWeight.W_200),
            ft.Text("W_300 - Light", weight=ft.FontWeight.W_300),
            ft.Text("W_400 - Regular (Same as NORMAL)", weight=ft.FontWeight.W_400),
            ft.Text("W_500 - Medium", weight=ft.FontWeight.W_500),
            ft.Text("W_600 - Semi Bold", weight=ft.FontWeight.W_600),
            ft.Text("W_700 - Bold (Same as BOLD)", weight=ft.FontWeight.W_700),
            ft.Text("W_800 - Extra Bold", weight=ft.FontWeight.W_800),
            ft.Text("W_900 - Black", weight=ft.FontWeight.W_900),
        ],
        spacing=10,
    )

    # Add description text
    description = ft.Text(
        "Note: The actual effect depends on whether the font supports the corresponding weight. Font weight is a description of the thickness of the font.",
        italic=True,
        color=ft.Colors.GREY_600,  # Modify here
    )

    page.add(text_samples, description)


ft.app(target=main)