import flet as ft
import time

def main(page: ft.Page):
    page.title = "Flet动画切换过渡枚举值Fade示例透明度变化淡入淡出动画自定义模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # 创建一个文本控件，设置背景色为黄色，文字颜色为白色
    text = ft.Text("Fade In and Out", size=30, opacity=0, bgcolor=ft.Colors.YELLOW_500, color=ft.Colors.WHITE)

    # 将文本控件添加到页面中
    page.add(text)

    # 淡入动画
    def fade_in():
        for i in range(0, 101, 5):
            text.opacity = i / 100
            page.update()
            time.sleep(0.3)  # 增加时间间隔

    # 淡出动画
    def fade_out():
        for i in range(100, -1, -5):
            text.opacity = i / 100
            page.update()
            time.sleep(0.3)  # 增加时间间隔

    # 循环淡入淡出
    while True:
        fade_in()
        fade_out()

ft.app(target=main)