import flet as ft


def main(page: ft.Page):
    page.title = "Flet容器内文本十种对齐方式Alignment类自定义模板"
    page.scroll = "adaptive"

    # 创建三个 Row 容器来排列子容器
    row1 = ft.Row(
        [
            ft.Container(
                content=ft.Text(
                    "左上角对齐", size=20, color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE
                ),
                alignment=ft.alignment.top_left,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
            ft.Container(
                content=ft.Text(
                    "顶部居中对齐",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.top_center,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
            ft.Container(
                content=ft.Text(
                    "右上角对齐", size=20, color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE
                ),
                alignment=ft.alignment.top_right,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
        ],
        alignment=ft.MainAxisAlignment.START,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    row2 = ft.Row(
        [
            ft.Container(
                content=ft.Text(
                    "左侧居中对齐",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.center_left,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
            ft.Container(
                content=ft.Text(
                    "中心对齐", size=20, color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE
                ),
                alignment=ft.alignment.center,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
            ft.Container(
                content=ft.Text(
                    "右侧居中对齐",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.center_right,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
        ],
        alignment=ft.MainAxisAlignment.START,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    row3 = ft.Row(
        [
            ft.Container(
                content=ft.Text(
                    "左下角对齐", size=20, color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE
                ),
                alignment=ft.alignment.bottom_left,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
            ft.Container(
                content=ft.Text(
                    "底部居中对齐",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.bottom_center,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
            ft.Container(
                content=ft.Text(
                    "右下角对齐", size=20, color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE
                ),
                alignment=ft.alignment.bottom_right,
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
            ft.Container(
                content=ft.Text(
                    "自定义对齐 (-0.5, -0.5)",
                    size=20,
                    color=ft.Colors.WHITE,
                    bgcolor=ft.Colors.BLUE,
                ),
                alignment=ft.alignment.Alignment(-0.5, -0.5),
                width=200,
                height=200,  # 修改为正方形
                bgcolor=ft.Colors.AMBER,
                expand=1,
                border=ft.border.all(1, ft.Colors.BLUE),  # 添加蓝色边框
            ),
        ],
        alignment=ft.MainAxisAlignment.START,
        vertical_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    # 创建一个 Column 容器来排列三个 Row 容器
    column = ft.Column(
        [row1, row2, row3],
        alignment=ft.MainAxisAlignment.START,
        horizontal_alignment=ft.CrossAxisAlignment.START,
        spacing=10,
    )

    # 将 Column 容器添加到页面
    page.add(column)


ft.app(target=main)
