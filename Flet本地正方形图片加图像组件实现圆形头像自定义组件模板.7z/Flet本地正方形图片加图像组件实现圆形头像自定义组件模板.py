import flet as ft


def main(page: ft.Page):
    # 设置页面标题
    page.title = "flet本地正方形图片加图像组件实现圆形头像自定义组件模板"

    # 创建一个正方形的Image组件，并使用Container添加边框
    square_image = ft.Container(
        content=ft.Image(
            src="logo.png",  # 图片路径
            width=100,  # 宽度
            height=100,  # 高度
            border_radius=50,  # 边框半径，设置为宽度的一半以形成圆形
        ),
        width=110,
        height=110,
        border_radius=55,
        bgcolor="green",  # 设置Container的背景颜色为绿色
        padding=3,  # 确保图片紧贴Container边缘
    )

    # 将Container组件添加到页面
    page.add(square_image)


# 运行Flet应用
ft.app(target=main)
