import flet as ft

def main(page: ft.Page):
    page.title = "flet用消息传递机制来进行多窗口管理的自定义模板"
    current_window = "main"

    # 主窗口
    main_window = ft.Column(controls=[
        ft.Text("主窗口"),
        ft.ElevatedButton("打开子窗口 1", on_click=lambda _: send_message("show_window1")),
        ft.ElevatedButton("打开子窗口 2", on_click=lambda _: send_message("show_window2")),
        ft.ElevatedButton("打开子窗口 3", on_click=lambda _: send_message("show_window3"))
    ])

    # 子窗口 1
    window1 = ft.Column(visible=False, controls=[
        ft.Text("这是子窗口 1"),
        ft.ElevatedButton("返回主窗口", on_click=lambda _: send_message("show_main"))
    ])

    # 子窗口 2
    window2 = ft.Column(visible=False, controls=[
        ft.Text("这是子窗口 2"),
        ft.ElevatedButton("返回主窗口", on_click=lambda _: send_message("show_main"))
    ])

    # 子窗口 3
    window3 = ft.Column(visible=False, controls=[
        ft.Text("这是子窗口 3"),
        ft.ElevatedButton("返回主窗口", on_click=lambda _: send_message("show_main"))
    ])
    
    # 将所有窗口添加到页面
    page.add(main_window, window1, window2, window3)

    # 消息处理函数传递消息管理多窗口
    def send_message(message):
        nonlocal current_window
        
        if message == "show_main":
            current_window = "main"
            main_window.visible = True
            window1.visible = False
            window2.visible = False
            window3.visible = False
        elif message == "show_window1":
            current_window = "window1"
            main_window.visible = False
            window1.visible = True
            window2.visible = False
            window3.visible = False
        elif message == "show_window2":
            current_window = "window2"
            main_window.visible = False
            window1.visible = False
            window2.visible = True
            window3.visible = False
        elif message == "show_window3":
            current_window = "window3"
            main_window.visible = False
            window1.visible = False
            window2.visible = False
            window3.visible = True

        page.update()

# 运行应用
ft.app(target=main)
