import flet as ft

def main(page: ft.Page):
    def create_custom_switch(scale: float = 1.0, label: str = ""):
        return ft.Row(
            [
                ft.Container(
                    content=ft.Switch(),
                    scale=scale,
                    alignment=ft.alignment.center,
                ),
                ft.Text(label) if label else None
            ],
            alignment=ft.MainAxisAlignment.START,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    small_switch = create_custom_switch(0.5, "小号开关")
    normal_switch = create_custom_switch(0.8, "正常大小开关")
    large_switch = create_custom_switch(1.1, "大号开关")
    extra_large_switch = create_custom_switch(1.4, "特大号开关")

    page.add(small_switch, normal_switch, large_switch, extra_large_switch)

ft.app(target=main)