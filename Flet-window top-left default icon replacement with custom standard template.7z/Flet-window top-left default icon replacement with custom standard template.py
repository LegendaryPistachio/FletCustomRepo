# Flet window top-left default icon replacement with custom standard template
import flet as ft


def main(page: ft.Page):
    # Set window title
    page.title = (
        "Flet Window Top-Left Default Icon Replacement with Custom Standard Template"
    )

    page.window.icon = "logo.ico"

    # Set window size
    page.window.width = 400
    page.window.height = 300

    # Add some content to the window
    page.add(ft.Text("This is a window standard template with a custom icon"))


ft.app(target=main)
