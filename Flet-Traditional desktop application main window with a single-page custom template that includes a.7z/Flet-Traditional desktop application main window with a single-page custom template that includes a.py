import flet as ft
from flet import Icons  # Import Icons enum

def main(page: ft.Page):
    # Set window title
    page.title = "Flet Traditional Desktop Application Main Window with Menu Bar and Tool Bar Single Page Custom Template"

    def handle_menu_item_click(e):
        print(f"{e.control.content.value}.on_click")
        page.open(ft.SnackBar(content=ft.Text(f"{e.control.content.value} was clicked!")))
        page.update()

    def handle_submenu_open(e):
        print(f"{e.control.content.value}.on_open")

    def handle_submenu_close(e):
        print(f"{e.control.content.value}.on_close")

    def handle_submenu_hover(e):
        print(f"{e.control.content.value}.on_hover")

    menubar = ft.MenuBar(
        expand=True,
        style=ft.MenuStyle(
            alignment=ft.alignment.top_left,
            bgcolor=ft.Colors.BLUE_GREY_300,  # Change background color
            mouse_cursor={
                ft.ControlState.HOVERED: ft.MouseCursor.WAIT,
                ft.ControlState.DEFAULT: ft.MouseCursor.ZOOM_OUT,
            },
        ),
        controls=[
            ft.SubmenuButton(
                content=ft.Text("File"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("New"),
                        leading=ft.Icon(Icons.NEW_LABEL),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Open"),
                        leading=ft.Icon(Icons.FOLDER_OPEN),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Save"),
                        leading=ft.Icon(Icons.SAVE),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Save As"),
                        leading=ft.Icon(Icons.SAVE_AS),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Exit"),
                        leading=ft.Icon(Icons.EXIT_TO_APP),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("Edit"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("Undo"),
                        leading=ft.Icon(Icons.UNDO),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Redo"),
                        leading=ft.Icon(Icons.REDO),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Cut"),
                        leading=ft.Icon(Icons.CONTENT_CUT),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Copy"),
                        leading=ft.Icon(Icons.CONTENT_COPY),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Paste"),
                        leading=ft.Icon(Icons.CONTENT_PASTE),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Delete"),
                        leading=ft.Icon(Icons.DELETE),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Find"),
                        leading=ft.Icon(Icons.SEARCH),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Replace"),
                        leading=ft.Icon(Icons.SWAP_HORIZ),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Select All"),
                        leading=ft.Icon(Icons.SELECT_ALL),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.LIGHT_GREEN_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("Format"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("Word Wrap"),
                        leading=ft.Icon(Icons.WRAP_TEXT),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.PINK_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("Font..."),
                        leading=ft.Icon(Icons.FONT_DOWNLOAD),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.PINK_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("View"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("Status Bar"),
                        leading=ft.Icon(Icons.STAR),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.ORANGE_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
            ft.SubmenuButton(
                content=ft.Text("Help"),
                on_open=handle_submenu_open,
                on_close=handle_submenu_close,
                on_hover=handle_submenu_hover,
                controls=[
                    ft.MenuItemButton(
                        content=ft.Text("View Help"),
                        leading=ft.Icon(Icons.HELP),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.YELLOW_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                    ft.MenuItemButton(
                        content=ft.Text("About Notepad"),
                        leading=ft.Icon(Icons.INFO),  # Use Icon control
                        style=ft.ButtonStyle(
                            bgcolor={ft.ControlState.HOVERED: ft.Colors.YELLOW_100}  # Use new Colors enum
                        ),
                        on_click=handle_menu_item_click,
                    ),
                ],
            ),
        ],
    )

    # Create tool bar
    toolbar = ft.Row(
        [
            ft.IconButton(Icons.NEW_LABEL, tooltip="New", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.FOLDER_OPEN, tooltip="Open", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SAVE, tooltip="Save", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SAVE_AS, tooltip="Save As", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.UNDO, tooltip="Undo", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.REDO, tooltip="Redo", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.CONTENT_CUT, tooltip="Cut", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.CONTENT_COPY, tooltip="Copy", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.CONTENT_PASTE, tooltip="Paste", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.DELETE, tooltip="Delete", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SEARCH, tooltip="Find", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SWAP_HORIZ, tooltip="Replace", on_click=lambda e: handle_menu_item_click(e)),
            ft.IconButton(Icons.SELECT_ALL, tooltip="Select All", on_click=lambda e: handle_menu_item_click(e)),
        ],
        spacing=10,
    )

    # Add menu bar and tool bar to the page
    page.add(
        ft.Column([
            ft.Row([menubar]),
            toolbar,
        ])
    )

ft.app(main)