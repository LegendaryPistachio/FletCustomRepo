import flet as ft

# Image list
images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg",
    "image6.jpg",
    "image7.jpg",
]


def next_image(event):
    page = event.control.page
    current_index = page.state["image_index"]
    next_index = (current_index + 1) % len(images)
    page.state["image_index"] = next_index
    update_images(page)
    page.update()


def prev_image(event):
    page = event.control.page
    current_index = page.state["image_index"]
    prev_index = (current_index - 1) % len(images)
    page.state["image_index"] = prev_index
    update_images(page)
    page.update()


def update_images(page):
    current_index = page.state["image_index"]
    print(f"Updating images with index {current_index}")
    page.controls[0].controls[1].src = images[current_index]  # First image
    page.controls[0].controls[2].src = images[
        (current_index + 1) % len(images)
    ]  # Second image
    page.controls[0].controls[3].src = images[
        (current_index + 2) % len(images)
    ]  # Third image


def main(page: ft.Page):
    # Initialize page state
    page.state = {"image_index": 0}

    # Page layout
    image_row = ft.Row(
        [
            ft.ElevatedButton("<", on_click=prev_image),
            ft.Image(src=images[0], width=300, height=200),
            ft.Image(src=images[1], width=300, height=200),
            ft.Image(src=images[2], width=300, height=200),
            ft.ElevatedButton(">", on_click=next_image),
        ],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        spacing=20,
    )

    page.add(image_row)


ft.app(target=main)
