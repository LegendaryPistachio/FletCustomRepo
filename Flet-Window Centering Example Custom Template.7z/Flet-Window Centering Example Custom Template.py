# Set the operating system taskbar to auto-hide, and then start the program, the window will automatically center.
import flet as ft


def main(page: ft.Page):
    # Set the window title
    page.title = "Flet Centered Window Example Custom Template"

    # Set the window size
    page.window.width = 800
    page.window.height = 600

    # Center the window
    page.window.center()

    # Add a simple text control
    page.add(ft.Text("Window is centered!"))


# Start the Flet app
ft.app(target=main)
