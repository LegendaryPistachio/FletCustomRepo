import flet as ft
import time
from time import strftime


def main(page: ft.Page):
    # 窗口设置
    page.window.frameless = True  # 设置无边框
    page.window.bgcolor = ft.Colors.TRANSPARENT  # 窗体背景透明
    page.bgcolor = ft.Colors.TRANSPARENT  # 页面背景透明
    # 设置窗口大小
    page.window.width = 200
    page.window.height = 100

    # 设置窗口居中
    page.window.center()


    def update_clock():
        timelabel.value = strftime("%H:%M:%S")
        datelabel.value = strftime("%A, %e %B")
        page.update()

    timelabel = ft.Text(
        value="", color=ft.Colors.WHITE, size=40, font_family="NovaMono"
    )
    datelabel = ft.Text(
        value="", color=ft.Colors.WHITE, size=15, font_family="Bahnschrift"
    )

    page.add(
        ft.Column(
            [timelabel, datelabel],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True,
        )
    )

    page.update()
    update_clock()

    while True:
        time.sleep(1)
        update_clock()


ft.app(target=main)
