import flet as ft
import random


def main(page: ft.Page):
    page.title = "Flet Colored Icon Outline Button Example"

    # Initialize result label
    result_label = ft.Text(value="Choose an option", size=16)

    # Define rock-paper-scissors logic
    def play_game(user_choice):
        choices = ["✊", "✌️", "✋"]  # Replace text with icon characters
        computer_choice = random.choice(choices)
        if user_choice == computer_choice:
            result = "Tie"
        elif (
            (user_choice == "✊" and computer_choice == "✌️")
            or (user_choice == "✌️" and computer_choice == "✋")
            or (user_choice == "✋" and computer_choice == "✊")
        ):
            result = "You won 😀"  # Add smiley face icon
        else:
            result = "You lost 😢"  # Add crying face icon
        result_label.value = f"You chose: {user_choice}, Computer chose: {computer_choice}, Result: {result}"
        page.update()

    page.add(
        ft.Row(
            [
                ft.OutlinedButton(
                    "Rock",
                    icon="pan_tool_outlined",
                    icon_color="red400",
                    on_click=lambda e: play_game("✊"),
                ),
                ft.OutlinedButton(
                    "Scissors",
                    icon="content_cut_outlined",
                    icon_color="yellow400",
                    on_click=lambda e: play_game("✌️"),
                ),
                ft.OutlinedButton(
                    "Paper",
                    icon="crop_free_outlined",
                    icon_color="blue400",
                    on_click=lambda e: play_game("✋"),
                ),
            ]
        ),
        result_label,  # Add result label
    )


ft.app(target=main)
