import flet as ft


def example():
    return ft.Container(
        content=ft.Column(
            controls=[
                ft.Container(
                    content=ft.Stack(
                        [
                            ft.CircleAvatar(
                                foreground_image_src="https://avatars.githubusercontent.com/u/5041459?s=88&v=4",
                                radius=30,  # 设置头像半径为30，以适应60x60的容器
                                tooltip="用户头像",  # 可选：添加工具提示
                            ),
                            ft.Container(
                                content=ft.CircleAvatar(
                                    bgcolor=ft.Colors.GREEN,
                                    radius=10,
                                    content=ft.Text(
                                        "在线",
                                        size=8,
                                        color=ft.Colors.WHITE,
                                    ),
                                ),
                                alignment=ft.alignment.bottom_right,
                            ),
                        ],
                        width=60,
                        height=60,
                    ),
                    margin=ft.margin.only(left=70),  # 向左边移动70像素
                    alignment=ft.alignment.center_left,  # 左对齐
                ),
                ft.Container(
                    width=220,
                    content=ft.ExpansionTile(
                        title=ft.Row(
                            controls=[
                                ft.Icon(
                                    ft.Icons.STAR, color=ft.Colors.BLUE
                                ),  # 五角星图标
                                ft.Text("ExpansionTile 1"),
                            ]
                        ),
                        affinity=ft.TileAffinity.PLATFORM,  # 扩展箭头在右侧
                        maintain_state=True,
                        initially_expanded=False,  # 默认折叠
                        collapsed_text_color=ft.Colors.BLUE,
                        text_color=ft.Colors.AMBER,
                        controls=[
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.STAR, color=ft.Colors.BLUE
                                        ),  # 固定图标
                                        ft.Text("子标题1"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.SEARCH, color=ft.Colors.BLUE
                                        ),  # 固定图标
                                        ft.Text("子标题2"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.BOOKMARK, color=ft.Colors.BLUE
                                        ),  # 固定图标
                                        ft.Text("子标题3"),
                                    ]
                                )
                            ),
                        ],
                    ),
                ),
                ft.Container(
                    width=220,
                    content=ft.ExpansionTile(
                        title=ft.Row(
                            controls=[
                                ft.Icon(
                                    ft.Icons.NOTIFICATIONS, color=ft.Colors.GREEN
                                ),  # 固定图标
                                ft.Text("ExpansionTile 2"),
                            ]
                        ),
                        affinity=ft.TileAffinity.PLATFORM,  # 扩展箭头在右侧
                        maintain_state=True,
                        initially_expanded=False,  # 默认折叠
                        collapsed_text_color=ft.Colors.BLUE,
                        text_color=ft.Colors.AMBER,
                        controls=[
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.FAVORITE, color=ft.Colors.BLUE
                                        ),  # 固定图标
                                        ft.Text("子标题1"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.EMAIL, color=ft.Colors.BLUE
                                        ),  # 固定图标
                                        ft.Text("子标题2"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.CLOSE_FULLSCREEN,
                                            color=ft.Colors.BLUE,
                                        ),  # 固定图标
                                        ft.Text("子标题3"),
                                    ]
                                )
                            ),
                        ],
                    ),
                ),
                ft.Container(
                    width=220,
                    content=ft.ExpansionTile(
                        title=ft.Row(
                            controls=[
                                ft.Icon(
                                    ft.Icons.SETTINGS, color=ft.Colors.RED
                                ),  # 固定图标
                                ft.Text("ExpansionTile 3"),
                            ]
                        ),
                        affinity=ft.TileAffinity.PLATFORM,  # 扩展箭头在右侧
                        maintain_state=True,
                        initially_expanded=False,  # 默认折叠
                        collapsed_text_color=ft.Colors.BLUE,
                        text_color=ft.Colors.AMBER,
                        controls=[
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.HOME, color=ft.Colors.BLUE
                                        ),  # 固定图标
                                        ft.Text("子标题1"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.SETTINGS, color=ft.Colors.BLUE
                                        ),  # 固定图标
                                        ft.Text("子标题2"),
                                    ]
                                )
                            ),
                            ft.ListTile(
                                title=ft.Row(
                                    controls=[
                                        ft.Icon(
                                            ft.Icons.PERM_DEVICE_INFORMATION,
                                            color=ft.Colors.BLUE,
                                        ),  # 固定图标
                                        ft.Text("子标题3"),
                                    ]
                                )
                            ),
                        ],
                    ),
                ),
            ],
            alignment=ft.MainAxisAlignment.START,  # 对齐方式
        ),
        alignment=ft.alignment.center,  # 居中对齐
    )


def main(page: ft.Page):
    page.title = "Flet平面级联菜单侧边栏和和登录用户圆形头像自定义组件模板"
    page.window.center()
    page.add(example())


ft.app(target=main)
