import flet as ft


def main(page: ft.Page):
    page.title = "Flet Fade-In Zoom Animation Example Custom Template"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.spacing = 20

    # Define fade-in animation
    animation = ft.Animation(duration=1000, curve=ft.AnimationCurve.EASE_IN)

    # Create a container to display the animation effect
    container = ft.Container(
        width=100,
        height=100,
        bgcolor=ft.Colors.BLUE,
        animate_scale=animation,
        scale=0,  # Initial scale is 0
    )

    # Create an image control
    image = ft.Image(
        src="logo.png",
        width=100,
        height=100,
        fit=ft.ImageFit.CONTAIN,
    )

    # Create a column container to include the image
    content_column = ft.Column(
        controls=[image],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=5,
    )

    # Add the column container to the main container
    container.content = content_column

    # Create a button to start the animation
    button = ft.ElevatedButton(
        text="Start Fade-In Animation", on_click=lambda e: start_animation(container)
    )

    # Create a column container to include the container and button
    column = ft.Column(
        controls=[container, button],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
    )

    # Add the column container to the page
    page.add(column)


def start_animation(container: ft.Container):
    # Fade-in zoom animation from small to large
    container.scale = 1
    container.update()


ft.app(target=main)
