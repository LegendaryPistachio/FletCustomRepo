import flet as ft


def main(page: ft.Page):
    page.title = "Flet Fade-Out Shrink Animation Example Custom Template"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.spacing = 20

    # Define fade-out animation
    scale_out_animation = ft.Animation(duration=1000, curve=ft.AnimationCurve.EASE_OUT)

    # Create a container to display the animation effect
    container = ft.Container(
        width=100,
        height=100,
        bgcolor=ft.Colors.BLUE,
        animate_scale=scale_out_animation,
        scale=1,  # Initial scale is 1
    )

    # Create an image control
    image = ft.Image(
        src="logo.png",
        width=100,
        height=100,
        fit=ft.ImageFit.CONTAIN,
    )

    # Create a column container to include the image
    content_column = ft.Column(
        controls=[image],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=5,
    )

    # Add the column container to the main container
    container.content = content_column

    # Create a button to start the fade-out animation
    scale_out_button = ft.ElevatedButton(
        text="Start Fade-Out Animation",
        on_click=lambda e: start_scale_out_animation(container),
    )

    # Create a column container to include the container and button
    column = ft.Column(
        controls=[container, scale_out_button],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=10,
    )

    # Add the column container to the page
    page.add(column)


def start_scale_out_animation(container: ft.Container):
    # Set the animation to fade-out animation
    container.animate_scale = ft.Animation(
        duration=1000, curve=ft.AnimationCurve.EASE_OUT
    )
    # Fade-out shrink animation from large to small
    container.scale = 0
    container.update()


ft.app(target=main)
