import flet as ft

def main(page: ft.Page):
    page.title = "Flet-Custom Template for Multi-Window Management Using Message Passing Mechanism"
    current_window = "main"

    # Main Window
    main_window = ft.Column(controls=[
        ft.Text("Main Window"),
        ft.ElevatedButton("Open Sub-Window 1", on_click=lambda _: send_message("show_window1")),
        ft.ElevatedButton("Open Sub-Window 2", on_click=lambda _: send_message("show_window2")),
        ft.ElevatedButton("Open Sub-Window 3", on_click=lambda _: send_message("show_window3"))
    ])

    # Sub-Window 1
    window1 = ft.Column(visible=False, controls=[
        ft.Text("This is Sub-Window 1"),
        ft.ElevatedButton("Return to Main Window", on_click=lambda _: send_message("show_main"))
    ])

    # Sub-Window 2
    window2 = ft.Column(visible=False, controls=[
        ft.Text("This is Sub-Window 2"),
        ft.ElevatedButton("Return to Main Window", on_click=lambda _: send_message("show_main"))
    ])

    # Sub-Window 3
    window3 = ft.Column(visible=False, controls=[
        ft.Text("This is Sub-Window 3"),
        ft.ElevatedButton("Return to Main Window", on_click=lambda _: send_message("show_main"))
    ])
    
    # Add all windows to the page
    page.add(main_window, window1, window2, window3)

    # Message handling function for managing multiple windows
    def send_message(message):
        nonlocal current_window
        
        if message == "show_main":
            current_window = "main"
            main_window.visible = True
            window1.visible = False
            window2.visible = False
            window3.visible = False
        elif message == "show_window1":
            current_window = "window1"
            main_window.visible = False
            window1.visible = True
            window2.visible = False
            window3.visible = False
        elif message == "show_window2":
            current_window = "window2"
            main_window.visible = False
            window1.visible = False
            window2.visible = True
            window3.visible = False
        elif message == "show_window3":
            current_window = "window3"
            main_window.visible = False
            window1.visible = False
            window2.visible = False
            window3.visible = True

        page.update()

# Run the application
ft.app(target=main)