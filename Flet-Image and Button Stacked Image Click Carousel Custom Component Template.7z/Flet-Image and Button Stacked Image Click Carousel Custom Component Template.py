import flet as ft

# Image list
images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg",
    "image6.jpg",
    "image7.jpg",
]


def change_image(event, index, page):
    page.state["image_index"] = index
    update_images(page)
    page.update()


def update_images(page):
    current_index = page.state["image_index"]
    print(f"Updating images with index {current_index}")
    # Access the first Container in Stack, then access its content attribute
    image_container = page.controls[0].controls[0].controls[0]
    image_container.content.src = images[current_index]


def main(page: ft.Page):
    page.title = (
        "Flet Image and Button Stacked Image Click Carousel Custom Component Template"
    )
    # Initialize page state
    page.state = {"image_index": 0}

    # Set page's vertical and horizontal alignment
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Image container
    image_container = ft.Container(
        content=ft.Image(src=images[0], width=1000, height=500, fit=ft.ImageFit.COVER),
        alignment=ft.alignment.center,
    )

    # Button row
    buttons_row = ft.Row(
        [
            ft.ElevatedButton(
                f"{i+1}",
                width=50,
                height=20,
                on_click=lambda e, i=i: change_image(e, i, page),
            )
            for i in range(len(images))
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        width=500,  # Adjust Row width to fit all buttons
    )

    # Use Stack to overlay image_container and buttons_row
    stack = ft.Stack(
        [
            image_container,
            ft.Container(
                content=buttons_row,
                alignment=ft.alignment.bottom_center,  # Place button row at bottom center
                margin=ft.margin.only(bottom=20),  # Adjust button row bottom margin
            ),
        ],
        width=1000,  # Set Stack width
        height=500,  # Set Stack height
    )

    # Add Stack to the page
    page.add(
        ft.Column(
            [stack],
            alignment=ft.MainAxisAlignment.CENTER,  # Vertically center
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # Horizontally center
            expand=True,  # Make Column take up the entire page
        )
    )


ft.app(target=main)
