import flet as ft

def main(page: ft.Page):
    page.title = "Flet Animation Switch Transition ROTATION Example Custom Template"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Use a regular boolean variable to manage state
    toggle_flag = False
    
    # Dynamic content control
    content = ft.AnimatedSwitcher(
        content=ft.Container(
            key="A",
            width=100,
            height=100,
            bgcolor=ft.Colors.BLUE,  # Use ft.Colors instead of ft.colors
            alignment=ft.alignment.center,
            content=ft.Text("A", color=ft.Colors.WHITE)  # Use ft.Colors instead of ft.colors
        ),
        transition=ft.AnimatedSwitcherTransition.ROTATION,
        duration=500
    )

    def toggle_content(e):
        nonlocal toggle_flag  # Declare as nonlocal variable
        # Switch content
        if toggle_flag:
            new_content = ft.Container(
                key="A",
                width=100,
                height=100,
                bgcolor=ft.Colors.BLUE,  # Use ft.Colors instead of ft.colors
                alignment=ft.alignment.center,
                content=ft.Text("A", color=ft.Colors.WHITE)  # Use ft.Colors instead of ft.colors
            )
        else:
            new_content = ft.Container(
                key="B",
                width=100,
                height=100,
                bgcolor=ft.Colors.RED,  # Use ft.Colors instead of ft.colors
                alignment=ft.alignment.center,
                content=ft.Text("B", color=ft.Colors.WHITE)  # Use ft.Colors instead of ft.colors
            )
        
        # Update state and content
        toggle_flag = not toggle_flag
        content.content = new_content
        page.update()

    page.add(
        ft.Column(
            [
                content,
                ft.ElevatedButton("Toggle", on_click=toggle_content)
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

ft.app(target=main)