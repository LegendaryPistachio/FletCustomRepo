# Flet-Draggable Toolbar Custom Component Template.py
import flet as ft


def main(page: ft.Page):
    page.title = "Flet-Draggable Toolbar Custom Component Template"

    def on_pan_update1(e: ft.DragUpdateEvent):
        new_top = c.top + e.delta_y
        new_left = c.left + e.delta_x
        c.top = max(
            0, min(new_top, 200)
        )  # 200 is the maximum value for the top, ensuring the container does not exceed the bottom
        c.left = max(
            0, min(new_left, 900)
        )  # 900 is the maximum value for the left, ensuring the container does not exceed the right
        c.update()

    def on_pan_update2(e: ft.DragUpdateEvent):
        new_top = e.control.top + e.delta_y
        new_left = e.control.left + e.delta_x
        e.control.top = max(
            0, min(new_top, 200)
        )  # 200 is the maximum value for the top, ensuring the container does not exceed the bottom
        e.control.left = max(
            0, min(new_left, 900)
        )  # 900 is the maximum value for the left, ensuring the container does not exceed the right
        e.control.update()

    # Create a row of icon buttons horizontally aligned
    icon_buttons = ft.Row(
        [
            ft.IconButton(icon=ft.Icons.DRAG_INDICATOR, tooltip="DRAG_INDICATOR"),
            ft.IconButton(icon=ft.Icons.SEARCH, tooltip="Search"),
            ft.IconButton(icon=ft.Icons.SETTINGS, tooltip="Settings"),
            ft.IconButton(icon=ft.Icons.INFO, tooltip="Info"),
            ft.IconButton(icon=ft.Icons.HOME, tooltip="Home"),
        ],
        alignment=ft.MainAxisAlignment.START,  # Horizontal left alignment
        spacing=0,
    )

    gd = ft.GestureDetector(
        mouse_cursor=ft.MouseCursor.MOVE,
        drag_interval=50,
        on_pan_update=on_pan_update1,
        content=ft.Container(
            icon_buttons,
            bgcolor=ft.Colors.AMBER,
            width=300,
            height=50,
            padding=0,
            alignment=ft.alignment.center,  # Vertical center alignment
        ),
    )

    c = ft.Container(gd, left=0, top=0)

    # Create another row of icon buttons horizontally aligned
    icon_buttons_blue = ft.Row(
        [
            ft.IconButton(icon=ft.Icons.DRAG_INDICATOR, tooltip="Favorite"),
            ft.IconButton(icon=ft.Icons.SEARCH, tooltip="Search"),
            ft.IconButton(icon=ft.Icons.SETTINGS, tooltip="Settings"),
            ft.IconButton(icon=ft.Icons.INFO, tooltip="Info"),
            ft.IconButton(icon=ft.Icons.HOME, tooltip="Home"),
        ],
        alignment=ft.MainAxisAlignment.START,  # Horizontal left alignment
        spacing=0,
    )

    gd1 = ft.GestureDetector(
        mouse_cursor=ft.MouseCursor.MOVE,
        drag_interval=10,
        on_vertical_drag_update=on_pan_update2,
        left=100,
        top=100,
        content=ft.Container(
            icon_buttons_blue,
            bgcolor=ft.Colors.BLUE,
            width=300,
            height=50,
            padding=0,
            alignment=ft.alignment.center,  # Vertical center alignment
        ),
    )

    page.add(ft.Stack([c, gd1], width=1200, height=500))


ft.app(target=main)
