import flet as ft


def main(page: ft.Page):
    page.window.title_bar_hidden = True
    page.window.title_bar_buttons_hidden = True

    def close_window(e):
        page.window.close()

    close_button = ft.Container(
        content=ft.IconButton(
            icon=ft.Icons.CLOSE,  # Use ft.Icons instead of ft.icons
            on_click=close_window,
        ),
        bgcolor=ft.Colors.RED,  # Use ft.Colors instead of ft.colors
        border_radius=25,  # Optional: Set rounded corners
        padding=0,  # Optional: Set padding
    )

    drag_area = ft.WindowDragArea(
        ft.Container(
            ft.Text(
                "Flet-Customizable Template for Application Window Drag Area",
            ),
            bgcolor=ft.Colors.GREY_300,
            border_radius=15,
            padding=10,
        ),
        expand=True,
    )

    page.add(ft.Row([drag_area, close_button]))


ft.app(target=main)  # Pass the main function using the target parameter
