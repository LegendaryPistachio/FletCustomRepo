import flet as ft

# 图片列表
images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg",
    "image6.jpg",
    "image7.jpg",
]

def change_image(event, index, page):
    page.state["image_index"] = index
    update_images(page)
    page.update()

def update_images(page):
    current_index = page.state["image_index"]
    print(f"Updating images with index {current_index}")
    # 访问 Stack 中的第一个 Container，然后访问其 content 属性
    image_container = page.controls[0].controls[0].controls[0]
    image_container.content.src = images[current_index]

def main(page: ft.Page):
    page.title = "Flet图片和按钮堆叠按钮点击图片轮播自定义组件模板"
    # 初始化页面状态
    page.state = {"image_index": 0}

    # 设置页面的垂直和水平对齐方式
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # 图片容器
    image_container = ft.Container(
        content=ft.Image(src=images[0], width=1000, height=500, fit=ft.ImageFit.COVER),
        alignment=ft.alignment.center,
    )

    # 按钮行
    buttons_row = ft.Row(
        [
            ft.ElevatedButton(f"{i+1}", width=50, height=20, on_click=lambda e, i=i: change_image(e, i, page)) for i in range(len(images))
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        width=500,  # 调整 Row 的宽度以适应所有按钮
    )

    # 使用 Stack 将 image_container 和 buttons_row 堆叠在一起
    stack = ft.Stack(
        [
            image_container,
            ft.Container(
                content=buttons_row,
                alignment=ft.alignment.bottom_center,  # 将按钮行放置在底部中心
                margin=ft.margin.only(bottom=20)  # 调整按钮行的底部边距
            )
        ],
        width=1000,  # 设置 Stack 的宽度
        height=500   # 设置 Stack 的高度
    )

    # 将 Stack 添加到页面中
    page.add(
        ft.Column(
            [
                stack
            ],
            alignment=ft.MainAxisAlignment.CENTER,  # 垂直居中
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # 水平居中
            expand=True  # 使 Column 占据整个页面
        )
    )

ft.app(target=main)