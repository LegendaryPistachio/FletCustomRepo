import flet as ft


def main(page: ft.Page):
    page.title = "AnimatedSwitcher SCALE Demo"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    toggle = False  # 直接使用Python变量

    # 定义两个容器
    container1 = ft.Container(
        key="1",
        width=200,
        height=200,
        bgcolor=ft.Colors.BLUE,
        alignment=ft.alignment.center,
        content=ft.Text("Page 1", color=ft.Colors.WHITE, size=24),
    )

    container2 = ft.Container(
        key="2",
        width=200,
        height=200,
        bgcolor=ft.Colors.RED,
        alignment=ft.alignment.center,
        content=ft.Text("Page 2", color=ft.Colors.WHITE, size=24),
    )

    def animate(e):
        nonlocal toggle  # 声明使用外部变量
        toggle = not toggle
        animated_content.content = container1 if toggle else container2
        page.update()

    # 定义动画切换内容
    animated_content = ft.AnimatedSwitcher(
        content=container1,  # 初始内容
        transition=ft.AnimatedSwitcherTransition.SCALE,  # 使用缩放过渡
        duration=500,  # 动画持续时间（毫秒）
        switch_in_curve=ft.AnimationCurve.EASE_IN_OUT,  # 进入动画曲线
        switch_out_curve=ft.AnimationCurve.EASE_IN_OUT,  # 退出动画曲线
    )

    # 强制更新一次以确保初始状态正确
    page.update()

    # 添加列到页面
    page.add(
        ft.Column(
            [animated_content, ft.ElevatedButton("切换页面", on_click=animate)],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )
    )

    # 强制更新一次以确保初始状态正确
    page.update()

    # 手动触发一次动画以确保第一次点击时开始动画
    animate(None)


ft.app(target=main)