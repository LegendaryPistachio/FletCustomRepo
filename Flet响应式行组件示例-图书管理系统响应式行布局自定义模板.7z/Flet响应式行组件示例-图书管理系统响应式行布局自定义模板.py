import flet as ft


def main(page: ft.Page):
    page.title = "Flet响应式行组件示例-图书管理系统响应式行布局自定义模板"

    def page_resized(e):
        pw.value = f"{page.width} px"
        pw.update()

    page.on_resized = page_resized

    pw = ft.Text(bottom=50, right=50, style="displaySmall")
    page.overlay.append(pw)
    page.add(
        ft.ResponsiveRow(
            [
                ft.Container(
                    ft.TextButton(
                        text="查找图书",
                        icon=ft.Icons.SEARCH,
                        on_click=lambda e: print("查找图书"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.YELLOW,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
                ft.Container(
                    ft.TextButton(
                        text="添加图书",
                        icon=ft.Icons.ADD,
                        on_click=lambda e: print("添加图书"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.GREEN,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
                ft.Container(
                    ft.TextButton(
                        text="删除图书",
                        icon=ft.Icons.DELETE,
                        on_click=lambda e: print("删除图书"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.BLUE,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
                ft.Container(
                    ft.TextButton(
                        text="修改图书",
                        icon=ft.Icons.EDIT,
                        on_click=lambda e: print("修改图书"),
                    ),
                    padding=5,
                    bgcolor=ft.Colors.PINK_300,
                    col={"sm": 6, "md": 4, "xl": 2},
                ),
            ],
        ),
        ft.ResponsiveRow(
            [
                ft.TextField(label="搜索", prefix_icon=ft.Icons.SEARCH, col={"md": 4}),
                ft.TextField(label="图书名称", col={"md": 4}),
                ft.TextField(label="作者", col={"md": 4}),
            ],
            run_spacing={"xs": 10},
        ),
    )
    page_resized(None)


ft.app(target=main)
