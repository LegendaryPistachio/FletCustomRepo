import flet as ft
import asyncio


async def increase_size(page: ft.Page):
    # 初始化窗口大小
    initial_width = 320  # 初始宽度
    initial_height = 159  # 初始高度
    target_width = 640  # 目标宽度
    target_height = 319  # 目标高度
    total_duration = 5  # 动画持续时间（秒）
    frames_per_second = 30  # 每秒的帧数
    total_frames = total_duration * frames_per_second  # 总帧数
    width_increment = (target_width - initial_width) / total_frames  # 每帧增加的宽度
    height_increment = (target_height - initial_height) / total_frames  # 每帧增加的高度

    # 设置无框窗口
    page.window.resizable = False
    page.window.width = initial_width
    page.window.height = initial_height
    page.window.frameless = True  # 设置无框窗口
    page.padding = 0  # 去掉默认的 padding
    page.window.left = 400
    page.window.top = 300  # 修改为 300

    # 加载并填充图片
    img = ft.Image(
        src="cangku.png",
        width=initial_width,
        height=initial_height,
        fit=ft.ImageFit.CONTAIN,  # 使用 CONTAIN 使图片适应窗口
    )
    page.add(img)

    # 停留2秒
    await asyncio.sleep(2)

    # 动画过程
    for _ in range(total_frames):
        # 增加窗口大小并更新
        page.window.width += width_increment
        page.window.height += height_increment
        img.width = page.window.width
        img.height = page.window.height
        img.fit = ft.ImageFit.CONTAIN  # 确保图片适应新窗口大小
        page.update()  # 更新页面

        await asyncio.sleep(1 / frames_per_second)  # 控制帧速率


# 启动应用
ft.app(target=increase_size)
