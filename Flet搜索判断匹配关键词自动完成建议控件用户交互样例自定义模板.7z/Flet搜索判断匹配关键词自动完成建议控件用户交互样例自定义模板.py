import flet as ft


def update_suggestions(page, text):
    # 根据用户输入更新建议列表
    suggestions = [
        ft.AutoCompleteSuggestion(key=f"{value} {i}", value=value)
        for i, value in enumerate(
            [
                "One",
                "Two",
                "Three",
                "Four",
                "Five",
                "Six",
                "Seven",
                "Eight",
                "Nine",
                "Ten",
            ]
        )
        if value.lower().startswith(text.lower())
    ]
    page.auto_complete.suggestions = suggestions

    if not suggestions:
        page.selected_text.value = "没有匹配的建议"
    else:
        page.selected_text.value = "请选择一个建议项"

    page.update()


def on_select(e, page):
    # 更新文本组件以显示选中的建议
    page.selected_text.value = f"您选择了: {e.selection}"
    page.update()


def main(page: ft.Page):
    page.title = "Flet搜索判断匹配关键词自动完成建议控件用户交互样例自定义模板"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 20

    # 创建文本输入框
    input_field = ft.TextField(
        hint_text="输入关键词",
        on_change=lambda e: update_suggestions(
            page, e.control.value
        ),  # 使用 on_change 处理输入变化
        border_radius=5,
        border_color=ft.Colors.BLUE_500,
        focused_border_color=ft.Colors.BLUE_700,
        content_padding=ft.padding.all(10),
        prefix_icon=ft.Icons.SEARCH,
        width=300,
    )

    # 创建自动完成组件
    page.auto_complete = ft.AutoComplete(
        suggestions=[], on_select=lambda e: on_select(e, page)
    )

    # 创建文本组件，用于显示选中的建议
    page.selected_text = ft.Text(
        value="请选择一个建议项", size=16, color=ft.Colors.BLACK
    )

    # 将组件添加到页面
    page.add(
        ft.Column(
            [
                input_field,
                page.auto_complete,
                page.selected_text,
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )
    )


ft.app(target=main)
