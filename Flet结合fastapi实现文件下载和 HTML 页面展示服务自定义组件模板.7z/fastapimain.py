from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
import os
import uvicorn

app = FastAPI()
templates = Jinja2Templates(directory="html")


# 下载文件
@app.get("/download/{file_name}")
async def download_file(file_name: str):
    file_path = os.getcwd() + f"\\download\\{file_name}"
    # 检查文件是否存在
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="文件不存在")
    # 返回文件内容
    return FileResponse(
        file_path, media_type="application/octet-stream", filename=file_name
    )


# 展示html页面
@app.get("/html/{file_name}", response_class=HTMLResponse)
async def get_html(file_name: str):
    file_path = os.getcwd() + f"\\html\\{file_name}"

    # 检查文件是否存在
    if not os.path.exists(file_path):
        print(file_path)
        raise HTTPException(status_code=404, detail="文件不存在:")

    try:
        with open(file_path, "r") as file:
            html_content = file.read()
        return HTMLResponse(content=html_content, status_code=200)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    uvicorn.run(app=app, host="0.0.0.0", port=8840)
