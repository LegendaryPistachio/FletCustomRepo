import flet as ft


def main(page):
    page.title = "Window 1"
    page.window.width = 600
    page.window.height = 400
    page.add(ft.Text("This is the first independent window"))


def second_window(page):
    page.title = "Window 2"
    page.window.width = 630
    page.window.height = 430
    page.add(ft.Text("This is the second independent window"))


def third_window(page):
    page.title = "Window 3"
    page.window.width = 660
    page.window.height = 460
    page.add(ft.Text("This is the third independent window"))


def fourth_window(page):
    page.title = "Window 4"
    page.window.width = 690
    page.window.height = 490
    page.add(ft.Text("This is the fourth independent window"))


def fifth_window(page):
    page.title = "Window 5"
    page.window.width = 720
    page.window.height = 520
    page.add(ft.Text("This is the fifth independent window"))


def sixth_window(page):
    page.title = "Window 6"
    page.window.width = 750
    page.window.height = 550
    page.add(ft.Text("This is the sixth independent window"))


def seventh_window(page):
    page.title = "Window 7"
    page.window.width = 780
    page.window.height = 580
    page.add(ft.Text("This is the seventh independent window"))


if __name__ == "__main__":
    # Create the first window
    ft.app(target=main)

    # Create the second window
    ft.app(target=second_window)

    # Create the third window
    ft.app(target=third_window)

    # Create the fourth window
    ft.app(target=fourth_window)

    # Create the fifth window
    ft.app(target=fifth_window)

    # Create the sixth window
    ft.app(target=sixth_window)

    # Create the seventh window
    ft.app(target=seventh_window)
