import flet as ft


def main(page: ft.Page):
    page.window.width = 600
    page.window.height = 400

    def route_change(route):
        page.views.clear()

        if page.route == "/":
            page.title = "Main Window"
            view = ft.View(
                "/",
                [
                    ft.AppBar(
                        title=ft.Text("Main Window"),
                        bgcolor=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                    ft.Column(
                        [
                            ft.ElevatedButton(
                                text="Go to ChildWindow1",
                                on_click=lambda e: page.go("/view1"),
                            ),
                            ft.ElevatedButton(
                                text="Go to ChildWindow2",
                                on_click=lambda e: page.go("/view2"),
                            ),
                            ft.ElevatedButton(
                                text="Go to ChildWindow3",
                                on_click=lambda e: page.go("/view3"),
                            ),
                            ft.ElevatedButton(
                                text="Go to ChildWindow4",
                                on_click=lambda e: page.go("/view4"),
                            ),
                        ]
                    ),
                ],
            )
        elif page.route == "/view1":
            page.title = "ChildWindow1"
            view = ft.View(
                "/view1",
                [
                    ft.AppBar(
                        title=ft.Text("ChildWindow1"),
                        bgcolor=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                    ft.Column([ft.Text("This is ChildWindow1")]),
                    ft.ElevatedButton(
                        text="Back to Main", on_click=lambda e: page.go("/")
                    ),
                ],
            )
        elif page.route == "/view2":
            page.title = "ChildWindow2"
            view = ft.View(
                "/view2",
                [
                    ft.AppBar(
                        title=ft.Text("ChildWindow2"),
                        bgcolor=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                    ft.Column([ft.Text("This is ChildWindow2")]),
                    ft.ElevatedButton(
                        text="Back to Main", on_click=lambda e: page.go("/")
                    ),
                ],
            )
        elif page.route == "/view3":
            page.title = "ChildWindow3"
            view = ft.View(
                "/view3",
                [
                    ft.AppBar(
                        title=ft.Text("ChildWindow3"),
                        bgcolor=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                    ft.Column([ft.Text("This is ChildWindow3")]),
                    ft.ElevatedButton(
                        text="Back to Main", on_click=lambda e: page.go("/")
                    ),
                ],
            )
        elif page.route == "/view4":
            page.title = "ChildWindow4"
            view = ft.View(
                "/view4",
                [
                    ft.AppBar(
                        title=ft.Text("ChildWindow4"),
                        bgcolor=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                    ft.Column([ft.Text("This is ChildWindow4")]),
                    ft.ElevatedButton(
                        text="Back to Main", on_click=lambda e: page.go("/")
                    ),
                ],
            )

        page.views.append(view)
        page.update()

    page.on_route_change = route_change
    page.go("/")  # Set initial route to the main page


ft.app(target=main)
