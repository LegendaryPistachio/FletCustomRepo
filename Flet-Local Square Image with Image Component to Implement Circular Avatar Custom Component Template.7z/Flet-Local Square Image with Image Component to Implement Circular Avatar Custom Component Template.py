import flet as ft


def main(page: ft.Page):
    # Set the page title
    page.title = "Flet Local Square Image with Image Component to Implement Circular Avatar Custom Component Template"

    # Create a square Image component and use Container to add a border
    square_image = ft.Container(
        content=ft.Image(
            src="logo.png",  # Image path
            width=100,  # Width
            height=100,  # Height
            border_radius=50,  # Border radius, set to half of the width to form a circle
        ),
        width=110,
        height=110,
        border_radius=55,
        bgcolor="green",  # Set the background color of the Container to green
        padding=3,  # Ensure the image is tightly against the edge of the Container
    )

    # Add the Container component to the page
    page.add(square_image)


# Run the Flet app
ft.app(target=main)
