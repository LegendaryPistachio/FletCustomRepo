import flet as ft

# Define a shared data store
shared_data = {}

# Define the main window function
def main_window(page: ft.Page):
    page.title = "Main Window - Flet Shared Data Storage Multi-Window Management Custom Template"
    page.add(ft.Text("This is the main window"))
    page.add(ft.ElevatedButton("Open Sub Window 1", on_click=lambda _: open_sub_window1(page)))
    page.add(ft.ElevatedButton("Open Sub Window 2", on_click=lambda _: open_sub_window2(page)))
    page.add(ft.ElevatedButton("Open Sub Window 3", on_click=lambda _: open_sub_window3(page)))

# Define the sub window 1 function
def sub_window1(page: ft.Page):
    page.title = "Sub Window 1"
    page.add(ft.Text("This is sub window 1"))
    page.add(ft.ElevatedButton("Back to Main Window", on_click=lambda _: go_back_to_main_window(page)))

# Define the sub window 2 function
def sub_window2(page: ft.Page):
    page.title = "Sub Window 2"
    page.add(ft.Text("This is sub window 2"))
    page.add(ft.ElevatedButton("Back to Main Window", on_click=lambda _: go_back_to_main_window(page)))

# Define the sub window 3 function
def sub_window3(page: ft.Page):
    page.title = "Sub Window 3"
    page.add(ft.Text("This is sub window 3"))
    page.add(ft.ElevatedButton("Back to Main Window", on_click=lambda _: go_back_to_main_window(page)))

# Define a function to open a new sub window
def open_sub_window1(page: ft.Page):
    page.clean()  # Clear all controls on the page
    sub_window1(page)

def open_sub_window2(page: ft.Page):
    page.clean()  # Clear all controls on the page
    sub_window2(page)

def open_sub_window3(page: ft.Page):
    page.clean()  # Clear all controls on the page
    sub_window3(page)

# Define a function to return to the main window
def go_back_to_main_window(page: ft.Page):
    page.clean()  # Clear all controls on the page
    main_window(page)

# Main function
def main(page: ft.Page):
    # Set window size and other properties
    page.window.width = 700
    page.window.height = 400
    page.window.resizable = False
    page.window.prevent_close = False
    page.on_close = lambda e: page.window_destroy()
    
    # Initialize shared data
    shared_data['counter'] = 0
    
    # Open the main window
    main_window(page)

# Run the application
ft.app(target=main)