import flet as ft  
import math  
import asyncio  

# 定义8字舞路径的函数  
def figure_eight_path(t, radius):  
    """计算8字形舞路径的坐标"""  
    x = radius * math.sin(t * 2 * math.pi)  # X 坐标变化  
    y = radius * math.sin(t * 4 * math.pi) / 2  # Y 坐标变化  
    return x, y  

async def main(page: ft.Page):  
    # 创建蝴蝶的图片控件  
    butterfly_image = ft.Image(  
        src="蝴蝶.png",  # 确保路径正确  
        width=100,  
        height=100,  
    )  

    # 创建用于显示蝴蝶的容器  
    container = ft.Container(  
        content=butterfly_image,  
        alignment=ft.alignment.center,  
        width=100,  
        height=100,  
    )  

    # 创建堆栈以绝对定位容器  
    stack = ft.Stack(  
        controls=[container],  
        width=400,  
        height=400,  
    )  

    page.add(stack)  

    duration = 5000  # 动画持续时间  
    steps = 300  # 动画步数  
    radius = 100  # 8字舞的半径  

    # 运行动画  
    while True:  
        await animate_butterfly(page, container, steps, duration, radius)  

async def animate_butterfly(page, container, steps, duration, radius):  
    for t in range(steps + 1):  
        progress = t / steps  
        x, y = figure_eight_path(progress, radius)  

        # 更新蝴蝶的位置  
        container.left = x + 150  # 加上偏移量  
        container.top = y + 150    # 加上偏移量  

        # 更新不透明度  
        opacity = 1 - (t / steps) ** 2  
        container.opacity = opacity  
        page.update()  
        await asyncio.sleep(duration / (steps * 1000))  # 控制帧率  

# 运行应用  
ft.app(main)  