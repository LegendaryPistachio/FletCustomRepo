import flet as ft
import asyncio

def main(page: ft.Page):

    c = ft.Container(
        width=150,
        height=150,
        bgcolor="white",
        border_radius=10,
        animate_opacity=100,  # Set the speed of the animation opacity
        content=ft.Image(src="fletlogo.png", width=150, height=150),  # Load logo image
    )

    async def animate_blink():
        while True:
            c.opacity = 0  # Fully transparent
            await c.update_async()
            await asyncio.sleep(1)  # Wait for 1 second
            c.opacity = 1  # Fully opaque
            await c.update_async()
            await asyncio.sleep(0.5)  # Wait for 0.5 seconds

    async def start_blink(e):
        asyncio.create_task(animate_blink())

    page.add(c)

    # Start blinking effect
    page.add(ft.ElevatedButton("Start Blinking", on_click=start_blink))

ft.app(target=main)