import flet as ft

# Create child window logic
class ChildWindow:
    def __init__(self, title, manager):
        self.title = title
        self.manager = manager
        self.visible = False  # Initial state is invisible
        self.control = self.build()

    def build(self):
        return ft.Container(
            content=ft.Column(
                [
                    ft.Text(self.title, size=20, weight="bold"),
                    ft.Text(f"This is the content of {self.title}."),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.STRETCH,  # Stretch horizontally to fit width
                expand=True  # Set expand to True to adapt to width and height
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.BLUE),  # Use ft.Colors
            margin=10,
            visible=self.visible,
            expand=True  # Set expand to True to adapt to width and height
        )

    def show(self):
        if not self.control.page:  # Check if control has been added to the page
            self.manager.add_child(self)  # If not, re-add it
        self.control.visible = True
        self.control.update()
        self.visible = True
        print(f"Show child window: {self.title}")

    def hide(self):
        if self.control.page:  # Ensure control has been added to the page
            self.control.visible = False
            self.control.update()
        self.visible = False
        print(f"Hide child window: {self.title}")

# Create main window and window manager logic
class WindowManager:
    def __init__(self, page):
        self.page = page
        self.child_windows = {}
        self.display_order = []  # Used to record the display order of child windows
        self.child_windows_column_ref = ft.Ref[ft.Column]()  # Create Ref object
        self.control = self.build()

    def build(self):
        buttons = []
        for i in range(1, 4):
            title = f"Child Window {i}"
            child_window = ChildWindow(title, self)
            self.child_windows[title] = child_window

            buttons.extend([
                ft.ElevatedButton(f"Show {title}", on_click=lambda e, cw=child_window: cw.show()),
                ft.ElevatedButton(f"Hide {title}", on_click=lambda e, cw=child_window: cw.hide()),
                ft.ElevatedButton(f"Close {title}", on_click=lambda e, cw=child_window: cw.manager.remove_child(cw)),
            ])

        button_rows = [
            ft.Row(buttons[i*3:(i+1)*3], alignment=ft.MainAxisAlignment.CENTER)
            for i in range(3)
        ]

        # Build Column control and assign to self.child_windows_column_ref
        child_windows_column = ft.Column(ref=self.child_windows_column_ref, controls=[], spacing=10, expand=True)
        
        # Initialize by adding child windows to the page and hiding them
        for child_window in self.child_windows.values():
            child_windows_column.controls.append(child_window.control)
            child_window.hide()

        # Add button to close main window
        close_main_button = ft.ElevatedButton("Close Main Window", on_click=self.close_main_window)

        return ft.Column(
            [
                ft.Text("Window Manager", size=30, weight="bold", text_align=ft.TextAlign.CENTER),
                ft.Container(
                    content=ft.Column(button_rows, spacing=10),
                    border=ft.border.all(1, ft.Colors.BLUE),  # Add border
                    padding=10,
                    margin=10,
                ),
                child_windows_column,  # Use the built Column control directly
                close_main_button,  # Add button to close main window
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # Center align horizontally
            expand=True  # Set expand to True to adapt to width
        )

    def add_child(self, child_window):
        if child_window.control not in self.child_windows_column_ref.current.controls:
            self.child_windows_column_ref.current.controls.append(child_window.control)
            self.child_windows_column_ref.current.update()
            print(f"Add child window: {child_window.title}")

    def show_child(self, child_window):
        if not child_window.control.page:  # Check if control has been added to the page
            self.add_child(child_window)  # If not, re-add it
        child_window.control.visible = True
        child_window.control.update()
        child_window.visible = True

        # Move child window to the end of the display order list
        if child_window in self.display_order:
            self.display_order.remove(child_window)
        self.display_order.append(child_window)

        # Update the display order of child windows
        self.update_display_order()
        print(f"Show child window: {child_window.title}")

    def hide_child(self, child_window):
        if child_window.control.page:  # Ensure control has been added to the page
            child_window.control.visible = False
            child_window.control.update()
        child_window.visible = False

        # Remove child window from the display order list
        if child_window in self.display_order:
            self.display_order.remove(child_window)

        print(f"Hide child window: {child_window.title}")

    def remove_child(self, child_window):
        if child_window.control in self.child_windows_column_ref.current.controls:
            self.child_windows_column_ref.current.controls.remove(child_window.control)
            self.child_windows_column_ref.current.update()
            child_window.control.visible = False  # Hide control

            # Remove child window from the display order list
            if child_window in self.display_order:
                self.display_order.remove(child_window)

            print(f"Close child window: {child_window.title}")
        else:
            print(f"Child window {child_window.title} is not in the page, cannot close")

    def update_display_order(self):
        # Update the display order of child windows based on the display order list
        controls = [cw.control for cw in self.display_order]
        self.child_windows_column_ref.current.controls = controls
        self.child_windows_column_ref.current.update()
        print("Update child window display order")

    def update(self):
        self.child_windows_column_ref.current.update()  # Update Column control to reflect changes
        print("Update control")

    def close_main_window(self, e):
        print("Close main window")
        self.page.window_close()  # Close main window

# Start the application
def main(page: ft.Page):
    page.title = "Window Manager Example"
    page.expand = True  # Set page to adapt
    manager = WindowManager(page)
    page.add(manager.control)
    page.update()  # Ensure page updates on initial load

# Run Flet application
ft.app(target=main)