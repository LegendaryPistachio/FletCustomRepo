import flet as ft

# 定义一个共享的数据存储
shared_data = {}

# 定义主窗口函数
def main_window(page: ft.Page):
    page.title = "主窗口-Flet共享数据存储多窗口管理自定义模板"
    page.add(ft.Text("这是主窗口"))
    page.add(ft.ElevatedButton("打开子窗口1", on_click=lambda _: open_sub_window1(page)))
    page.add(ft.ElevatedButton("打开子窗口2", on_click=lambda _: open_sub_window2(page)))
    page.add(ft.ElevatedButton("打开子窗口3", on_click=lambda _: open_sub_window3(page)))

# 定义子窗口1函数
def sub_window1(page: ft.Page):
    page.title = "子窗口1"
    page.add(ft.Text("这是子窗口1"))
    page.add(ft.ElevatedButton("返回主窗口", on_click=lambda _: go_back_to_main_window(page)))

# 定义子窗口2函数
def sub_window2(page: ft.Page):
    page.title = "子窗口2"
    page.add(ft.Text("这是子窗口2"))
    page.add(ft.ElevatedButton("返回主窗口", on_click=lambda _: go_back_to_main_window(page)))

# 定义子窗口3函数
def sub_window3(page: ft.Page):
    page.title = "子窗口3"
    page.add(ft.Text("这是子窗口3"))
    page.add(ft.ElevatedButton("返回主窗口", on_click=lambda _: go_back_to_main_window(page)))

# 定义一个函数来打开新子窗口
def open_sub_window1(page: ft.Page):
    page.clean()  # 清除页面上的所有控件
    sub_window1(page)

def open_sub_window2(page: ft.Page):
    page.clean()  # 清除页面上的所有控件
    sub_window2(page)

def open_sub_window3(page: ft.Page):
    page.clean()  # 清除页面上的所有控件
    sub_window3(page)

# 定义一个函数来返回主窗口
def go_back_to_main_window(page: ft.Page):
    page.clean()  # 清除页面上的所有控件
    main_window(page)

# 主函数
def main(page: ft.Page):
    # 使用新的属性设置窗口大小和其他属性
    page.window.width = 600
    page.window.height = 400
    page.window.resizable = False
    page.window.prevent_close = False
    page.on_close = lambda e: page.window_destroy()
    
    # 初始化共享数据
    shared_data['counter'] = 0
    
    # 打开主窗口
    main_window(page)

# 运行应用程序
ft.app(target=main)
