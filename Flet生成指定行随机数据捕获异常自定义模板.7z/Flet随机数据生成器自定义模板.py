import random
import string
import flet as ft


def generate_random_data(num_lines, line_length):
    """
    生成指定行数的随机字符串数据
    :param num_lines: 要生成的行数
    :param line_length: 每行字符串的长度
    :return: 包含随机字符串的列表
    """
    data = []
    for _ in range(num_lines):
        random_string = "".join(
            random.choices(string.ascii_letters + string.digits, k=line_length)
        )
        data.append(random_string)
    return data


def do(num_lines, line_length, output_file):
    """
    执行生成随机数据并保存到文件的操作
    :param num_lines: 要生成的行数
    :param line_length: 每行字符串的长度
    :param output_file: 输出文件路径
    """
    try:
        data = generate_random_data(num_lines, line_length)
        with open(output_file, "w") as file:
            for line in data:
                file.write(line + "\n")
        print(f"成功生成 {num_lines} 行随机数据并保存到 {output_file}")
    except Exception as e:
        print(f"生成随机数据时发生错误: {e}")


def main(page: ft.Page):
    page.title = "随机数据生成器"
    page.vertical_alignment = ft.MainAxisAlignment.START  # 修改为顶部对齐
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    num_lines_input = ft.TextField(label="行数", value="10")
    line_length_input = ft.TextField(label="每行长度", value="20")
    output_file_input = ft.TextField(label="输出文件路径", value="random_data.txt")
    result_label = ft.Text()

    def generate_click(e):
        try:
            num_lines = int(num_lines_input.value)
            line_length = int(line_length_input.value)
            output_file = output_file_input.value
            do(num_lines, line_length, output_file)
            result_label.value = (
                f"成功生成 {num_lines} 行随机数据并保存到 {output_file}"
            )
        except ValueError:
            result_label.value = "请输入有效的数字"
        except Exception as e:
            result_label.value = f"生成随机数据时发生错误: {e}"
        page.update()

    generate_button = ft.ElevatedButton(text="生成", on_click=generate_click)

    page.add(
        ft.Column(
            [
                num_lines_input,
                line_length_input,
                output_file_input,
                generate_button,
                result_label,
            ],
            alignment=ft.MainAxisAlignment.START,  # 修改为顶部对齐
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )


ft.app(target=main)
