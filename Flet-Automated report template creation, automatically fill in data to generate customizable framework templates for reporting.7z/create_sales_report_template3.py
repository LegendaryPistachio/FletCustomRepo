# create_sales_report_template3.py
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, Border, Side, PatternFill

def create_sales_report_template3():
    # Create a new workbook
    wb = Workbook()
    ws = wb.active
    
    # Set the worksheet name
    ws.title = "Sales Report 3"
    
    # Add the title
    ws['A1'] = "Sales Report 3"
    
    # Merge cells to center the title
    ws.merge_cells('A1:F1')
    
    # Set the title style (optional)
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
    
    # Add column headers
    headers = ["Product Name", "Quantity", "Unit Price", "Discount", "Tax Amount", "Total Price"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # Set column header styles (optional)
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="4F8A3D", end_color="4F8A3D", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # Set column widths
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    
    # Save the workbook
    wb.save("sales_report_template3.xlsx")

if __name__ == "__main__":
    create_sales_report_template3()
    print("Sales report template file 'sales_report_template3.xlsx' has been successfully created.")