import flet as ft
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, Border, Side, PatternFill
import os

def create_sales_report_template1():
    # Create a new workbook
    wb = Workbook()
    ws = wb.active
    
    # Set the worksheet name
    ws.title = "Sales Report 1"
    
    # Add the title
    ws['A1'] = "Sales Report 1"
    
    # Merge cells to center the title
    ws.merge_cells('A1:F1')
    
    # Set the title style (optional)
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
    
    # Add column headers
    headers = ["Product Name", "Quantity", "Unit Price", "Discount", "Tax Amount", "Total Price"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # Set column header styles (optional)
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="4F8A3D", end_color="4F8A3D", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # Set column widths
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    
    # Save the workbook
    wb.save("sales_report_template1.xlsx")
    return "sales_report_template1.xlsx"

def create_sales_report_template2():
    # Create a new workbook
    wb = Workbook()
    ws = wb.active
    
    # Set the worksheet name
    ws.title = "Sales Report 2"
    
    # Add the title
    ws['A1'] = "Sales Report 2"
    
    # Merge cells to center the title
    ws.merge_cells('A1:F1')
    
    # Set the title style (optional)
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
    
    # Add column headers
    headers = ["Product Name", "Quantity", "Unit Price", "Discount", "Tax Amount", "Total Price"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # Set column header styles (optional)
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="4F8A3D", end_color="4F8A3D", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # Set column widths
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    
    # Save the workbook
    wb.save("sales_report_template2.xlsx")
    return "sales_report_template2.xlsx"

def create_sales_report_template3():
    # Create a new workbook
    wb = Workbook()
    ws = wb.active
    
    # Set the worksheet name
    ws.title = "Sales Report 3"
    
    # Add the title
    ws['A1'] = "Sales Report 3"
    
    # Merge cells to center the title
    ws.merge_cells('A1:F1')
    
    # Set the title style (optional)
    title_cell = ws['A1']
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
    
    # Add column headers
    headers = ["Product Name", "Quantity", "Unit Price", "Discount", "Tax Amount", "Total Price"]
    for col_num, header in enumerate(headers, start=1):
        ws.cell(row=2, column=col_num, value=header)
    
    # Set column header styles (optional)
    for row in ws["2:2"]:
        row.font = Font(bold=True, color="FFFFFF")
        row.fill = PatternFill(start_color="4F8A3D", end_color="4F8A3D", fill_type="solid")
        row.border = Border(bottom=Side(style='thin'))
    
    # Set column widths
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 10
    ws.column_dimensions['D'].width = 10
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    
    # Save the workbook
    wb.save("sales_report_template3.xlsx")
    return "sales_report_template3.xlsx"

def load_template(template_path):
    if os.path.exists(template_path):
        return load_workbook(template_path)
    else:
        return None

def fill_data(ws, data):
    for row_num, row_data in enumerate(data, start=3):
        for col_num, cell_value in enumerate(row_data, start=1):
            ws.cell(row=row_num, column=col_num, value=cell_value)

def save_report(wb, file_name):
    wb.save(file_name)
    return file_name

def clear_data(ws):
    for row in ws.iter_rows(min_row=3):
        for cell in row:
            cell.value = None

def main(page: ft.Page):
    page.title = "Flet Automated Sales Report Template Creation and Data Filling"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    template_options = {
        "Sales Report 1": create_sales_report_template1,
        "Sales Report 2": create_sales_report_template2,
        "Sales Report 3": create_sales_report_template3,
    }
    
    def create_template_click(e):
        selected_template = template_dropdown.value
        if selected_template:
            template_path = template_options[selected_template]()
            template_text.value = f"Template created: {template_path}"
            template_container.update()
        else:
            template_text.value = "Please select a template"
            template_container.update()
    
    def select_template_click(e):
        file_picker.pick_files(allowed_extensions=["xlsx"])
    
    def file_picker_result(e: ft.FilePickerResultEvent):
        if e.files:
            selected_template_path.value = e.files[0].path
            selected_template_text.value = f"Selected template: {e.files[0].name}"
            selected_template_container.update()
        else:
            selected_template_text.value = "No file selected"
            selected_template_container.update()
    
    def fill_data_click(e):
        if selected_template_path.value:
            wb = load_template(selected_template_path.value)
            if wb:
                ws = wb.active
                data = [
                    ["Product A", 10, 50, 0.1, 5, 450],
                    ["Product B", 5, 100, 0.05, 2.5, 472.5]
                ]
                fill_data(ws, data)
                save_report(wb, "filled_sales_report.xlsx")
                result_text.value = "Data filled and saved as filled_sales_report.xlsx"
                result_container.update()
            else:
                result_text.value = "Failed to load template file"
                result_container.update()
        else:
            result_text.value = "Please select a template file"
            result_container.update()
    
    def clear_data_click(e):
        if selected_template_path.value:
            wb = load_template(selected_template_path.value)
            if wb:
                ws = wb.active
                clear_data(ws)
                save_report(wb, "cleared_sales_report.xlsx")
                result_text.value = "Data cleared and saved as cleared_sales_report.xlsx"
                result_container.update()
            else:
                result_text.value = "Failed to load template file"
                result_container.update()
        else:
            result_text.value = "Please select a template file"
            result_container.update()
    
    template_text = ft.Text(value="", color="green")
    selected_template_text = ft.Text(value="", color="blue")
    result_text = ft.Text(value="", color="red")
    selected_template_path = ft.Ref[str]()

    template_dropdown = ft.Dropdown(
        label="Select a template creation script",
        options=[ft.dropdown.Option(k) for k in template_options.keys()],
        width=300
    )

    file_picker = ft.FilePicker(on_result=file_picker_result)
    page.overlay.append(file_picker)

    # Create buttons with icons
    create_template_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.PLAY_ARROW, color="blue", size=24),  # Change icon to PLAY_ARROW and set fixed width
                ft.Text("Run script to create styled report template")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=create_template_click,
        width=300  # Restore fixed width
    )

    select_template_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.FOLDER_OPEN, color="blue", size=24),  # Add folder open icon
                ft.Text("Select your preferred styled report template")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=select_template_click,
        width=300  # Restore fixed width
    )

    fill_data_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.ADD, color="blue", size=24),  # Add plus icon
                ft.Text("Fill data and save generated report")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=fill_data_click,
        width=300  # Restore fixed width
    )

    clear_data_button = ft.ElevatedButton(
        content=ft.Row(
            [
                ft.Icon(name=ft.icons.CLEAR, color="blue", size=24),  # Add clear icon
                ft.Text("Clear data and save blank styled report")
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        on_click=clear_data_click,
        width=300  # Restore fixed width
    )

    # Use Container to wrap template_text and set border
    template_container = ft.Container(
        content=template_text,
        border=ft.border.all(1, "black"),  # Set border width to 1, color to black
        padding=10,  # Set padding
        width=300  # Set width
    )

    # Use Container to wrap selected_template_text and set border
    selected_template_container = ft.Container(
        content=selected_template_text,
        border=ft.border.all(1, "black"),  # Set border width to 1, color to black
        padding=10,  # Set padding
        width=300  # Set width
    )

    # Use Container to wrap result_text and set border
    result_container = ft.Container(
        content=result_text,
        border=ft.border.all(1, "black"),  # Set border width to 1, color to black
        padding=10,  # Set padding
        width=300  # Set width
    )

    page.add(
        ft.Column([
            template_dropdown,
            create_template_button,  # Use button with icon
            template_container,  # Use Container with border
            select_template_button,
            selected_template_container,  # Use Container with border
            fill_data_button,
            clear_data_button,
            result_container,  # Use Container with border
        ])
    )

ft.app(target=main)