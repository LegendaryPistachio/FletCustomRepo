import flet as ft
from flet import Icons  # Import Icons module
import threading
import time

# Image list
images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg",
    "image6.jpg",
    "image7.jpg",
]


def change_image(index, image_container, buttons, page):
    image_container.content.src = images[index]
    page.update()
    # Update the selected state of the buttons
    for i, button in enumerate(buttons):
        button.selected = i == index
    page.update()


def auto_change_image(image_container, buttons, page):
    current_index = 0

    def change():
        nonlocal current_index
        while True:
            current_index = (current_index + 1) % len(images)
            change_image(current_index, image_container, buttons, page)
            buttons[current_index].on_click(None)  # Simulate button click event
            time.sleep(3)  # 3 seconds

    # Create and start the thread
    thread = threading.Thread(target=change, daemon=True)
    thread.start()


def main(page: ft.Page):
    page.title = "Flet Circular Button Auto-Click Image Carousel Custom Component Template"

    # Initialize current image index
    current_index = 0

    # Image container
    image_container = ft.Container(
        content=ft.Image(
            src=images[current_index], width=1000, height=500, fit=ft.ImageFit.COVER
        ),
        alignment=ft.alignment.center,
    )

    # Button row
    buttons = [
        ft.IconButton(
            icon=Icons.CIRCLE_SHARP,  # Use CIRCLE_SHARP icon
            selected_icon=Icons.CIRCLE_SHARP,  # Optional: Set the icon when selected
            icon_color="blue",  # Optional: Set the icon color
            selected_icon_color="red",  # Optional: Set the icon color when selected
            tooltip=f"Image {i+1}",  # Optional: Set tooltip
            selected=i == current_index,  # Initialize selected state
            on_click=lambda e, i=i: change_image(i, image_container, buttons, page),
        )
        for i in range(len(images))
    ]
    buttons_row = ft.Row(
        buttons,
        alignment=ft.MainAxisAlignment.CENTER,
        width=500,  # Adjust the width of the Row to fit all buttons
    )

    # Use Stack to stack image_container and buttons_row together
    stack = ft.Stack(
        [
            image_container,
            ft.Container(
                content=buttons_row,
                alignment=ft.alignment.bottom_center,  # Place the button row at the bottom center
                margin=ft.margin.only(bottom=20),  # Adjust the bottom margin of the button row
            ),
        ],
        width=1000,  # Set the width of the Stack
        height=500,  # Set the height of the Stack
    )

    # Add Stack to the page
    page.add(
        ft.Column(
            [
                ft.Row(
                    [stack],
                    alignment=ft.MainAxisAlignment.CENTER,  # Center horizontally
                    expand=True,  # Make the Row take the full page width
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,  # Center vertically
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # Center horizontally
            expand=True,  # Make the Column take the full page height
        )
    )

    # Start the timer
    auto_change_image(image_container, buttons, page)


ft.app(target=main)