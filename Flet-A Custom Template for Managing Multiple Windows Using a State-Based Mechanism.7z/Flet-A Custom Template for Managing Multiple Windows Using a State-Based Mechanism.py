import flet as ft

class MyApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.main_window = self.create_main_window()
        self.sub_window1 = self.create_sub_window("Sub Window 1")
        self.sub_window2 = self.create_sub_window("Sub Window 2")
        self.sub_window3 = self.create_sub_window("Sub Window 3")
        self.current_window = self.main_window
        self.page.add(self.current_window)

    def create_main_window(self):
        main_window = ft.Column(
            [
                ft.Text("Main Window", size=20),
                ft.Row(
                    [
                        ft.ElevatedButton("Open Sub Window 1", on_click=lambda _: self.switch_window(self.sub_window1)),
                        ft.ElevatedButton("Open Sub Window 2", on_click=lambda _: self.switch_window(self.sub_window2)),
                        ft.ElevatedButton("Open Sub Window 3", on_click=lambda _: self.switch_window(self.sub_window3)),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
        return main_window

    def create_sub_window(self, title):
        sub_window = ft.Column(
            [
                ft.Text(title, size=20),
                ft.ElevatedButton("Back to Main Window", on_click=lambda _: self.switch_window(self.main_window)),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
        return sub_window

    def switch_window(self, new_window):
        self.page.clean()  # Clear the current content of the page
        self.current_window = new_window
        self.page.add(self.current_window)  # Add the new window to the page

def main(page: ft.Page):
    page.title = "Flet Custom Template for Managing Multiple Windows Using a State-Based Mechanism"
    app = MyApp(page)

ft.app(target=main)