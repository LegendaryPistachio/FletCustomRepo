# product_table_ui.py
import flet as ft
import websockets
import asyncio
import json
import requests
import logging

# 配置日志记录
logging.basicConfig(level=logging.INFO)

header_list = ["序号", "产品名称", "SN号", "规格型号", "数量", "产品问题描述", "操作"]


async def listen_to_server(data_table):
    uri = "ws://127.0.0.1:8000/ws"
    try:
        async with websockets.connect(uri) as websocket:
            logging.info(f"Connected to WebSocket server at {uri}")
            while True:
                message = await websocket.recv()
                data = json.loads(message)
                if data["action"] == "add":
                    add_row(data_table, data["data"])
    except Exception as e:
        logging.error(f"WebSocket connection failed: {e}")


def add_row(data_table, row_data):
    row_index = len(data_table.rows)
    data_table.rows.append(
        ft.DataRow(
            [
                ft.DataCell(
                    ft.Text(
                        str(row_index + 1),
                        color="black",
                        weight="bold",
                        text_align=ft.TextAlign.CENTER,
                        width=30,
                    )
                ),
                ft.DataCell(
                    ft.Text(
                        row_data["product_name"],
                        color="black",
                        weight="bold",
                        text_align=ft.TextAlign.CENTER,
                    )
                ),
                ft.DataCell(
                    ft.Text(
                        row_data["sn_number"],
                        color="black",
                        weight="bold",
                        text_align=ft.TextAlign.CENTER,
                    )
                ),
                ft.DataCell(
                    ft.Text(
                        row_data["model"],
                        color="black",
                        weight="bold",
                        text_align=ft.TextAlign.CENTER,
                    )
                ),
                ft.DataCell(
                    ft.Text(
                        str(row_data["quantity"]),
                        color="black",
                        weight="bold",
                        text_align=ft.TextAlign.CENTER,
                    )
                ),
                ft.DataCell(
                    ft.Text(
                        row_data["description"],
                        color="black",
                        weight="bold",
                        text_align=ft.TextAlign.CENTER,
                    )
                ),
                ft.DataCell(
                    ft.Container(
                        content=ft.Row(
                            [
                                ft.IconButton(
                                    icon=ft.Icons.ADD_CIRCLE_OUTLINE_ROUNDED,
                                    icon_color=ft.Colors.GREEN,
                                    tooltip=ft.Tooltip(message="增加一行"),
                                    style=ft.ButtonStyle(
                                        shape={"": ft.RoundedRectangleBorder(radius=8)}
                                    ),
                                    on_click=lambda e, dt=data_table: add_row(
                                        dt,
                                        {
                                            "product_name": "",
                                            "sn_number": "",
                                            "model": "",
                                            "quantity": 0,
                                            "description": "",
                                        },
                                    ),
                                ),
                                ft.IconButton(
                                    icon=ft.Icons.REMOVE_CIRCLE_OUTLINE_ROUNDED,
                                    icon_color=ft.Colors.RED,
                                    tooltip=ft.Tooltip(message="删除一行"),
                                    style=ft.ButtonStyle(
                                        shape={"": ft.RoundedRectangleBorder(radius=8)}
                                    ),
                                    on_click=lambda e, dt=data_table, ri=row_index: remove_row(
                                        e, dt, ri
                                    ),
                                ),
                            ],
                            spacing=5,
                            expand=True,
                        ),
                        width=80,
                        alignment=ft.alignment.center,
                    )
                ),
            ]
        )
    )
    data_table.update()


def remove_row(e, data_table, row_index):
    if 0 <= row_index < len(data_table.rows):
        del data_table.rows[row_index]
        data_table.update()


class CustomDataTable(ft.DataTable):
    def __init__(self):
        columns = [
            ft.DataColumn(
                label=ft.Text(
                    index, color="black", weight="bold", text_align=ft.TextAlign.CENTER
                ),
                heading_row_alignment=ft.MainAxisAlignment.CENTER,
            )
            for index in header_list
        ]
        super().__init__(columns=columns)
        self.expand = True  # 让表格自动扩展
        self.vertical_lines = ft.border.BorderSide(1, "#ebebeb")
        self.column_spacing = 5
        self.data_row_max_height = 50
        self.heading_row_color = ft.Colors.BLUE_50  # 修改这里
        self.rows = []
        self.load_data()

    def load_data(self):
        products = fetch_data()
        for idx, product in enumerate(products, start=1):
            self.rows.append(
                ft.DataRow(
                    [
                        ft.DataCell(
                            ft.Text(
                                str(idx),
                                color="black",
                                weight="bold",
                                text_align=ft.TextAlign.CENTER,
                                width=30,
                            )
                        ),
                        ft.DataCell(
                            ft.Text(
                                product["product_name"],
                                color="black",
                                weight="bold",
                                text_align=ft.TextAlign.CENTER,
                            )
                        ),
                        ft.DataCell(
                            ft.Text(
                                product["sn_number"],
                                color="black",
                                weight="bold",
                                text_align=ft.TextAlign.CENTER,
                            )
                        ),
                        ft.DataCell(
                            ft.Text(
                                product["model"],
                                color="black",
                                weight="bold",
                                text_align=ft.TextAlign.CENTER,
                            )
                        ),
                        ft.DataCell(
                            ft.Text(
                                str(product["quantity"]),
                                color="black",
                                weight="bold",
                                text_align=ft.TextAlign.CENTER,
                            )
                        ),
                        ft.DataCell(
                            ft.Text(
                                product["description"],
                                color="black",
                                weight="bold",
                                text_align=ft.TextAlign.CENTER,
                            )
                        ),
                        ft.DataCell(
                            ft.Container(
                                content=ft.Row(
                                    [
                                        ft.IconButton(
                                            icon=ft.Icons.ADD_CIRCLE_OUTLINE_ROUNDED,
                                            icon_color=ft.Colors.GREEN,
                                            tooltip=ft.Tooltip(message="增加一行"),
                                            style=ft.ButtonStyle(
                                                shape={
                                                    "": ft.RoundedRectangleBorder(
                                                        radius=8
                                                    )
                                                }
                                            ),
                                            on_click=lambda e, dt=self: add_row(
                                                dt,
                                                {
                                                    "product_name": "",
                                                    "sn_number": "",
                                                    "model": "",
                                                    "quantity": 0,
                                                    "description": "",
                                                },
                                            ),
                                        ),
                                        ft.IconButton(
                                            icon=ft.Icons.REMOVE_CIRCLE_OUTLINE_ROUNDED,
                                            icon_color=ft.Colors.RED,
                                            tooltip=ft.Tooltip(message="删除一行"),
                                            style=ft.ButtonStyle(
                                                shape={
                                                    "": ft.RoundedRectangleBorder(
                                                        radius=8
                                                    )
                                                }
                                            ),
                                            on_click=lambda e, dt=self, ri=idx - 1: remove_row(
                                                e, dt, ri
                                            ),
                                        ),
                                    ],
                                    spacing=5,
                                    expand=True,
                                ),
                                width=80,
                                alignment=ft.alignment.center,
                            )
                        ),
                    ]
                )
            )


def fetch_data():
    try:
        response = requests.get("http://127.0.0.1:8000/get_products/")
        response.raise_for_status()  # 检查请求是否成功
        logging.info("Successfully fetched data from server")
        return response.json()
    except requests.exceptions.RequestException as e:
        logging.error(f"Failed to fetch data from server: {e}")
        return []


async def main(page: ft.Page):
    page.title = "Product Table"
    page.adaptive = True
    data_table = CustomDataTable()
    page.add(
        ft.Column(
            scroll=ft.ScrollMode.ALWAYS,
            expand=True,
            controls=[ft.Row(controls=[data_table], scroll=ft.ScrollMode.ALWAYS)],
        ),
    )
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.update()

    # 使用 asyncio.create_task 添加异步任务
    asyncio.create_task(listen_to_server(data_table))


if __name__ == "__main__":
    ft.app(target=main, view=ft.WEB_BROWSER)
