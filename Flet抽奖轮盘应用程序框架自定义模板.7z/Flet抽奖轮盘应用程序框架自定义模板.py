import os
import flet as ft
import random
import time
from threading import Thread
import json

def main(page: ft.Page):
    page.title = "抽奖轮盘"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 50
    page.update()

    # 图片文件名列表
    image_paths = [
        'desktop computer.jpg',
        'smartphone2.jpg',
        'smartearbuds2.jpg',
        'laptop.jpg',
        'start.jpg',
        'smartband1.jpg',
        'smartband2.jpg',  
        'smartphone1.jpg',
        'smartphone3.jpg'
    ]

    # 人员列表
    participants = [
        "张三", "李四", "王五", "赵六", "孙七", "周八",
        "吴九", "郑十", "钱十一", "陈十二", "杨十三", "黄十四"
    ]

    # 获取当前工作目录
    current_dir = os.getcwd()

    # 定义统一的按钮宽度和高度
    button_width = 150
    button_height = 150

    # 图片宽度和高度各减少 40 像素（原减少 20 像素的基础上再减少 20 像素）
    image_width = button_width - 40
    image_height = button_height - 40

    # 加载本地图片
    image_buttons = []
    for idx, image_name in enumerate(image_paths):
        image_path = os.path.join(current_dir, image_name)  # 拼接成完整路径

        image_button = ft.ElevatedButton(
            content=ft.Image(
                src=image_path,  # 使用完整路径
                fit=ft.ImageFit.COVER,  # 使用 COVER 以填充满整个按钮
                repeat=ft.ImageRepeat.NO_REPEAT,
                border_radius=ft.border_radius.all(10),
                width=image_width,  # 设置图片宽度
                height=image_height  # 设置图片高度
            ),
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10),
                padding=0,  # 确保没有内边距
                overlay_color={
                    ft.ControlState.PRESSED: ft.Colors.BLUE,  # 按下时的颜色
                    ft.ControlState.HOVERED: ft.Colors.LIGHT_BLUE,  # 鼠标悬停时的颜色
                    ft.ControlState.DEFAULT: ft.Colors.TRANSPARENT  # 默认状态的颜色
                }
            ),
            width=button_width,  # 设置按钮宽度
            height=button_height,  # 设置按钮高度
            on_click=lambda e, name=image_name, idx=idx: start_lottery(e, name, idx),  # 添加点击事件
            data=idx  # 设置按钮的ID
        )
        image_buttons.append(image_button)

    # 使用 Column 和 Row 组件手动布局图片按钮
    rows = []
    for i in range(0, len(image_buttons), 3):
        row = ft.Row(
            controls=image_buttons[i:i+3],
            spacing=5,
            alignment=ft.MainAxisAlignment.CENTER
        )
        rows.append(row)

    column = ft.Column(
        controls=rows,
        spacing=5,
        alignment=ft.MainAxisAlignment.CENTER
    )

    # 将 Column 包裹在一个 Container 中，并设置边框
    grid_container = ft.Container(
        content=column,
        border=ft.border.all(2, ft.Colors.BLUE),  # 添加蓝色边框
        padding=10,  # 可选：添加内边距
        border_radius=ft.border_radius.all(10),  # 可选：添加圆角
        width=485,  # 增加宽度5
        height=500  # 手动设置高度，可以根据实际需要调整
    )

    # 创建一个新的 ListView 组件
    list_view = ft.ListView(
        expand=1,
        spacing=10,
        padding=10
    )

    # 初始显示信息
    initial_message = ft.Text("这里显示抽奖结果信息", size=18, color=ft.Colors.BLACK, weight=ft.FontWeight.BOLD)
    list_view.controls.append(initial_message)

    # 将 ListView 包裹在一个 Container 中，并设置边框
    list_container = ft.Container(
        content=list_view,
        border=ft.border.all(1, ft.Colors.BLUE),  # 修改为蓝色边框
        padding=10,  # 可选：添加内边距
        border_radius=ft.border_radius.all(10),  # 可选：添加圆角
        height=500,  # 设置与 grid_container 相同的高度
        expand=True  # 让容器扩展到最大宽度
    )

    # 使用 Row 组件水平排列两个容器
    row_container = ft.Row(
        controls=[
            grid_container,
            list_container
        ],
        alignment=ft.MainAxisAlignment.START,  # 左对齐
        vertical_alignment=ft.CrossAxisAlignment.START  # 顶部对齐
    )

    # 将 Row 包裹在一个 Container 中，并设置背景颜色
    container_with_row = ft.Container(
        content=row_container,
        bgcolor=ft.Colors.YELLOW  # 添加黄色背景色以便调试
    )

    page.add(container_with_row)
    page.update()

    last_winner_button = None  # 用于记录上一次的中奖按钮

    # 初始化抽奖数据
    data = load_data()
    current_round = len(data["rounds"]) + 1
    current_round_data = {
        "round": current_round,
        "draw_count": 0,
        "results": []
    }
    data["rounds"].append(current_round_data)
    save_data(data)

    def simulate_hover(buttons):
        nonlocal last_winner_button  # 使用外部变量

        # 计算额外等待时间，使得总时间在30秒到40秒之间
        extra_wait_time = random.uniform(20, 30)  # 随机生成20到30秒之间的额外等待时间

        for _ in range(10):  # 模拟10次悬停
            button = random.choice(buttons)
            # 模拟鼠标悬停
            button.style.bgcolor = ft.Colors.LIGHT_BLUE
            page.update()
            time.sleep(0.5)  # 暂停0.5秒

            # 模拟鼠标离开
            button.style.bgcolor = ft.Colors.TRANSPARENT
            page.update()
            time.sleep(0.5)  # 暂停0.5秒

        # 随机选择一个按钮作为中奖按钮
        winner_button = random.choice(buttons)
        winner_button.style.bgcolor = ft.Colors.LIGHT_BLUE
        page.update()

        # 随机选择一个中奖人员
        winner_name = random.choice(participants)

        # 显示中奖信息
        winner_image = os.path.basename(winner_button.content.src)  # 提取图片名称
        result_text = f"{winner_name} 中奖 {os.path.splitext(winner_image)[0]}"  # 修改为只显示图片名称
        list_view.controls.append(ft.Text(result_text, size=18, color=ft.Colors.RED))
        list_view.update()

        # 更新抽奖数据
        current_round_data["draw_count"] += 1
        current_round_data["results"].append(result_text)
        save_data(data)

        # 记录中奖按钮
        last_winner_button = winner_button

        # 增加额外的等待时间
        time.sleep(extra_wait_time)

    def start_lottery(e, image_name, idx):
        if idx == 4:  # 确保是第五个按钮
            # 取消上一次的中奖悬停
            if last_winner_button:
                last_winner_button.style.bgcolor = ft.Colors.TRANSPARENT
                page.update()

            # 检查当前轮次的抽奖次数
            if current_round_data["draw_count"] < 5:
                # 创建线程来模拟鼠标悬停和离开
                thread = Thread(target=simulate_hover, args=(image_buttons,))
                thread.start()
            else:
                # 抽奖次数已满，显示提示信息
                list_view.controls.append(ft.Text("本轮抽奖已结束", size=18, color=ft.Colors.RED))
                list_view.update()

    def reset_lottery(e):
        nonlocal current_round_data
        nonlocal current_round  # 声明 current_round 是外部作用域中的变量
        # 重置抽奖状态
        if last_winner_button:
            last_winner_button.style.bgcolor = ft.Colors.TRANSPARENT
            page.update()

        # 开始新的一轮
        current_round += 1
        current_round_data = {
            "round": current_round,
            "draw_count": 0,
            "results": []
        }
        data["rounds"].append(current_round_data)
        save_data(data)

        # 清空结果列表
        list_view.controls.clear()
        list_view.controls.append(initial_message)
        list_view.update()

    # 添加重置按钮
    reset_button = ft.ElevatedButton(
        text="重置抽奖",
        on_click=reset_lottery
    )

    # 将重置按钮添加到页面
    page.add(reset_button)
    page.update()

def load_data():
    try:
        with open('data.json', 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        return {"rounds": []}

def save_data(data):
    with open('data.json', 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)

ft.app(main)