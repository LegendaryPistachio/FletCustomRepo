import flet as ft

def main(page: ft.Page):
    page.title = "CustomFloating Action Button"
    page.horizontal_alignment = ft.CrossAxisAlignment.END  # 修改为右对齐
    page.auto_scroll = True
    page.scroll = ft.ScrollMode.HIDDEN
    page.appbar = ft.AppBar(
        title=ft.Text("CustomFloating Action Button", weight=ft.FontWeight.BOLD, color=ft.colors.BLACK87),
        actions=[ft.IconButton(ft.icons.MENU, tooltip="Menu", icon_color=ft.colors.BLACK87)],
        bgcolor=ft.colors.BLUE,
        center_title=True,
        color=ft.colors.WHITE,
    )

    # List to hold the action buttons
    action_buttons = [
        ft.Container(
            content=ft.IconButton(ft.icons.ADD, tooltip="Add"),
            margin=ft.margin.only(top=300, right=15),  # 右侧边距为15
            visible=False  # 初始时隐藏
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.REMOVE, tooltip="Remove"),
            margin=ft.margin.only(top=3, right=15),  # 右侧边距为15
            visible=False  # 初始时隐藏
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.SEARCH, tooltip="Search"),
            margin=ft.margin.only(top=3, right=15),  # 右侧边距为15
            visible=False  # 初始时隐藏
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.SETTINGS, tooltip="Settings"),
            margin=ft.margin.only(top=3, right=15),  # 右侧边距为15
            visible=False  # 初始时隐藏
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.INFO, tooltip="Info"),
            margin=ft.margin.only(top=3, right=15),  # 右侧边距为15
            visible=False  # 初始时隐藏
        )
    ]

    # Wrap the action buttons in a Column container with spacing
    action_buttons_column = ft.Column(
        controls=action_buttons,
        spacing=2  # 设置按钮之间的间距为2
    )

    # Add the column to the page
    page.add(action_buttons_column)

    # Function to handle the floating action button click event
    def on_fab_click(e):
        for button in action_buttons:
            button.visible = not button.visible  # 切换可见性
        page.update()  # 更新页面以反映更改

    # Add the floating action button
    page.floating_action_button = ft.FloatingActionButton(
        icon=ft.icons.ADD,
        bgcolor=ft.colors.LIME_300,
        on_click=on_fab_click  # 绑定点击事件
    )
    page.add()

# 调用 ft.app(main)
ft.app(main)