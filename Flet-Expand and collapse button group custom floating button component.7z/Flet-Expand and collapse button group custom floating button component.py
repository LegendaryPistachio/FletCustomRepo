import flet as ft

def main(page: ft.Page):
    page.title = "Custom Floating Action Button"
    page.horizontal_alignment = ft.CrossAxisAlignment.END  # Set to right alignment
    page.auto_scroll = True
    page.scroll = ft.ScrollMode.HIDDEN
    page.appbar = ft.AppBar(
        title=ft.Text("Custom Floating Action Button", weight=ft.FontWeight.BOLD, color=ft.colors.BLACK87),
        actions=[ft.IconButton(ft.icons.MENU, tooltip="Menu", icon_color=ft.colors.BLACK87)],
        bgcolor=ft.colors.BLUE,
        center_title=True,
        color=ft.colors.WHITE,
    )

    # List to hold the action buttons
    action_buttons = [
        ft.Container(
            content=ft.IconButton(ft.icons.ADD, tooltip="Add"),
            margin=ft.margin.only(top=300, right=15),  # Right margin is 15
            visible=False  # Initially hidden
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.REMOVE, tooltip="Remove"),
            margin=ft.margin.only(top=3, right=15),  # Right margin is 15
            visible=False  # Initially hidden
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.SEARCH, tooltip="Search"),
            margin=ft.margin.only(top=3, right=15),  # Right margin is 15
            visible=False  # Initially hidden
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.SETTINGS, tooltip="Settings"),
            margin=ft.margin.only(top=3, right=15),  # Right margin is 15
            visible=False  # Initially hidden
        ),
        ft.Container(
            content=ft.IconButton(ft.icons.INFO, tooltip="Info"),
            margin=ft.margin.only(top=3, right=15),  # Right margin is 15
            visible=False  # Initially hidden
        )
    ]

    # Wrap the action buttons in a Column container with spacing
    action_buttons_column = ft.Column(
        controls=action_buttons,
        spacing=2  # Set the spacing between buttons to 2
    )

    # Add the column to the page
    page.add(action_buttons_column)

    # Function to handle the floating action button click event
    def on_fab_click(e):
        for button in action_buttons:
            button.visible = not button.visible  # Toggle visibility
        page.update()  # Update the page to reflect changes

    # Add the floating action button
    page.floating_action_button = ft.FloatingActionButton(
        icon=ft.icons.ADD,
        bgcolor=ft.colors.LIME_300,
        on_click=on_fab_click  # Bind the click event
    )
    page.add()

# Call ft.app(main)
ft.app(main)