import flet as ft
import asyncio

# 图片列表
images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg",
    "image6.jpg",
    "image7.jpg",
]

# 自动轮播的间隔时间（秒）
AUTO_PLAY_INTERVAL = 3


async def auto_play(page):
    while page.state.get("auto_play", False):
        await asyncio.sleep(AUTO_PLAY_INTERVAL)
        current_index = page.state["image_index"]
        next_index = (current_index + 1) % len(images)
        page.state["image_index"] = next_index
        update_images(page)
        await page.update_async()


def next_image(event):
    page = event.control.page
    current_index = page.state["image_index"]
    next_index = (current_index + 1) % len(images)
    page.state["image_index"] = next_index
    update_images(page)
    page.update()


def prev_image(event):
    page = event.control.page
    current_index = page.state["image_index"]
    prev_index = (current_index - 1) % len(images)
    page.state["image_index"] = prev_index
    update_images(page)
    page.update()


def update_images(page):
    current_index = page.state["image_index"]
    print(f"Updating images with index {current_index}")
    page.controls[0].controls[1].src = images[current_index]  # 第一张图片
    page.controls[0].controls[2].src = images[
        (current_index + 1) % len(images)
    ]  # 第二张图片
    page.controls[0].controls[3].src = images[
        (current_index + 2) % len(images)
    ]  # 第三张图片


async def toggle_auto_play(event):
    page = event.control.page
    page.state["auto_play"] = not page.state.get("auto_play", False)

    # 如果开始自动播放，则启动协程
    if page.state["auto_play"]:
        if "auto_play_task" in page.state and page.state["auto_play_task"] is not None:
            page.state["auto_play_task"].cancel()
        page.state["auto_play_task"] = asyncio.create_task(auto_play(page))
    else:
        if "auto_play_task" in page.state and page.state["auto_play_task"] is not None:
            page.state["auto_play_task"].cancel()
            page.state["auto_play_task"] = None
    await page.update_async()


async def main(page: ft.Page):
    # 初始化页面状态
    page.state = {"image_index": 0, "auto_play": False}

    # 页面布局
    image_row = ft.Row(
        [
            ft.ElevatedButton("<", on_click=prev_image),
            ft.Image(src=images[0], width=300, height=200),
            ft.Image(src=images[1], width=300, height=200),
            ft.Image(src=images[2], width=300, height=200),
            ft.ElevatedButton(">", on_click=next_image),
            ft.ElevatedButton("Auto Play", on_click=toggle_auto_play),
        ],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        spacing=20,
    )

    page.add(image_row)

    # 如果需要默认开始自动轮播，可以取消下面这行的注释
    # page.state["auto_play"] = True
    # page.state["auto_play_task"] = asyncio.create_task(auto_play(page))


ft.app(target=main)
