import flet
from flet import (
    FilePicker,
    FilePickerFileType,
    Page,
    Row,
    Text,
    ElevatedButton,
    Icons,
)


def main(page: Page):
    page.title = "Flet File Picker File Type Enum Example Custom Template"
    page.horizontal_align = "stretch"
    page.vertical_align = "center"

    # Create file picker control
    file_picker = FilePicker()
    page.overlay.append(file_picker)
    page.update()

    # Text control to display selected files
    selected_files = Text()

    def handle_file_result(e):
        if e.files:
            # Filter file types
            allowed_extensions = [
                ".jpg",
                ".jpeg",
                ".png",
                ".gif",
                ".svg",
                ".mp4",
                ".mkv",
                ".mov",
                ".avi",
            ]
            valid_files = [
                f
                for f in e.files
                if any(f.path.lower().endswith(ext) for ext in allowed_extensions)
            ]
            if valid_files:
                # Display the path of the first selected file
                selected_files.value = valid_files[0].path
            else:
                selected_files.value = "No valid files selected"
        else:
            selected_files.value = "No files selected"
        page.update()

    # Bind result handling function to file picker
    file_picker.on_result = handle_file_result

    # Create Row control and add it to the page
    row = Row(
        controls=[
            # Example 1: Pick any file type
            ElevatedButton(
                "Pick Any File",
                icon=Icons.FILE_OPEN,
                on_click=lambda _: file_picker.pick_files(
                    allow_multiple=False,
                ),
            ),
            # Example 2: Pick images and videos
            ElevatedButton(
                "Pick Media Files",
                icon=Icons.IMAGE,
                on_click=lambda _: file_picker.pick_files(
                    file_type=FilePickerFileType.CUSTOM,
                    allowed_extensions=[
                        "jpg",
                        "jpeg",
                        "png",
                        "gif",
                        "svg",
                        "mp4",
                        "mkv",
                        "mov",
                        "avi",
                    ],
                    allow_multiple=True,
                ),
            ),
            # Example 3: Custom file types (PDF and text files)
            ElevatedButton(
                "Pick Documents",
                icon=Icons.DESCRIPTION,
                on_click=lambda _: file_picker.pick_files(
                    file_type=FilePickerFileType.CUSTOM,
                    allowed_extensions=["pdf", "txt", "docx", "doc"],
                    allow_multiple=True,
                ),
            ),
            selected_files,  # Display selection result
        ],
        alignment="center",
    )

    # Add Row control to the page's controls list
    page.controls.append(row)
    page.update()


flet.app(target=main)
