import flet as ft


class State:
    toggle = True


s = State()


def main(page: ft.Page):
    # 模拟数据：语文、数学、英语成绩
    chinese_scores = [
        ft.LineChartDataPoint(1, 85),
        ft.LineChartDataPoint(2, 90),
        ft.LineChartDataPoint(3, 88),
        ft.LineChartDataPoint(4, 92),
        ft.LineChartDataPoint(5, 87),
    ]
    math_scores = [
        ft.LineChartDataPoint(1, 92),
        ft.LineChartDataPoint(2, 88),
        ft.LineChartDataPoint(3, 95),
        ft.LineChartDataPoint(4, 90),
        ft.LineChartDataPoint(5, 93),
    ]
    english_scores = [
        ft.LineChartDataPoint(1, 88),
        ft.LineChartDataPoint(2, 91),
        ft.LineChartDataPoint(3, 89),
        ft.LineChartDataPoint(4, 94),
        ft.LineChartDataPoint(5, 90),
    ]

    data_1 = [
        ft.LineChartData(
            data_points=chinese_scores,
            stroke_width=8,
            color=ft.Colors.LIGHT_GREEN,
            curved=True,
            stroke_cap_round=True,
        ),
        ft.LineChartData(
            data_points=math_scores,
            color=ft.Colors.PINK,
            below_line_bgcolor=ft.Colors.with_opacity(0, ft.Colors.PINK),
            stroke_width=8,
            curved=True,
            stroke_cap_round=True,
        ),
        ft.LineChartData(
            data_points=english_scores,
            color=ft.Colors.CYAN,
            stroke_width=8,
            curved=True,
            stroke_cap_round=True,
        ),
    ]

    # 可以根据需要添加更多的数据集，这里仅使用一个数据集
    data_2 = data_1

    chart = ft.LineChart(
        data_series=data_1,
        border=ft.Border(
            bottom=ft.BorderSide(4, ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE))
        ),
        left_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(
                    value=80,
                    label=ft.Text("80", size=14, weight=ft.FontWeight.BOLD),
                ),
                ft.ChartAxisLabel(
                    value=85,
                    label=ft.Text("85", size=14, weight=ft.FontWeight.BOLD),
                ),
                ft.ChartAxisLabel(
                    value=90,
                    label=ft.Text("90", size=14, weight=ft.FontWeight.BOLD),
                ),
                ft.ChartAxisLabel(
                    value=95,
                    label=ft.Text("95", size=14, weight=ft.FontWeight.BOLD),
                ),
            ],
            labels_size=40,
        ),
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(
                    value=1,
                    label=ft.Container(
                        ft.Text(
                            "期中",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
                ft.ChartAxisLabel(
                    value=2,
                    label=ft.Container(
                        ft.Text(
                            "期末",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
                ft.ChartAxisLabel(
                    value=3,
                    label=ft.Container(
                        ft.Text(
                            "期中",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
                ft.ChartAxisLabel(
                    value=4,
                    label=ft.Container(
                        ft.Text(
                            "期末",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
                ft.ChartAxisLabel(
                    value=5,
                    label=ft.Container(
                        ft.Text(
                            "期中",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                        ),
                        margin=ft.margin.only(top=10),
                    ),
                ),
            ],
            labels_size=32,
        ),
        tooltip_bgcolor=ft.Colors.with_opacity(0.8, ft.Colors.BLUE_GREY),
        min_y=80,
        max_y=100,
        min_x=0,
        max_x=6,
        # animate=5000,
        expand=True,
    )

    def toggle_data(e):
        if s.toggle:
            chart.data_series = data_2
            chart.max_y = 100
            chart.interactive = False
        else:
            chart.data_series = data_1
            chart.max_y = 100
            chart.interactive = True
        s.toggle = not s.toggle
        chart.update()

    # 添加标题
    title = ft.Text("各学科成绩变化趋势", size=24, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER)

    # 添加图例
    legend = ft.Row(
        [
            ft.Container(
                content=ft.Text("语文", size=16, text_align=ft.TextAlign.CENTER),
                width=100,
                height=30,
                bgcolor=ft.Colors.LIGHT_GREEN,
                border_radius=5,
                margin=ft.margin.symmetric(horizontal=5),
            ),
            ft.Container(
                content=ft.Text("数学", size=16, text_align=ft.TextAlign.CENTER),
                width=100,
                height=30,
                bgcolor=ft.Colors.PINK,
                border_radius=5,
                margin=ft.margin.symmetric(horizontal=5),
            ),
            ft.Container(
                content=ft.Text("英语", size=16, text_align=ft.TextAlign.CENTER),
                width=100,
                height=30,
                bgcolor=ft.Colors.CYAN,
                border_radius=5,
                margin=ft.margin.symmetric(horizontal=5),
            ),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
    )

    # 使用 Column 来垂直排列标题、图表和图例，并使标题居中
    page.add(
        ft.Column(
            [
                ft.Container(
                    content=title,
                    alignment=ft.alignment.center,
                    margin=ft.margin.only(bottom=20),
                ),
                chart,
                ft.Container(
                    content=legend,
                    alignment=ft.alignment.center,
                    margin=ft.margin.only(top=20),
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            expand=True,
        ),
        ft.IconButton(ft.Icons.REFRESH, on_click=toggle_data),
    )


ft.app(main)