import flet as ft
import requests as re
import json

# Define the VE variable
VE = "1.0.0"  # Set the version number according to your actual situation


# Define the LINK_URL constant
class LINK_URL:
    About_Url = "https://example.com/api/about"  # Replace with the actual URL


class MyApp(ft.Container):  # Inherit from ft.Container
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.msg = ft.Text(value="", color="green")
        self.button = ft.ElevatedButton(
            text="About",
            on_click=self.pro_about,
            data={"url": LINK_URL.About_Url, "pwd": "your_password_here"},
        )
        self.download_button = ft.ElevatedButton(
            text="Download",
            on_click=self.download_pro,
            data={"download_url": "https://example.com/file.zip"},
        )
        self.content = ft.Column([self.button, self.download_button, self.msg])

    def pro_about(self, e):
        url = e.control.data["url"]
        pwd = e.control.data["pwd"]
        self.page.launch_url(url)
        self.page.set_clipboard(pwd)
        self.msg.value = "Password copied"
        self.msg.update()

        try:
            response = re.get(LINK_URL.About_Url)
            if 200 <= response.status_code < 300:
                ret = response.text
                info_list = json.loads(ret.replace("'", '"'))
            else:
                # If the server response is not in the 200-300 range, use default information
                info_list = {
                    "code": 0,
                    "msg": "success!",
                    "newversion": 0,
                    "latest": VE,
                }
        except Exception as e:
            print("main.py-error", e)
            # If an error occurs, set the image URL to local
            info_list = {
                "code": -1,
                "msg": "Server error",
                "newversion": 0,
                "latest": "local",
            }

        # Process info_list, assuming you need to display some information on the interface
        self.msg.value = (
            f"Status code: {info_list['code']}, Message: {info_list['msg']}"
        )
        self.msg.update()

    def download_pro(self, e):
        download_url = e.control.data[
            "download_url"
        ]  # Assume the event object contains the download URL
        save_path = "downloaded_file.ext"  # Set the save path and filename

        try:
            response = re.get(download_url, stream=True)
            if response.status_code == 200:
                with open(save_path, "wb") as file:
                    for chunk in response.iter_content(chunk_size=8192):
                        file.write(chunk)
                self.msg.value = (
                    f"File successfully downloaded and saved to {save_path}"
                )
            else:
                self.msg.value = f"Download failed, status code: {response.status_code}"
        except Exception as e:
            print("download_pro-error", e)
            self.msg.value = f"An error occurred during download: {str(e)}"

        self.msg.update()


def main(page: ft.Page):
    page.title = "MyApp"
    app = MyApp(page)
    page.add(app)


ft.app(target=main)
