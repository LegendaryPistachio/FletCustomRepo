import flet as ft


def main(page: ft.Page):
    page.title = (
        "Flet-AnimationStyle with Four Properties Application Example Custom Template"
    )
    # Create an animation object, set the forward curve and duration
    animation = ft.Animation(
        duration=2000,  # Forward animation duration
        curve=ft.AnimationCurve.EASE_IN_OUT,  # Forward animation curve
    )

    reverse_animation = ft.Animation(
        duration=1000,  # Reverse animation duration
        curve=ft.AnimationCurve.BOUNCE_OUT,  # Reverse animation curve
    )

    container = ft.Container(
        width=200,
        height=200,
        bgcolor=ft.Colors.BLUE,
        animate=animation,  # Use the defined animation object
        on_click=lambda e: toggle_animation(e),
    )
    page.add(container)

    def toggle_animation(e):
        if e.control.width == 200:
            e.control.width = 300
            e.control.bgcolor = ft.Colors.GREEN
            e.control.animate = animation
        else:
            e.control.width = 200
            e.control.bgcolor = ft.Colors.BLUE
            e.control.animate = reverse_animation
        e.control.update()

    page.update()


ft.app(target=main)
