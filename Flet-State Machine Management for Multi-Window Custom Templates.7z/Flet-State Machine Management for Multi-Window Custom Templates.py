import flet as ft
from enum import Enum, auto
from dataclasses import dataclass


class AppState(Enum):
    MAIN = auto()
    WINDOW1 = auto()
    WINDOW2 = auto()
    WINDOW3 = auto()


@dataclass
class StateTransition:
    current_state: AppState
    next_state: AppState
    action: callable = None


class StateMachineApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.current_state = AppState.MAIN
        self.setup_ui()

    def setup_ui(self):
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.title = "Flet State Machine Multi-Window Custom Template"

        # Main container
        self.main_container = ft.Container(
            width=700,
            height=400,
            bgcolor=ft.Colors.WHITE,  # Use ft.Colors instead of ft.colors
            border_radius=10,
            padding=20,
            content=self.create_main_view(),
        )

        self.page.add(self.main_container)

    def create_main_view(self):
        return ft.Column(
            [
                ft.Text("Main Window", size=20, weight=ft.FontWeight.BOLD),
                ft.ElevatedButton(
                    "Open Window 1",
                    on_click=lambda e: self.transition_to(AppState.WINDOW1),
                ),
                ft.ElevatedButton(
                    "Open Window 2",
                    on_click=lambda e: self.transition_to(AppState.WINDOW2),
                ),
                ft.ElevatedButton(
                    "Open Window 3",
                    on_click=lambda e: self.transition_to(AppState.WINDOW3),
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )

    def create_window1_view(self):
        return ft.Column(
            [
                ft.Text("Window 1", size=20, weight=ft.FontWeight.BOLD),
                ft.Text("This is the content of Window 1"),
                ft.ElevatedButton(
                    "Return to Main Window",
                    on_click=lambda e: self.transition_to(AppState.MAIN),
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )

    def create_window2_view(self):
        return ft.Column(
            [
                ft.Text("Window 2", size=20, weight=ft.FontWeight.BOLD),
                ft.Text("This is the content of Window 2"),
                ft.ElevatedButton(
                    "Return to Main Window",
                    on_click=lambda e: self.transition_to(AppState.MAIN),
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )

    def create_window3_view(self):
        return ft.Column(
            [
                ft.Text("Window 3", size=20, weight=ft.FontWeight.BOLD),
                ft.Text("This is the content of Window 3"),
                ft.ElevatedButton(
                    "Return to Main Window",
                    on_click=lambda e: self.transition_to(AppState.MAIN),
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )

    def transition_to(self, next_state):
        # State transition logic
        self.current_state = next_state
        self.update_view()

    def update_view(self):
        # Update view based on current state
        if self.current_state == AppState.MAIN:
            self.main_container.content = self.create_main_view()
        elif self.current_state == AppState.WINDOW1:
            self.main_container.content = self.create_window1_view()
        elif self.current_state == AppState.WINDOW2:
            self.main_container.content = self.create_window2_view()
        elif self.current_state == AppState.WINDOW3:
            self.main_container.content = self.create_window3_view()

        self.page.update()


def main(page: ft.Page):
    page.window.width = 800
    page.window.height = 500
    page.window.resizable = False
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    StateMachineApp(page)
    page.update()


ft.app(target=main)
