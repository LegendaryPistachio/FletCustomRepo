import flet as ft


def main(page: ft.Page):
    # Hide the title bar and buttons
    page.window.title_bar_hidden = True
    page.window.title_bar_buttons_hidden = True

    # Set window background transparency
    page.bgcolor = ft.Colors.TRANSPARENT
    page.window.bgcolor = ft.Colors.TRANSPARENT  # Entire window background transparent
    page.window.opacity = 1.0  # Entire window opaque

    # Remove extra padding settings
    page.padding = 0

    # Set fixed window size
    window_width = 471
    window_height = 507
    page.window.width = window_width
    page.window.height = window_height

    def close_window(e):
        print("Close button clicked")  # Debug output
        e.page.window.close()  # Close window

    # Create a close button
    close_button = ft.IconButton(
        icon=ft.Icons.CLOSE,
        on_click=close_window,  # Bind event handler function
        bgcolor=ft.Colors.RED,  # Change background color to red
        style=ft.ButtonStyle(shape=ft.CircleBorder()),
        icon_color=ft.Colors.BLACK,
        icon_size=26,
        tooltip="Close",
        top=10,
        left=200,
    )

    # Create an image component and set fill mode
    image = ft.Image(
        src="shj.png",  # Ensure path is correct
        width=window_width,
        height=window_height,
        fit=ft.ImageFit.COVER,  # Fill entire container
    )

    # Create a stack layout
    stack = ft.Stack(
        controls=[
            image,
            close_button,  # Place close button above the image
        ],
        width=window_width,
        height=window_height,
        expand=True,  # Expand to fill parent container
    )

    # Create a drag area
    drag_area = ft.WindowDragArea(
        content=stack,
        width=window_width,
        height=window_height,
        expand=True,  # Expand to fill parent container
    )

    # Add drag area to page
    page.add(drag_area)

    # Prevent window from being resized
    page.window.resizable = False


ft.app(target=main)
