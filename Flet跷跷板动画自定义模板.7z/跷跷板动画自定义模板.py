import flet as ft
import time

def main(page: ft.Page):
    page.title = "心形跷跷板动画"
    
    # 创建一个 Stack 控件
    stack = ft.Stack()

    # 创建两个心形图标，大小缩小一半
    heart1 = ft.Icon(ft.icons.FAVORITE, size=50, color=ft.colors.RED)  # 原来是100
    heart2 = ft.Icon(ft.icons.FAVORITE, size=50, color=ft.colors.RED)  # 原来是100

    # 设置心形图标的初始位置
    heart1.left = 50  # 心1在左侧
    heart1.top = 100
    heart2.left = 150  # 心2在右侧
    heart2.top = 100

    # 将心形图标添加到 Stack 控件
    stack.controls.append(heart1)
    stack.controls.append(heart2)

    # 将 Stack 控件添加到页面
    page.add(stack)

    # 动画循环
    while True:
        for i in range(20):
            heart1.top -= 2  # 心1上升
            heart2.top += 2  # 心2下降
            page.update()
            time.sleep(0.05)

        for i in range(20):
            heart1.top += 2  # 心1下降
            heart2.top -= 2  # 心2上升
            page.update()
            time.sleep(0.05)

ft.app(target=main)