import flet as ft


def main(page: ft.Page):
    page.title = "Flet Set Elevation Attribute to Achieve Shadow-Free Flat Effect with Custom Templates"
    # Create an ElevatedButton with no shadow
    no_shadow_button = ft.ElevatedButton(
        text="ElevatedButton without Shadow", elevation=0
    )

    # Create an OutlinedButton with no shadow
    no_shadow_outlined_button = ft.OutlinedButton(text="Outlined Button without Shadow")

    # Create a FilledButton with no shadow
    no_shadow_filled_button = ft.FilledButton(text="Filled Button without Shadow")

    # Create a Card with no shadow
    card = ft.Card(
        content=ft.Container(
            content=ft.Text("Card without Shadow"),
            padding=10,
            alignment=ft.alignment.center,
        ),
        elevation=0,
    )

    # Create a FloatingActionButton with no shadow
    fab = ft.FloatingActionButton(icon=ft.Icons.ADD, elevation=0)

    # Create an AppBar with no shadow
    app_bar = ft.AppBar(
        title=ft.Text("App Bar without Shadow"), center_title=True, elevation=0
    )
    page.appbar = app_bar

    # Add all controls to the page
    page.add(
        no_shadow_button, no_shadow_outlined_button, no_shadow_filled_button, card, fab
    )


ft.app(target=main)
