import flet as ft

def main(page: ft.Page):
    page.theme = ft.Theme(font_family="Arial")
    page.title = "Flet Circular Avatar with Adaptive Badge and Global Font Settings Custom Template"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # Create a circular avatar
    avatar = ft.Container(
        width=100,
        height=100,
        border_radius=50,  # Circular
        bgcolor=ft.Colors.BLUE,  # Avatar background color
        content=ft.Image(
            src="https://avatars.githubusercontent.com/u/5041459?s=88&v=4",
            width=100,
            height=100,
            fit=ft.ImageFit.COVER,  # Ensure the image covers the entire container
            border_radius=50,  # Circular
        ),
    )

    # Create an adaptive text badge
    badge = ft.Container(
        width=80,  # Set badge width
        height=20,  # Set badge height
        padding=ft.padding.symmetric(horizontal=0, vertical=0),  # Badge padding
        border_radius=10,  # Rounded rectangle
        bgcolor=ft.Colors.GREEN,  # Badge background color
        alignment=ft.alignment.top_center,  # Badge alignment
        offset=ft.Offset(1.0, 0.5),  # Badge offset
        content=ft.Text("User Online", color=ft.Colors.WHITE, size=12),  # Badge content
    )

    # Combine avatar and badge
    avatar_with_badge = ft.Stack(
        [
            avatar,
            badge,
        ],
        width=100,
        height=100,
    )

    # Add the combined control to the page
    page.add(avatar_with_badge)

ft.app(target=main)