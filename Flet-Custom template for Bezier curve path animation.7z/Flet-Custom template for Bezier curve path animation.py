import flet as ft
import asyncio

def main(page: ft.Page):
    # Initial shopping cart icon (colored)
    cart_icon_colored = ft.Icon(name=ft.icons.SHOPPING_CART, size=40, color=ft.colors.AMBER)
    # Product icon (colored)
    product_icon_colored = ft.Icon(name=ft.icons.SHOPPING_BAG, size=40, color=ft.colors.PINK)

    # Create shopping cart container
    cart_container = ft.Container(
        content=cart_icon_colored,
        width=50,
        height=50,
        alignment=ft.alignment.center,
        left=20,
        top=300,  # Shopping cart position remains unchanged
    )

    # Create product container
    product_container = ft.Container(
        content=product_icon_colored,
        width=50,
        height=50,
        alignment=ft.alignment.center,
        left=150,
        top=50,
    )

    # Bézier curve function
    def bezier_curve(t, p0, p1, p2):
        return (1 - t)**2 * p0 + 2 * (1 - t) * t * p1 + t**2 * p2

    # Animation function
    async def animate_product(e):
        duration = 3  # Animation duration (seconds)
        steps = 100  # Number of animation steps
        trail_points = []
        for i in range(steps + 1):
            t = i / steps
            x = bezier_curve(t, 150, 200, 20)
            y = bezier_curve(t, 50, 200, 300)
            trail_points.append((x, y))
        for i in range(steps + 1):
            t = i / steps
            x = trail_points[i][0]
            y = trail_points[i][1]
            product_container.left = x
            product_container.top = y
            if i == steps:  # When the product reaches the shopping cart
                product_container.content.size = 25  # Shrink to 25 pixels
                product_container.top = cart_container.top - 10  # Move up 3 pixels
            page.update()
            await asyncio.sleep(duration / steps)
        # Change the shopping cart icon to a colored icon
        cart_container.content = ft.Icon(name=ft.icons.SHOPPING_CART_OUTLINED, size=40, color=ft.colors.GREEN)
        cart_container.update()

    # Add to the page
    page.add(
        ft.Stack(
            [product_container, cart_container],
            width=400,
            height=400,
        ),
        ft.ElevatedButton("Add product to cart", on_click=animate_product),  # Button text in Chinese
    )

ft.app(target=main)