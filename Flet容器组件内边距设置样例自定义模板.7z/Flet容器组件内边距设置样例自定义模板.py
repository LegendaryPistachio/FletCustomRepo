import flet as ft


def create_custom_container(
    inner_width,
    inner_height,
    outer_width,
    outer_height,
    padding,
    text,
    inner_alignment=ft.alignment.center,
    outer_alignment=ft.alignment.center,
):
    inner_container = ft.Container(
        width=inner_width,
        height=inner_height,
        bgcolor=ft.Colors.YELLOW_100,
        border=ft.border.all(1, ft.Colors.BLACK12),
        content=ft.Text(text, color=ft.Colors.BLACK, size=16),
        alignment=inner_alignment,
    )

    outer_container = ft.Container(
        width=outer_width,
        height=outer_height,
        bgcolor=ft.Colors.GREEN_100,
        border=ft.border.all(1, ft.Colors.BLACK12),
        content=inner_container,
        alignment=outer_alignment,
        padding=padding,
    )
    return outer_container


def main(page: ft.Page):
    page.title = "Flet容器组件内边距设置样例自定义模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # 创建四个不同的容器
    container_1 = create_custom_container(
        inner_width=180,
        inner_height=180,
        outer_width=200,
        outer_height=200,
        padding=ft.padding.all(10),
        text="容器组件内边距设置1",
    )

    container_2 = create_custom_container(
        inner_width=110,
        inner_height=110,
        outer_width=200,
        outer_height=200,
        padding=ft.padding.all(20),
        text="容器组件内边距设置2",
    )

    container_3 = create_custom_container(
        inner_width=200,
        inner_height=100,
        outer_width=200,
        outer_height=200,
        padding=ft.padding.symmetric(horizontal=0),
        text="容器组件内边距设置3",
    )

    container_4 = create_custom_container(
        inner_width=200,
        inner_height=200,
        outer_width=200,
        outer_height=200,
        padding=ft.padding.only(left=10),
        text="容器组件内边距设置4",
        inner_alignment=ft.alignment.center_right,
    )

    row_container = ft.Row(
        [
            container_1,
            container_2,
            container_3,
            container_4,
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=0,  # 设置间距为0
    )

    page.add(row_container)


ft.app(target=main)
