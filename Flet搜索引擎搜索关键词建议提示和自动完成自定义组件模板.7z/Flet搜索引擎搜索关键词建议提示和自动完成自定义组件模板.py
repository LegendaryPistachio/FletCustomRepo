import flet as ft


def main(page: ft.Page):
    page.title = "Flet搜索引擎搜索关键词建议提示和自动完成自定义组件模板"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    # 示例数据集
    data = ["apple", "banana", "cherry", "date", "elderberry", "fig", "grape"]

    # 用于显示建议的列表视图
    suggestions_list = ft.ListView(expand=1, spacing=10, padding=20)

    # 输入框
    input_field = ft.TextField(
        hint_text="开始输入...",
        prefix_icon=ft.icons.SEARCH,  # 添加搜索图标
        on_change=lambda e: update_suggestions(e, suggestions_list, data),
    )

    # 更新建议列表的函数
    def update_suggestions(e, suggestions_list, data):
        suggestions_list.controls.clear()
        query = e.control.value.lower()
        if query:
            for item in data:
                if query in item.lower():
                    suggestions_list.controls.append(
                        ft.TextButton(
                            text=item,
                            on_click=lambda e, val=item: select_suggestion(
                                e, val, input_field
                            ),
                        )
                    )
        suggestions_list.update()

    # 选择建议的函数
    def select_suggestion(e, val, input_field):
        input_field.value = val
        input_field.update()
        suggestions_list.controls.clear()
        suggestions_list.update()

    # 将输入框和建议列表添加到页面
    page.add(
        ft.Column(
            [input_field, suggestions_list],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.START,
        )
    )


ft.app(target=main)
