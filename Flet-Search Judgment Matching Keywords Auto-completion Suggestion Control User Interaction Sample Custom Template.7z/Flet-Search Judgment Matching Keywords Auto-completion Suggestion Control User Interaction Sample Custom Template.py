import flet as ft

def update_suggestions(page, text):
    # Update suggestion list based on user input
    suggestions = [
        ft.AutoCompleteSuggestion(key=f"{value} {i}", value=value)
        for i, value in enumerate(
            [
                "One",
                "Two",
                "Three",
                "Four",
                "Five",
                "Six",
                "Seven",
                "Eight",
                "Nine",
                "Ten",
            ]
        )
        if value.lower().startswith(text.lower())
    ]
    page.auto_complete.suggestions = suggestions

    if not suggestions:
        page.selected_text.value = "No matching suggestions"
    else:
        page.selected_text.value = "Please select a suggestion"

    page.update()

def on_select(e, page):
    # Update text component to display selected suggestion
    page.selected_text.value = f"You selected: {e.selection}"
    page.update()

def main(page: ft.Page):
    page.title = "Flet Search and Keyword Matching Suggestions Control User Interaction Sample Custom Template"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 20

    # Create text input field
    input_field = ft.TextField(
        hint_text="Enter keyword",
        on_change=lambda e: update_suggestions(
            page, e.control.value
        ),  # Use on_change to handle input changes
        border_radius=5,
        border_color=ft.Colors.BLUE_500,
        focused_border_color=ft.Colors.BLUE_700,
        content_padding=ft.padding.all(10),
        prefix_icon=ft.Icons.SEARCH,
        width=300,
    )

    # Create auto-complete component
    page.auto_complete = ft.AutoComplete(
        suggestions=[], on_select=lambda e: on_select(e, page)
    )

    # Create text component to display selected suggestion
    page.selected_text = ft.Text(
        value="Please select a suggestion", size=16, color=ft.Colors.BLACK
    )

    # Add components to the page
    page.add(
        ft.Column(
            [
                input_field,
                page.auto_complete,
                page.selected_text,
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        )
    )

ft.app(target=main)