import flet as ft
from multiprocessing import Process


def start_second_window_1():
    def second_window_1(page: ft.Page):
        page.title = "Sub Window 1"
        page.window.always_on_top = True  # Set the window to always be on top
        page.add(ft.Text("I am Sub Window 1"))
        page.update()  # Update the page to apply the always_on_top setting

    ft.app(target=second_window_1)


def start_second_window_2():
    def second_window_2(page: ft.Page):
        page.title = "Sub Window 2"
        page.window.always_on_top = True  # Set the window to always be on top
        page.add(ft.Text("I am Sub Window 2"))
        page.update()  # Update the page to apply the always_on_top setting

    ft.app(target=second_window_2)


def start_second_window_3():
    def second_window_3(page: ft.Page):
        page.title = "Sub Window 3"
        page.window.always_on_top = True  # Set the window to always be on top
        page.add(ft.Text("I am Sub Window 3"))
        page.update()  # Update the page to apply the always_on_top setting

    ft.app(target=second_window_3)


def open_second_window_1(e):
    Process(target=start_second_window_1, daemon=True).start()


def open_second_window_2(e):
    Process(target=start_second_window_2, daemon=True).start()


def open_second_window_3(e):
    Process(target=start_second_window_3, daemon=True).start()


def main_window(page: ft.Page):
    page.title = "Main Window - Flet-A Custom template for multi-process independent window interaction in a single file"
    page.add(
        ft.ElevatedButton("Start Sub Window 1", on_click=open_second_window_1),
        ft.ElevatedButton("Start Sub Window 2", on_click=open_second_window_2),
        ft.ElevatedButton("Start Sub Window 3", on_click=open_second_window_3),
    )


if __name__ == "__main__":
    ft.app(target=main_window)
