import flet as ft
import os

def main(page: ft.Page):
    # Set page title
    page.title = "Local Image Waterfall Flow"
    
    # Image folder path
    image_folder = "images"
    
    # Get image file list
    images = [os.path.join(image_folder, f"{i}.jpg") for i in range(1, 10)]
    
    # Calculate number of images per column
    num_columns = 3
    num_images_per_column = len(images) // num_columns
    
    # Create image control list
    columns = []
    for i in range(num_columns):
        start_index = i * num_images_per_column
        end_index = (i + 1) * num_images_per_column if i < num_columns - 1 else len(images)
        column_images = images[start_index:end_index]
        
        # Create image controls for each column
        column_controls = [ft.Image(src=img, width=200, fit=ft.ImageFit.COVER) for img in column_images]
        
        # Create Column control
        column = ft.Column(controls=column_controls, spacing=10)
        
        # Add to column list
        columns.append(column)
    
    # Arrange columns horizontally using Row control
    row = ft.Row(controls=columns, spacing=10)
    
    # Wrap Row control with Column control and add vertical scrollbar
    scroll_column = ft.Column(
        controls=[row],
        scroll=ft.ScrollMode.AUTO,  # Enable vertical scrolling
        expand=True  # Make Column control occupy all available space
    )
    
    # Add to page
    page.add(scroll_column)

# Run application
ft.app(target=main)