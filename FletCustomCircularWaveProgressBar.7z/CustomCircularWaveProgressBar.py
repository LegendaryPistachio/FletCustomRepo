import flet as ft

def main(page: ft.Page):
    page.title = "Circular Wave Progress Bar"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    wave_color = ft.colors.LIGHT_BLUE

    large_wave = ft.Container(
        width=200,  # Adjust to the same width as the container
        height=200,  # Adjust to the same height as the container
        bgcolor=wave_color,
        border_radius=100,  # Adjust to the same radius as the container
        offset=ft.Offset(-0.20, 0.95),  # Initial position
        animate_offset=ft.Animation(500, "easeInOut"),
    )

    small_wave = ft.Container(
        width=3040,  # Keep the larger width
        height=3040,  # Keep the larger height
        bgcolor=wave_color,
        border_radius=1520,  # Keep the larger radius
        offset=ft.Offset(0.30, 1.05),  # Initial position
        animate_offset=ft.Animation(500, "easeInOut"),
    )

    text = ft.Text(
        "0%",
        size=30,
        weight=ft.FontWeight.BOLD,
        color=ft.colors.WHITE,
    )

    container = ft.Container(
        width=200,  # Keep unchanged
        height=200,  # Keep unchanged
        border_radius=100,  # Keep unchanged
        bgcolor=ft.colors.GREY_200,
        border=ft.Border(
            left=ft.BorderSide(5, wave_color),
            top=ft.BorderSide(5, wave_color),
            right=ft.BorderSide(5, wave_color),
            bottom=ft.BorderSide(5, wave_color),
        ),
        alignment=ft.alignment.center,
        clip_behavior=ft.ClipBehavior.HARD_EDGE,  # Restrict the waves within the circle
        content=ft.Stack(
            [
                large_wave,
                small_wave,
                ft.Container(
                    content=text,
                    alignment=ft.alignment.center
                ),
            ]
        ),
    )

    def update_wave(value):
        # Update wave positions
        x_offset_adjustment = 0.2 * (value / 100)  # Move 200 units to the right at 100%
        y_offset_adjustment = 0.050 * (value / 100)  # Move 5.0 units down at 100%
        large_wave.offset = ft.Offset(-0.20 + x_offset_adjustment, 0.95 - value / 100 + y_offset_adjustment)
        small_wave.offset = ft.Offset(0.30 + x_offset_adjustment, 1.05 - value / 100 * 1.2 + y_offset_adjustment)
        text.value = f"{int(value)}%"
        page.update()

    slider = ft.Slider(
        min=0,
        max=100,
        value=0,
        on_change=lambda e: update_wave(e.control.value),
    )

    page.add(container, slider)

ft.app(target=main)