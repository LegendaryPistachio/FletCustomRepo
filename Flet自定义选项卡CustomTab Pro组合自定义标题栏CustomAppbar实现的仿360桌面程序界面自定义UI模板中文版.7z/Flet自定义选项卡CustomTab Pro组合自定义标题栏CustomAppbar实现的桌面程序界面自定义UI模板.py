
 
import flet as ft
 
class CustomTab:
    def __init__(self, text, icon_path, on_click=None):
        self.text = text
        self.icon_path = icon_path
        self.on_click = on_click
        self.container = None
 
    def build(self):
        self.container = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[ft.Image(src=self.icon_path, width=64, height=64)],
                        alignment=ft.MainAxisAlignment.CENTER
                    ),
                    ft.Row(
                        controls=[ft.Text(self.text, color=ft.colors.WHITE, size=16)],
                        alignment=ft.MainAxisAlignment.CENTER
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=5
            ),
            bgcolor=ft.colors.GREEN_500,
            height=200,
            width=200,
            on_click=self.on_click,
            ink=True  # 确保具有墨水效果
        )
        return self.container
 
def create_tab(text, icon_path, on_click):
    return CustomTab(text=text, icon_path=icon_path, on_click=on_click).build()
 
def main(page: ft.Page):
    # 设置窗口的初始大小和样式
    page.window.width = 1220
    page.window.height = 800
    page.window.frameless = True
    page.window.resizable = False
 
    current_tab = None
    content_container = ft.Column()
 
    tab_contents = {
        "我的选购": ft.Text("这是我的选购页面", bgcolor=ft.colors.RED),
        "清单详情": ft.Text("这是清单详情页面", bgcolor=ft.colors.ORANGE),
        "添加商品": ft.Text("这是添加商品页面", bgcolor=ft.colors.GREEN),
        "保存商品": ft.Text("这是保存商品页面", bgcolor=ft.colors.BLUE),
        "删除商品": ft.Text("这是删除商品页面", bgcolor=ft.colors.PURPLE),
        "联系我们": ft.Text("这是联系我们页面", bgcolor=ft.colors.YELLOW),
    }
 
    def tab_clicked(e):
        nonlocal current_tab
        tab_text = e.control.content.controls[1].controls[0].value
        print(f"{tab_text} tab clicked")
 
        if current_tab:
            current_tab.bgcolor = ft.colors.GREEN_500
        
        current_tab = e.control
        current_tab.bgcolor = ft.colors.GREEN_400
        page.update()
 
        content_container.clean()
        content_container.controls.append(tab_contents[tab_text])
        page.update()
 
    # 创建顶部标题栏
    def create_app_title():
        app_title_row = ft.Row(
            controls=[
                ft.IconButton(ft.icons.SHOPPING_CART, tooltip="购物车", icon_color=ft.colors.WHITE),
                ft.Text("购物清单助手桌面程序1.0", color=ft.colors.WHITE, size=16)
            ],
            alignment=ft.MainAxisAlignment.START
        )
        close_button = ft.IconButton(
            ft.icons.CLOSE,
            tooltip="关闭",
            icon_color=ft.colors.RED,
            on_click=lambda e: page.window.close()
        )
        icons_row = ft.Row(
            controls=[
                ft.IconButton(ft.icons.HOME, tooltip="首页", icon_color=ft.colors.WHITE),
                ft.IconButton(ft.icons.SEARCH, tooltip="搜索", icon_color=ft.colors.WHITE),
                ft.IconButton(ft.icons.SETTINGS, tooltip="设置", icon_color=ft.colors.WHITE),
                close_button
            ],
            alignment=ft.MainAxisAlignment.END
        )
        top_row_container = ft.Container(
            content=ft.Row(
                controls=[app_title_row, icons_row],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                height=50,
                width=1220
            ),
            bgcolor=ft.colors.GREEN_500,
            padding=10,
        )
        return top_row_container
 
    # 创建标签栏
    def create_tabs():
        tabs = ft.Row(
            [
                create_tab(text="我的选购", icon_path="gg.png", on_click=tab_clicked),
                create_tab(text="清单详情", icon_path="hh.png", on_click=tab_clicked),
                create_tab(text="添加商品", icon_path="ii.png", on_click=tab_clicked),
                create_tab(text="保存商品", icon_path="jj.png", on_click=tab_clicked),
                create_tab(text="删除商品", icon_path="kk.png", on_click=tab_clicked),
                create_tab(text="联系我们", icon_path="ll.png", on_click=tab_clicked),
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=0,
            width=1200
        )
        return tabs
 
    # 创建布局
    layout_column = ft.Column(
        controls=[create_app_title(), create_tabs()],
        spacing=0
    )
 
    page.add(layout_column, content_container)
 
ft.app(target=main)

