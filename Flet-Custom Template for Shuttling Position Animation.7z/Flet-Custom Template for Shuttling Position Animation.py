import flet as ft
import asyncio

async def main(page: ft.Page):
    # Image width and spacing
    image_width = 100
    spacing = 20

    # Calculate the total occupied width
    total_width = 3 * image_width + 2 * spacing

    # Calculate the initial position of each image container
    left1 = page.window.width - total_width
    left2 = left1 + image_width + spacing
    left3 = left2 + image_width + spacing

    # Create image containers
    c1 = ft.Container(
        content=ft.Image(src="logo.jpg", width=image_width, height=image_width),  # Replace with your image path
        top=60,  # 60 pixels from the top
        left=left1,  # Initial position on the right
        animate_position=1000
    )

    c2 = ft.Container(
        content=ft.Image(src="logo.jpg", width=image_width, height=image_width),  # Replace with your image path
        top=60,  # 60 pixels from the top
        left=left2,  # Initial position on the right
        animate_position=500
    )

    c3 = ft.Container(
        content=ft.Image(src="logo.jpg", width=image_width, height=image_width),  # Replace with your image path
        top=60,  # 60 pixels from the top
        left=left3,  # Initial position on the right
        animate_position=1000
    )

    def animate_container():
        # Move image containers to the left
        c1.left -= 100
        c2.left -= 100
        c3.left -= 100

        # Check if positions need to be reset
        if c1.left <= -image_width:
            c1.left = page.window.width
        if c2.left <= -image_width:
            c2.left = page.window.width - image_width - spacing
        if c3.left <= -image_width:
            c3.left = page.window.width - 2 * image_width - 2 * spacing

        page.update()

    async def timer_tick():
        while True:
            animate_container()
            await asyncio.sleep(0.1)  # Update position every 0.1 seconds

    page.add(
        ft.Stack([c1, c2, c3], height=250),
    )

    # Start the timer task
    asyncio.create_task(timer_tick())

def start_app():
    ft.app(target=main)

if __name__ == "__main__":
    start_app()