import flet as ft


def main(page: ft.Page):
    page.title = "Flet-App Lifecycle State Attribute Enum Example Custom Template"
    # Define a text control to display the current lifecycle state
    status_text = ft.Text("App is shown")

    # Define a callback function for lifecycle state changes
    def app_lifecycle_change(e: ft.AppLifecycleStateChangeEvent):
        status_text.value = f"App state changed to: {e.state}"
        page.update()
        if e.state == ft.AppLifecycleState.DETACH:
            print("App is detached from the engine.")
        elif e.state == ft.AppLifecycleState.HIDE:
            print("App is hidden.")
        elif e.state == ft.AppLifecycleState.INACTIVE:
            print("App is inactive.")
        elif e.state == ft.AppLifecycleState.PAUSE:
            print("App is paused.")
        elif e.state == ft.AppLifecycleState.RESUME:
            print("App is resumed.")
        elif e.state == ft.AppLifecycleState.RESTART:
            print("App is restarted.")
        elif e.state == ft.AppLifecycleState.SHOW:
            print("App is shown.")

    # Set the callback function for lifecycle state changes
    page.on_app_lifecycle_state_change = app_lifecycle_change

    # Add the status text control to the page
    page.add(status_text)

    # Print "App is shown." when the app starts
    print("App is shown.")


# Start the Flet app
ft.app(target=main)
