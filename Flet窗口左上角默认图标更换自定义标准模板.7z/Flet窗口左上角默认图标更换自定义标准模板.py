import flet as ft


def main(page: ft.Page):
    # 设置窗口标题
    page.title = "Flet窗口左上角默认图标更换自定义标准模板"

    page.window.icon = "logo.ico"

    # 设置窗口大小
    page.window.width = 400
    page.window.height = 300

    # 添加一些内容到窗口
    page.add(ft.Text("这是一个带自定义图标的窗口标准模板"))


ft.app(target=main)
