import flet as ft


def main(page: ft.Page):
    page.title = "Main Window"
    page.window.width = 800
    page.window.height = 600

    def open_child_window(e):
        # Use a dialog as a child window
        dialog = ft.AlertDialog(
            title=ft.Text("Child Window"),
            content=ft.Column(
                [
                    ft.Text("This is a child window"),
                    ft.ElevatedButton("Close", on_click=lambda e: close_dialog(dialog)),
                ]
            ),
            actions=[],  # Remove the OK button from the actions list
        )
        page.overlay.append(dialog)  # Add the dialog to the page overlay
        dialog.open = True
        page.update()

    def close_dialog(dialog):
        dialog.open = False  # Directly set the open property of the dialog to False
        page.update()

    main_button = ft.ElevatedButton("Open Child Window", on_click=open_child_window)
    page.add(main_button)


# Start the main application
ft.app(target=main)
