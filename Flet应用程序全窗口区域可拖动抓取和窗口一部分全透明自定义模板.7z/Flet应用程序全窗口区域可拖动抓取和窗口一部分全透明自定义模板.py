import flet as ft


def main(page: ft.Page):
    # 隐藏标题栏和按钮
    page.window.title_bar_hidden = True
    page.window.title_bar_buttons_hidden = True
    
    # 设置窗口背景透明度
    page.bgcolor = ft.Colors.TRANSPARENT
    page.window.bgcolor = ft.Colors.TRANSPARENT  # 整个窗口背景透明
    page.window.opacity = 1.0  # 整个窗口不透明
    
    # 移除多余的 padding 设置
    page.padding = 0
    
    # 设置窗口固定大小
    window_width = 471
    window_height = 507
    page.window.width = window_width
    page.window.height = window_height
    
    def close_window(e):
        print("Close button clicked")  # 调试输出
        e.page.window.close()  # 关闭窗口
    
    # 创建关闭按钮
    close_button = ft.IconButton(
        icon=ft.Icons.CLOSE,
        on_click=close_window,  # 绑定事件处理函数
        bgcolor=ft.Colors.RED,  # 修改背景色为红色
        style=ft.ButtonStyle(shape=ft.CircleBorder()),
        icon_color=ft.Colors.BLACK,
        icon_size=26,
        tooltip="Close",
        top=10,
        left=200,
    )
    
    # 创建图像组件并设置填充模式
    image = ft.Image(
        src="shj.png",  # 确保路径正确
        width=window_width,
        height=window_height,
        fit=ft.ImageFit.COVER,  # 填满整个容器
    )
    
    # 创建堆叠布局
    stack = ft.Stack(
        controls=[
            image,
            close_button,  # 关闭按钮放在图片之上
        ],
        width=window_width,
        height=window_height,
        expand=True,  # 扩展以填满父容器
    )
    
    # 创建拖拽区域
    drag_area = ft.WindowDragArea(
        content=stack,
        width=window_width,
        height=window_height,
        expand=True,  # 扩展以填满父容器
    )
    
    # 添加拖拽区域到页面
    page.add(drag_area)
    
    # 防止窗口被调整大小
    page.window.resizable = False


ft.app(target=main)