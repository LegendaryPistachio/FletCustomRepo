import flet as ft
import asyncio
import os

# 图片资源列表
image_paths = ["image1.jpg", "image2.jpg", "image3.jpg", "image4.jpg", "image5.jpg", "image6.jpg", "image7.jpg"]

# 检查图片文件是否存在
for path in image_paths:
    if not os.path.exists(path):
        print(f"Image file {path} does not exist.")

# 主函数，标记为异步
async def main(page: ft.Page):
    page.title = "Image Carousel"
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"

    # 当前图片索引
    current_image_index = 0

    # 图片显示区域，设置宽度和高度
    image = ft.Image(src=image_paths[current_image_index], width=1200, height=600, fit=ft.ImageFit.CONTAIN)
    print(f"Initial image source: {image.src}")  # 调试信息

    # 自定义按钮列表
    def change_image_callback(index):
        nonlocal current_image_index
        current_image_index = index
        change_image(page, image, segmented_control, current_image_index)

    # 创建 CupertinoSlidingSegmentedButton
    segmented_control = ft.CupertinoSlidingSegmentedButton(
        selected_index=current_image_index,
        thumb_color=ft.colors.BLUE_400,
        on_change=lambda e: change_image_callback(int(e.data)),
        padding=ft.padding.symmetric(0, 10),
        controls=[
            ft.Container(
                content=ft.Text(f"{i+1}"),
                width=100,  # 设置每个按钮的宽度
                alignment=ft.alignment.center
            )
            for i in range(len(image_paths))
        ],
    )

    # 使用 Stack 将图片和按钮组堆叠在一起
    stack = ft.Stack([
        image,
        ft.Container(
            content=segmented_control,
            alignment=ft.alignment.bottom_center,
            margin=ft.Margin(0, 0, 0, 50)  # 调整按钮组的底部间距
        )
    ], alignment=ft.alignment.center)  # 确保 Stack 内容居中

    # 使用 Container 设置 Stack 的对齐方式
    container = ft.Container(
        content=stack,
        alignment=ft.alignment.center,
        expand=True
    )

    # 页面布局
    page.add(container)

    # 定时器，用于自动轮播
    async def auto_rotate():
        nonlocal current_image_index
        while True:
            if current_image_index < len(image_paths) - 1:
                current_image_index += 1
            else:
                current_image_index = 0
            change_image(page, image, segmented_control, current_image_index)
            await asyncio.sleep(3)  # 3秒切换一次图片

    # 启动自动轮播
    page.run_task(auto_rotate)  # 传递函数本身，而不是调用它

def change_image(page, image, segmented_control, index):
    image.src = image_paths[index]
    print(f"Changing image source to: {image.src}")  # 调试信息

    # 更新按钮颜色
    segmented_control.selected_index = index
    page.update()

ft.app(main)