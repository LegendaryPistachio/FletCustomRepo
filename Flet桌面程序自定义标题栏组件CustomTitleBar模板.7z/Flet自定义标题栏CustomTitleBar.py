import flet as ft
from flet import Icons, Colors

def create_app_title(page):
    return ft.Container(
        content=ft.Row(
            controls=[
                ft.Row(
                    controls=[
                        ft.IconButton(ft.icons(Icons.SHOPPING_CART), tooltip="购物车", icon_color=ft.colors(Colors.WHITE)),
                        ft.Text("Flet自定义标题栏Custom Title Bar", color=ft.colors(Colors.WHITE), size=16)
                    ],
                    alignment=ft.MainAxisAlignment.START
                ),
                ft.Row(
                    controls=[
                        ft.IconButton(ft.icons(Icons.ADD), tooltip="添加", icon_color=ft.colors(Colors.GREEN), on_click=lambda _: print("添加按钮点击")),
                        ft.IconButton(ft.icons(Icons.HELP), tooltip="帮助", icon_color=ft.colors(Colors.BLUE), on_click=lambda _: print("帮助按钮点击")),
                        ft.IconButton(ft.icons(Icons.INFO), tooltip="关于", icon_color=ft.colors(Colors.RED), on_click=lambda _: print("关于按钮点击")),
                        ft.IconButton(ft.icons(Icons.CLOSE), tooltip="关闭", icon_color=ft.colors(Colors.RED), on_click=lambda _: page.window.close())
                    ],
                    alignment=ft.MainAxisAlignment.END
                )
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            height=50,
            width=1200
        ),
        bgcolor=ft.colors(Colors.GREEN_500),
        padding=10,
    )

def main(page: ft.Page):
    page.window.frameless = True
    page.add(create_app_title(page))

if __name__ == "__main__":
    ft.app(target=main)