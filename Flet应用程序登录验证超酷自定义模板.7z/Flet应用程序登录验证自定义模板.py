import flet as ft
from flet import (
    Page,
    TextField,
    Checkbox,
    ElevatedButton,
    Text,
    Row,
    Column,
    ControlEvent,
    app,
)


def main(page: ft.Page):
    # 设置页面背景和主题
    def login_page():
        # 设置页面基本属性
        page.title = "Flet应用程序登录验证自定义模板"
        page.vertical_alignment = ft.MainAxisAlignment.CENTER
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.theme = ft.Theme(color_scheme_seed=ft.Colors.BLUE)
        page.window.width = 1000
        page.window.height = 700
        page.window.resizable = False
        page.bgcolor = ft.Colors.WHITE

        # 保存输入框组件的引用
        text_username = TextField(
            label="用户名",
            text_align=ft.TextAlign.LEFT,
            width=300,
            prefix_icon=ft.Icons.PERSON_OUTLINE,
            border=ft.InputBorder.UNDERLINE,
            hint_text="请输入用户名",
        )

        text_password = TextField(
            label="密码",
            text_align=ft.TextAlign.LEFT,
            width=300,
            password=True,
            can_reveal_password=True,
            prefix_icon=ft.Icons.LOCK_OUTLINE,
            border=ft.InputBorder.UNDERLINE,
            hint_text="请输入密码",
        )

        checkbox_signup = Checkbox(
            label="我已阅读并同意用户协议和隐私政策",
            value=False,
            fill_color=ft.Colors.BLUE,
        )

        button_submit = ElevatedButton(
            content=ft.Text("登 录", size=16, weight=ft.FontWeight.W_500),
            style=ft.ButtonStyle(
                color=ft.Colors.WHITE,
                bgcolor=ft.Colors.BLUE,
                padding=ft.padding.symmetric(horizontal=100, vertical=20),
            ),
            width=300,
            disabled=True,
        )

        # 创建登录卡片
        login_card = ft.Container(
            width=400,
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    # Logo和标题
                    ft.Icon(
                        ft.Icons.ACCOUNT_CIRCLE_ROUNDED, size=80, color=ft.Colors.BLUE
                    ),
                    ft.Text(
                        "用户登录",
                        size=28,
                        weight=ft.FontWeight.BOLD,
                        color=ft.Colors.BLUE_900,
                    ),
                    ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
                    # 用户名输入框
                    ft.Container(
                        content=text_username, margin=ft.margin.only(bottom=10)
                    ),
                    # 密码输入框
                    ft.Container(
                        content=text_password, margin=ft.margin.only(bottom=20)
                    ),
                    # 同意条款复选框
                    ft.Container(
                        content=checkbox_signup, margin=ft.margin.only(bottom=20)
                    ),
                    # 登录按钮
                    ft.Container(content=button_submit),
                    # 底部文字
                    ft.Container(
                        content=ft.Text(
                            "hhhhhh System v1.0",
                            size=12,
                            color=ft.Colors.GREY_600,
                        ),
                        margin=ft.margin.only(top=30),
                    ),
                ],
                spacing=5,
            ),
            padding=40,
            bgcolor=ft.Colors.WHITE,
            border_radius=8,
            shadow=ft.BoxShadow(
                spread_radius=1,
                blur_radius=15,
                color=ft.Colors.BLUE_GREY_100,
            ),
        )

        def validate(e: ControlEvent) -> None:
            if all([text_username.value, text_password.value, checkbox_signup.value]):
                button_submit.disabled = False
            else:
                button_submit.disabled = True
            page.update()

        def submit(e: ControlEvent) -> None:
            # 显示加载动画
            progress_ring = ft.ProgressRing()
            page.overlay.append(progress_ring)
            page.update()

            print("Username:", text_username.value)
            print("Password:", text_password.value)

            # 移除加载动画
            page.overlay.remove(progress_ring)
            page.clean()

        # 绑定事件处理
        checkbox_signup.on_change = validate
        text_username.on_change = validate
        text_password.on_change = validate
        button_submit.on_click = submit

        # 添加登录卡片到页面
        page.add(
            ft.Container(
                content=login_card,
                alignment=ft.alignment.center,
            )
        )
        # 初始化显示登录页面

    login_page()


ft.app(target=main)
