import flet as ft
import json
import os

# Define data model
class Item:
    def __init__(self, name, checked=False):
        self.name = name
        self.checked = checked

    def to_dict(self):
        return {'name': self.name, 'checked': self.checked}

    @classmethod
    def from_dict(cls, data):
        return cls(data['name'], data['checked'])

# Data file path
DATA_FILE = 'data.json'

# Load data
def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as file:
            data = json.load(file)
            return [Item.from_dict(item) for item in data]
    return []

# Save data
def save_data(items):
    data = [item.to_dict() for item in items]
    with open(DATA_FILE, 'w') as file:
        json.dump(data, file, indent=2)

# Initialize content
content = ft.Column(
    [
        ft.Text("Body!", size=20),
    ],
    alignment=ft.MainAxisAlignment.CENTER,
    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
)

# Input field and list view
input_text = ft.TextField(label="Enter item name")
items_list = ft.ListView(expand=1, spacing=10, padding=20, auto_scroll=True)

data_table = ft.DataTable(
    columns=[
        ft.DataColumn(ft.Text("Item Name")),
        ft.DataColumn(ft.Text("Checked")),
    ],
    rows=[],
)

# Set up navigation bar
def main(page: ft.Page):
    global items  # Define items as a global variable
    items = load_data()  # Initialize items

    page.window.width = 400
    page.window.height = 600
    page.window.frameless = True

    # Function to update page content
    def navigate(e):
        if page.navigation_bar.selected_index == 0:
            content.controls = [
                ft.Column([
                    input_text,
                    ft.Column(
                        [items_list],
                        height=page.window.height - 120,  # Subtract the height of the navigation bar and input field
                        scroll=ft.ScrollMode.AUTO
                    ),
                ], alignment=ft.MainAxisAlignment.START)
            ]
        elif page.navigation_bar.selected_index == 1:
            content.controls = [
                ft.Column(
                    [
                        ft.Text("Shopping List", size=18, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                        ft.Container(
                            content=ft.Column(
                                [
                                    ft.Column(
                                        [data_table],
                                        height=page.window.height - 120,  # Subtract the height of the navigation bar and title
                                        scroll=ft.ScrollMode.AUTO
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER
                            ),
                            padding=20,
                            alignment=ft.alignment.center
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                )
            ]
        else:
            content.controls = [
                ft.Text("About Content!", size=20),
                ft.Divider(),
                ft.Image(src="logo.png", width=100, height=100),
                ft.Column([
                    ft.Text("Shopping List Assistant Mobile App v1.0", size=14),
                    ft.Text("Author: Legendary Pistachio", size=14),
                    ft.Text("WeChat: lxm1093220242", size=14),
                ], alignment=ft.MainAxisAlignment.START),
            ]

        page.update()

    # Set up navigation bar
    page.navigation_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(
                icon=ft.icons.HOME, 
                selected_icon=ft.icons.HOME_ROUNDED, 
                label="Home"
            ),
            ft.NavigationBarDestination(
                icon=ft.icons.LIST, 
                selected_icon=ft.icons.LIST_ALT, 
                label="List"
            ),
            ft.NavigationBarDestination(
                icon=ft.icons.INFO, 
                selected_icon=ft.icons.INFO_ROUNDED, 
                label="About"
            ),
        ],
        on_change=navigate
    )

    # Set up AppBar
    page.appbar = ft.AppBar(
        leading=ft.Row(
            [
                ft.Container(
                    content=ft.Text("Shopping List Assistant v1.0", size=14, weight=ft.FontWeight.BOLD),
                    padding=ft.padding.only(left=20),  # Set left padding to 20
                )
            ],
            alignment=ft.MainAxisAlignment.START
        ),
        center_title=False,
        bgcolor=ft.colors.SURFACE_VARIANT,
        actions=[
            ft.IconButton(ft.icons.ADD, on_click=lambda e: add_action(e, page)),
            ft.IconButton(ft.icons.DELETE, on_click=lambda e: delete_action(e, page)),
            ft.IconButton(ft.icons.SAVE, on_click=lambda e: save_action(e, page)),
            ft.IconButton(ft.icons.CLOSE, on_click=lambda e: exit_app(e, page)),
        ],
        toolbar_height=60  # Adjust height to fit more space
    )

    # Initialize data table
    for item in items:
        items_list.controls.append(
            ft.ListTile(
                leading=ft.Checkbox(value=item.checked, on_change=lambda e, i=item: toggle_checkbox(e, page, i)),
                title=ft.Text(item.name),
            )
        )
        data_table.rows.append(
            ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(item.name)),
                    ft.DataCell(ft.Text("Yes" if item.checked else "No")),
                ]
            )
        )

    # Wrap content in SafeArea component
    safe_area_content = ft.SafeArea(content)

    # Add content to page
    page.add(safe_area_content)

    # Initialize navigation bar
    page.navigation_bar.selected_index = 0
    navigate(None)

# Add new item
def add_action(e, page):
    if input_text.value:
        item = Item(input_text.value)
        items.append(item)
        items_list.controls.append(
            ft.ListTile(
                leading=ft.Checkbox(value=item.checked, on_change=lambda e, i=item: toggle_checkbox(e, page, i)),
                title=ft.Text(item.name),
            )
        )
        data_table.rows.append(
            ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(item.name)),
                    ft.DataCell(ft.Text("Yes" if item.checked else "No")),
                ]
            )
        )
        input_text.value = ""
        save_data(items)
        page.update()

# Delete selected items
def delete_action(e, page):
    checked_items = [item for item in items if item.checked]
    for item in checked_items:
        index = items.index(item)
        items_list.controls.pop(index)
        data_table.rows.pop(index)
        items.remove(item)
    save_data(items)
    page.update()

# Save data
def save_action(e, page):
    save_data(items)
    page.update()

# Exit app
def exit_app(e, page):
    page.window_close()

# Toggle item status
def toggle_checkbox(e, page, item):
    index = items.index(item)
    item.checked = e.control.value
    data_table.rows[index].cells[1].content.value = "Yes" if item.checked else "No"
    save_data(items)
    page.update()

# Launch app
ft.app(target=main)