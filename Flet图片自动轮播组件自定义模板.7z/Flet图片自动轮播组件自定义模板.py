import flet as ft
import time
from threading import Thread

def main(page: ft.Page):
    page.title = "Flet图片自动轮播组件自定义模板"
    # 本地图片路径列表
    images = [
       'desktop computer.jpg',
        'smartphone2.jpg',
        'smartearbuds2.jpg',
        'laptop.jpg',
        'smartband1.jpg',
        'smartband2.jpg',  
        'smartphone1.jpg',
        'smartphone3.jpg'
    ]
    
    # 当前显示的图片索引
    current_index = 0
    
    # 图片控件
    image_control = ft.Image(
        src=images[current_index],
        width=400,
        height=300,
        fit=ft.ImageFit.CONTAIN
    )
    
    # 更新图片的函数
    def update_image():
        nonlocal current_index
        while True:
            time.sleep(3)  # 每隔3秒切换一次图片
            current_index = (current_index + 1) % len(images)
            image_control.src = images[current_index]
            page.update()  # 更新页面
    
    # 启动线程自动更新图片
    thread = Thread(target=update_image, daemon=True)
    thread.start()
    
    # 添加图片控件到页面
    page.add(image_control)

# 运行应用
ft.app(target=main)