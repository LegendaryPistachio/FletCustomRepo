import flet as ft

def main(page: ft.Page):
    page.title = "Flet带透明度变化带形状变化带边框颜色变化的酷炫玻璃按钮样式示例自定义模板"

    def on_hover(e):
        if e.data == "true":
            button.style.bgcolor = ft.Colors.with_opacity(0.7, ft.Colors.GREEN_500)  # 鼠标悬停时透明度为 70%
        else:
            button.style.bgcolor = ft.Colors.with_opacity(0.5, ft.Colors.GREEN_500)  # 默认透明度为 50%
        button.update()

    button = ft.ElevatedButton(
        "Styled button 1",
        style=ft.ButtonStyle(
            color={
                ft.ControlState.HOVERED: ft.Colors.WHITE,
                ft.ControlState.DEFAULT: ft.Colors.WHITE,
            },
            bgcolor={
                ft.ControlState.HOVERED: ft.Colors.with_opacity(0.7, ft.Colors.GREEN_500),
                ft.ControlState.DEFAULT: ft.Colors.with_opacity(0.5, ft.Colors.GREEN_500),
            },
            padding=15,
            overlay_color=ft.Colors.TRANSPARENT,
            elevation={"pressed": 0, ft.ControlState.DEFAULT: 5},
            side={
                ft.ControlState.DEFAULT: ft.BorderSide(2, ft.Colors.GREEN_500),
                ft.ControlState.HOVERED: ft.BorderSide(3, ft.Colors.GREEN_900),
            },
            shape={
                ft.ControlState.HOVERED: ft.RoundedRectangleBorder(radius=20),
                ft.ControlState.DEFAULT: ft.RoundedRectangleBorder(radius=2),
            },
            animation_duration=500,  # 添加动画效果
        ),
        on_hover=on_hover,
    )

    page.add(button)

ft.app(main)